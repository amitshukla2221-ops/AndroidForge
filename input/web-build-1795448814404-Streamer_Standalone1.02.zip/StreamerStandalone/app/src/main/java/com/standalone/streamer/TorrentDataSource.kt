package com.standalone.streamer

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import org.libtorrent4j.Priority
import org.libtorrent4j.TorrentHandle
import org.libtorrent4j.TorrentInfo
import java.io.File
import java.io.IOException
import java.io.InterruptedIOException
import java.io.RandomAccessFile

/**
 * Serves one file of a torrent to Media3. Reads block until the torrent piece that
 * covers the requested byte has been downloaded and verified by libtorrent.
 */
@UnstableApi
class TorrentDataSource(
    private val ti: TorrentInfo,
    private val handle: TorrentHandle,
    private val fileIndex: Int,
    private val file: File
) : BaseDataSource(true) {

    private val size: Long = ti.files().fileSize(fileIndex)
    private val pieceLength: Int = ti.pieceLength()
    private val firstPiece: Int = ti.mapFile(fileIndex, 0, 1).piece()
    private val lastPiece: Int = ti.mapFile(fileIndex, size - 1, 1).piece()

    private var raf: RandomAccessFile? = null
    private var uri: Uri? = null
    private var position = 0L
    private var remaining = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)
        position = dataSpec.position
        if (position >= size) {
            throw DataSourceException(PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        }
        val available = size - position
        remaining = if (dataSpec.length == C.LENGTH_UNSET.toLong()) available
        else minOf(dataSpec.length, available)
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT

        val req = ti.mapFile(fileIndex, position, 1)
        val piece = req.piece()
        val bytesLeftInPiece = pieceLength - req.start()
        val n = minOf(length.toLong(), remaining, bytesLeftInPiece.toLong()).toInt()

        waitForPiece(piece)

        val f = raf ?: openFile()
        var read = 0
        var tries = 0
        while (read <= 0) {
            f.seek(position)
            read = f.read(buffer, offset, n)
            if (read <= 0) {
                read = 0
                if (++tries > 100) throw IOException("Downloaded data not readable")
                sleep(100)
            }
        }
        position += read
        remaining -= read
        bytesTransferred(read)
        return read
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        uri = null
        try {
            raf?.close()
        } finally {
            raf = null
            if (opened) {
                opened = false
                transferEnded()
            }
        }
    }

    private fun openFile(): RandomAccessFile {
        var tries = 0
        while (!file.exists()) {
            if (++tries > 300) throw IOException("File was not created by engine")
            sleep(100)
        }
        return RandomAccessFile(file, "r").also { raf = it }
    }

    private fun waitForPiece(piece: Int) {
        if (handle.havePiece(piece)) return
        handle.piecePriority(piece, Priority.SEVEN)
        val end = minOf(piece + 4, lastPiece)
        for (p in (piece + 1)..end) {
            if (p >= firstPiece) handle.piecePriority(p, Priority.SIX)
        }
        while (!handle.havePiece(piece)) sleep(150)
    }

    private fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            throw InterruptedIOException()
        }
    }
}
