import { createFileRoute } from "@tanstack/react-router";
import { AudioLines, Bluetooth, Download, SlidersHorizontal, Speaker } from "lucide-react";
import type { ReactNode } from "react";
import { previewPathPrefix } from "@/lib/preview-path-prefix";

export const Route = createFileRoute("/")({ component: Home });

const APK_NAME = "SystemAudioBridge-2.2.0.apk";
const APK_PATH = `/${APK_NAME}`;

function apkHref(): string {
  if (typeof window === "undefined") return APK_PATH;
  const prefix = previewPathPrefix(window.location.hostname, window.location.pathname) ?? "";
  return `${prefix}${APK_PATH}`;
}

function Home() {
  return (
    <main className="mx-auto min-h-screen max-w-3xl px-5 py-10 sm:px-8 sm:py-16">
      <p className="text-xs font-medium tracking-[0.22em] text-primary uppercase">Version 2.2.0</p>
      <h1 className="font-display mt-3 text-5xl leading-none font-medium text-fg sm:text-6xl">
        System Audio Bridge
      </h1>
      <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted">
        One clean capture, then two copies that stay put: the tablet speaker and the Bluetooth
        speaker. You line them up yourself. Each one has its own volume.
      </p>

      <a
        href={APK_PATH}
        download={APK_NAME}
        onClick={(event) => {
          event.currentTarget.href = apkHref();
        }}
        className="mt-8 inline-flex min-h-12 items-center gap-3 rounded-2xl bg-primary px-5 py-3 text-base font-semibold text-primary-ink no-underline"
      >
        <Download className="size-5" aria-hidden />
        Download {APK_NAME}
        <span className="font-medium opacity-70">45 KB</span>
      </a>
      <p className="mt-3 text-sm text-muted">
        Android 10 or newer. Open the file after it downloads, then install. This build installs
        over 2.1.0. Uninstall 1.x first if Android reports a conflict.
      </p>

      <section className="mt-12 grid gap-3 sm:grid-cols-3">
        <Card
          icon={<Speaker className="size-5" aria-hidden />}
          title="Each speaker stays"
          body="A copy is pinned once and left there. Sync and level changes do not move it to the other speaker."
        />
        <Card
          icon={<AudioLines className="size-5" aria-hidden />}
          title="Manual sync only"
          body="Above each sync slider: who is playing first, and by how many milliseconds. Nothing adjusts that for you."
        />
        <Card
          icon={<SlidersHorizontal className="size-5" aria-hidden />}
          title="Separate levels"
          body="Tablet volume never changes Bluetooth, and Bluetooth never changes the tablet. No blend between them."
        />
      </section>

      <section className="mt-10 rounded-card border border-line bg-surface p-5 sm:p-7">
        <h2 className="font-display text-3xl font-medium">Install on the Pad</h2>
        <ol className="mt-4 space-y-3 text-base leading-relaxed text-fg">
          <li className="flex gap-3">
            <Step n="1" />
            Download the file, then open it from the notification or the Files app.
          </li>
          <li className="flex gap-3">
            <Step n="2" />
            If the tablet blocks it: Settings, Security, More settings, Install unknown apps, and
            allow the browser you used.
          </li>
          <li className="flex gap-3">
            <Step n="3" />
            Open Audio Bridge. Tap Start. Allow microphone, nearby Bluetooth, and notifications. On
            the capture screen, allow it and include audio.
          </li>
          <li className="flex gap-3">
            <Step n="4" />
            Play music in another app. Read the line above Sync. Drag that slider until the echo
            is gone. The line tells you which side is ahead, and by how many milliseconds.
          </li>
          <li className="flex gap-3">
            <Step n="5" />
            Set each level on its own slider. 100% with Flat is the untouched recording. Mute
            silences only that copy.
          </li>
        </ol>
      </section>

      <section className="mt-6 rounded-card border border-line bg-surface p-5 sm:p-7">
        <div className="flex items-center gap-2 text-primary">
          <Bluetooth className="size-5" aria-hidden />
          <h2 className="font-display text-3xl font-medium text-fg">How the sound stays clean</h2>
        </div>
        <ul className="mt-4 space-y-2 text-base leading-relaxed text-muted">
          <li>Capture is 48 kHz stereo. Flat at full level does not touch the samples.</li>
          <li>Other levels are a straight scale. The equalizer is the only thing that reshapes tone.</li>
          <li>The two copies are never added together, and a level slider never feeds the other side.</li>
          <li>Sync does not pause or flush playback, so moving it does not throw the sound to the other speaker.</li>
          <li>Stopping the bridge puts the media volume back if it was lowered.</li>
        </ul>
      </section>
    </main>
  );
}

function Card({ icon, title, body }: { icon: ReactNode; title: string; body: string }) {
  return (
    <article className="rounded-card border border-line bg-surface p-4">
      <div className="text-primary">{icon}</div>
      <h2 className="mt-3 text-base font-semibold text-fg">{title}</h2>
      <p className="mt-1 text-sm leading-relaxed text-muted">{body}</p>
    </article>
  );
}

function Step({ n }: { n: string }) {
  return (
    <span className="mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-ink">
      {n}
    </span>
  );
}
