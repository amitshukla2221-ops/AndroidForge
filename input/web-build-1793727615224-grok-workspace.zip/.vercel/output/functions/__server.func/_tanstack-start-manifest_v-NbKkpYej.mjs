//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-NbKkpYej.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-iUEl54Hf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-iUEl54Hf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dn8n59ri.js"]
	}
} });
//#endregion
export { tsrStartManifest };
