import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Bluetooth, i as Download, n as Speaker, o as AudioLines, r as SlidersHorizontal } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-mr_kYR5u.js
var import_jsx_runtime = require_jsx_runtime();
var APK = "/SystemAudioBridge-2.2.0.apk";
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-3xl px-5 py-10 sm:px-8 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-[0.22em] text-primary uppercase",
				children: "Version 2.2.0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-3 text-5xl leading-none font-medium text-fg sm:text-6xl",
				children: "System Audio Bridge"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-xl text-lg leading-relaxed text-muted",
				children: "One clean capture, then two copies that stay put: the tablet speaker and the Bluetooth speaker. You line them up yourself. Each one has its own volume."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: APK,
				download: "SystemAudioBridge-2.2.0.apk",
				className: "mt-8 inline-flex min-h-12 items-center gap-3 rounded-2xl bg-primary px-5 py-3 text-base font-semibold text-primary-ink no-underline",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
					className: "size-5",
					"aria-hidden": true
				}), "Download APK"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Android 10 or newer. Installs over 2.1.0. Uninstall 1.x first if Android reports a conflict."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12 grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Speaker, {
							className: "size-5",
							"aria-hidden": true
						}),
						title: "Each speaker stays",
						body: "A copy is pinned once and left there. Sync and level changes do not move it to the other speaker."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, {
							className: "size-5",
							"aria-hidden": true
						}),
						title: "Manual sync only",
						body: "Above each sync slider: who is playing first, and by how many milliseconds. Nothing adjusts that for you."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
							className: "size-5",
							"aria-hidden": true
						}),
						title: "Separate levels",
						body: "Tablet volume never changes Bluetooth, and Bluetooth never changes the tablet. No blend between them."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 rounded-card border border-line bg-surface p-5 sm:p-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl font-medium",
					children: "Install on the Pad"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-4 space-y-3 text-base leading-relaxed text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "1" }), "Download the file, then open it from the notification or the Files app."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "2" }), "If the tablet blocks it: Settings, Security, More settings, Install unknown apps, and allow the browser you used."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "3" }), "Open Audio Bridge. Tap Start. Allow microphone, nearby Bluetooth, and notifications. On the capture screen, allow it and include audio."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "4" }), "Play music in another app. Read the line above Sync. Drag that slider until the echo is gone. The line tells you which side is ahead, and by how many milliseconds."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "5" }), "Set each level on its own slider. 100% with Flat is the untouched recording. Mute silences only that copy."]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-card border border-line bg-surface p-5 sm:p-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bluetooth, {
						className: "size-5",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-medium text-fg",
						children: "How the sound stays clean"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2 text-base leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Capture is 48 kHz stereo. Flat at full level does not touch the samples." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Other levels are a straight scale. The equalizer is the only thing that reshapes tone." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The two copies are never added together, and a level slider never feeds the other side." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Sync does not pause or flush playback, so moving it does not throw the sound to the other speaker." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stopping the bridge puts the media volume back if it was lowered." })
					]
				})]
			})
		]
	});
}
function Card({ icon, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-primary",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-base font-semibold text-fg",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: body
			})
		]
	});
}
function Step({ n }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-ink",
		children: n
	});
}
//#endregion
export { Home as component };
