# System Audio Bridge

Android project for System Audio Bridge. Minimum Android version is Android 10 (API 29); target SDK is 34.

## Build locally

```bash
./gradlew assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build in the cloud

This repository includes `.github/workflows/build-apk.yml`. Upload the extracted project files to a GitHub repository, then open **Actions → Build Android APK → Run workflow**. Download the resulting `SystemAudioBridge-debug-apk` artifact from the successful workflow run.

See `GITHUB_BUILD_INSTRUCTIONS.md` for detailed steps.

## Audio behavior and testing

The reverse-route experiment leaves Android's direct media route unchanged and routes the bridge's captured copy to the built-in phone speaker when the system media route is Bluetooth. Delay applies to the captured copy only. Validate on the target phone and speaker; source-app playback capture may be restricted for protected audio.
