package com.example.systemaudiobridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Copies media/game playback into an in-memory PCM buffer. If Android already
 * routes the original mix to Bluetooth, the copy is played through the built-in
 * speaker; otherwise the copy is sent to Bluetooth. The original mix is never
 * stopped or rerouted by this service.
 */
class AudioBridgeService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private val haltLock = Any()
    private var halted = false

    private var mediaProjection: MediaProjection? = null
    @Volatile private var audioRecord: AudioRecord? = null
    @Volatile private var audioTrack: AudioTrack? = null
    private var captureThread: Thread? = null
    private var preferredDeviceId: Int? = null
    private var devicesRegistered = false
    private var routeCheckPosted = false
    private var routeGeneration = 0

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            if (running.get()) reattach("Bluetooth back")
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            val id = preferredDeviceId ?: return
            if (!running.get() || removedDevices.none { it.id == id }) return
            if (reattach("Bluetooth moved")) return
            if (!routeCheckPosted) {
                routeCheckPosted = true
                val generation = routeGeneration
                BridgeStatus.update(
                    BridgeStatus.Phase.BRIDGING,
                    "Bluetooth blipped. Holding the bridge for a moment."
                )
                mainHandler.postDelayed({ confirmRoute(generation) }, BridgePolicy.ROUTE_GRACE_MS)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        channel.description = getString(R.string.channel_desc)
        channel.setSound(null, null)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                if (BridgeStatus.snapshot().phase == BridgeStatus.Phase.BRIDGING) {
                    BridgeStatus.update(BridgeStatus.Phase.IDLE, getString(R.string.stopped))
                }
                requestHalt()
            }
            ACTION_START -> {
                if (running.get()) return START_NOT_STICKY
                synchronized(haltLock) { halted = false }
                try {
                    startForeground(
                        NOTIFICATION_ID,
                        buildNotification(getString(R.string.notification_starting)),
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    )
                } catch (t: Exception) {
                    Log.e(TAG, "startForeground failed", t)
                    BridgeStatus.update(BridgeStatus.Phase.ERROR, getString(R.string.error_blocked))
                    stopSelf()
                    return START_NOT_STICKY
                }
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = readResultData(intent)
                if (data == null) {
                    BridgeStatus.update(BridgeStatus.Phase.ERROR, getString(R.string.error_projection))
                    requestHalt()
                } else {
                    try {
                        startCapture(resultCode, data)
                    } catch (t: Throwable) {
                        Log.e(TAG, "Failed to start capture", t)
                        BridgeStatus.update(BridgeStatus.Phase.ERROR, messageFor(t))
                        requestHalt()
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        requestHalt()
        super.onDestroy()
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val target = SpeakerRouter.findBridgeOutput(this)
            ?: throw IllegalStateException("no-speaker")

        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, data)
            ?: throw IllegalStateException("projection")
        mediaProjection = projection
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (BridgeStatus.snapshot().phase == BridgeStatus.Phase.BRIDGING) {
                    BridgeStatus.update(BridgeStatus.Phase.IDLE, getString(R.string.capture_ended))
                }
                requestHalt()
            }
        }, mainHandler)

        val rate = BridgePolicy.chooseRate(target.device.sampleRates)
        val minIn = AudioRecord.getMinBufferSize(rate, CHANNEL_IN, ENCODING)
        val minOut = AudioTrack.getMinBufferSize(rate, CHANNEL_OUT, ENCODING)
        if (minIn <= 0 || minOut <= 0) {
            throw IllegalStateException("format")
        }

        val captureConfig = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        var record = openRecord(captureConfig, rate, minIn)
            ?: throw IllegalStateException("record")
        audioRecord = record

        val track = buildTrack(rate, minOut)
        audioTrack = track
        if (!routeTo(track, target.device)) {
            throw IllegalStateException("route")
        }
        preferredDeviceId = target.device.id

        record.startRecording()
        if (track.playState != AudioTrack.PLAYSTATE_PLAYING) {
            track.play()
        }
        running.set(true)

        val chunkShorts = readChunkShorts(minIn, rate)
        val eq = StereoEq(rate)
        val delay = StereoDelay(rate)
        val stabilizer = LevelStabilizer()
        val outBytes = track.bufferSizeInFrames * FRAME_BYTES
        val phoneNote = if (SpeakerRouter.mediaAlreadyOnBluetooth(this) && target.device.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) {
            " Bluetooth remains the direct system output; this bridge plays the synchronized copy on the phone speaker."
        } else {
            " The original system playback route is left unchanged."
        }
        val detail = "Copy playing on ${target.label}. Clean ${rate / 1000.0} kHz stream; app buffering is about ${bufferMillis(minIn, rate) + bufferMillis(outBytes, rate)} ms, plus device latency. Song changes stay connected.$phoneNote"
        BridgeStatus.update(BridgeStatus.Phase.BRIDGING, detail)
        notify(detail)

        if (!devicesRegistered) {
            SpeakerRouter.audioManager(this).registerAudioDeviceCallback(deviceCallback, mainHandler)
            devicesRegistered = true
        }

        captureThread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val buffer = ShortArray(chunkShorts)
            var silentLoops = 0
            var heard = false
            var failures = 0
            var reopens = 0
            while (running.get()) {
                val read = try {
                    record.read(buffer, 0, buffer.size)
                } catch (t: Throwable) {
                    Log.e(TAG, "AudioRecord read threw", t)
                    -1
                }
                if (read < 0) {
                    failures++
                    Log.w(TAG, "AudioRecord read error $read ($failures)")
                    if (!BridgePolicy.shouldReopen(failures)) {
                        try {
                            Thread.sleep(20)
                        } catch (_: InterruptedException) {
                        }
                        continue
                    }
                    failures = 0
                    reopens++
                    if (BridgePolicy.shouldStopAfterReopens(reopens)) {
                        BridgeStatus.update(BridgeStatus.Phase.ERROR, getString(R.string.error_start))
                        requestHalt()
                        break
                    }
                    val fresh = openRecord(captureConfig, rate, minIn)
                    if (fresh == null) continue
                    try {
                        record.stop()
                    } catch (_: Exception) {
                    }
                    try {
                        record.release()
                    } catch (_: Exception) {
                    }
                    record = fresh
                    audioRecord = fresh
                    try {
                        fresh.startRecording()
                    } catch (t: Throwable) {
                        Log.e(TAG, "restart recording failed", t)
                        continue
                    }
                    val held = "Capture restarted. Bridge stayed on."
                    BridgeStatus.update(BridgeStatus.Phase.BRIDGING, held)
                    notify(held)
                    continue
                }
                failures = 0
                if (read == 0) continue
                if (!heard) {
                    var i = 0
                    while (i < read) {
                        val sample = buffer[i]
                        if (sample > 80 || sample < -80) {
                            heard = true
                            break
                        }
                        i += 8
                    }
                    if (!heard) {
                        silentLoops++
                        if (silentLoops == 80) {
                            val quiet = "Bridging the audio copy to ${target.label}, but nothing capturable is playing yet. DRM apps can block this."
                            BridgeStatus.update(BridgeStatus.Phase.BRIDGING, quiet)
                            notify(quiet)
                        }
                    }
                }
                val delayMs = MixControl.delayMs
                if (delayMs > 0) delay.apply(buffer, read, delayMs)
                val gain = MixControl.btGain()
                val ride = MixControl.stabilize
                val shape = MixControl.eqActive()
                if (shape) eq.process(buffer, read, 1f)
                if (ride || shape || gain < 0.995f) {
                    stabilizer.apply(buffer, read, gain, ride)
                }
                LiveLevels.push(buffer, read, rate)
                val wrote = track.write(buffer, 0, read)
                if (wrote < 0) {
                    Log.e(TAG, "AudioTrack write error $wrote")
                    if (!reattach("Playback route moved")) {
                        BridgeStatus.update(BridgeStatus.Phase.ERROR, getString(R.string.error_start))
                        requestHalt()
                        break
                    }
                }
            }
        }, "AudioBridgeCapture")
        captureThread?.start()
        Log.i(TAG, "Bridge started rate=$rate in=$minIn out=${track.bufferSizeInFrames} device=${target.label}")
    }

    private fun openRecord(
        captureConfig: AudioPlaybackCaptureConfiguration,
        rate: Int,
        minIn: Int,
    ): AudioRecord? {
        return try {
            val record = AudioRecord.Builder()
                .setAudioFormat(pcmFormat(rate, CHANNEL_IN))
                .setBufferSizeInBytes(minIn)
                .setAudioPlaybackCaptureConfig(captureConfig)
                .build()
            if (record.state != AudioRecord.STATE_INITIALIZED) {
                record.release()
                null
            } else {
                record
            }
        } catch (t: Throwable) {
            Log.w(TAG, "AudioRecord open failed", t)
            null
        }
    }

    private fun reattach(reason: String): Boolean {
        if (!running.get()) return false
        val speaker = SpeakerRouter.findBridgeOutput(this) ?: return false
        val track = audioTrack ?: return false
        if (!track.setPreferredDevice(speaker.device)) return false
        preferredDeviceId = speaker.device.id
        routeGeneration++
        routeCheckPosted = false
        val detail = "$reason: copy routed to ${speaker.label}. Bridge stayed on."
        BridgeStatus.update(BridgeStatus.Phase.BRIDGING, detail)
        return true
    }

    private fun confirmRoute(generation: Int) {
        routeCheckPosted = false
        if (generation != routeGeneration || !running.get()) return
        if (reattach("Reconnected")) return
        BridgeStatus.update(BridgeStatus.Phase.ERROR, getString(R.string.error_disconnected))
        requestHalt()
    }

    private fun buildTrack(rate: Int, minOut: Int): AudioTrack {
        val bytes = qualityBytes(rate, minOut)
        val track = newTrack(rate, bytes, lowLatency = false)
        if (track.state != AudioTrack.STATE_INITIALIZED) {
            track.release()
            throw IllegalStateException("track")
        }
        return track
    }

    private fun newTrack(rate: Int, bufferBytes: Int, lowLatency: Boolean): AudioTrack {
        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(pcmFormat(rate, CHANNEL_OUT))
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
        if (lowLatency) {
            builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }
        return builder.build()
    }

    private fun qualityBytes(rate: Int, minOut: Int): Int {
        val fortyMs = (rate * FRAME_BYTES * 40) / 1000
        return maxOf(minOut, fortyMs).coerceAtMost((minOut * 3).coerceAtLeast(minOut))
    }

    private fun routeTo(track: AudioTrack, device: AudioDeviceInfo): Boolean {
        if (track.setPreferredDevice(device)) return true
        track.play()
        return track.setPreferredDevice(device)
    }

    private fun readChunkShorts(minBufferBytes: Int, rate: Int): Int {
        val frames = (rate / 50).coerceIn(96, 960)
        val cap = (minBufferBytes / 2).coerceAtLeast(2)
        var shorts = (frames.coerceIn(96, 480) * 2)
        if (shorts % 2 != 0) shorts--
        return shorts.coerceIn(2, cap)
    }

    private fun bufferMillis(bytes: Int, rate: Int): Int {
        if (rate <= 0) return 0
        return (bytes * 1000) / (rate * FRAME_BYTES)
    }

    private fun pcmFormat(rate: Int, channelMask: Int): AudioFormat =
        AudioFormat.Builder()
            .setEncoding(ENCODING)
            .setSampleRate(rate)
            .setChannelMask(channelMask)
            .build()

    private fun requestHalt() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            halt()
        } else {
            mainHandler.post { halt() }
        }
    }

    private fun halt() {
        synchronized(haltLock) {
            if (halted) return
            halted = true
        }
        running.set(false)
        routeGeneration++
        routeCheckPosted = false
        if (devicesRegistered) {
            try {
                SpeakerRouter.audioManager(this).unregisterAudioDeviceCallback(deviceCallback)
            } catch (_: Exception) {
            }
            devicesRegistered = false
        }
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        val thread = captureThread
        if (thread != null && thread !== Thread.currentThread()) {
            try {
                thread.join(1500)
            } catch (_: InterruptedException) {
            }
        }
        captureThread = null
        try {
            audioRecord?.release()
        } catch (_: Exception) {
        }
        audioRecord = null
        try {
            audioTrack?.pause()
        } catch (_: Exception) {
        }
        try {
            audioTrack?.flush()
        } catch (_: Exception) {
        }
        try {
            audioTrack?.stop()
        } catch (_: Exception) {
        }
        try {
            audioTrack?.release()
        } catch (_: Exception) {
        }
        audioTrack = null
        preferredDeviceId = null
        try {
            mediaProjection?.stop()
        } catch (_: Exception) {
        }
        mediaProjection = null
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        stopSelf()
    }

    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this,
            1,
            Intent(this, AudioBridgeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSmallIcon(R.drawable.ic_stat_bridge)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, getString(R.string.stop), stop)
            .build()
    }

    private fun readResultData(intent: Intent): Intent? {
        return if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
    }

    private fun messageFor(t: Throwable): String {
        return when {
            t is SecurityException -> getString(R.string.error_blocked)
            t.message == "no-speaker" -> getString(R.string.error_no_speaker)
            t.message == "route" -> getString(R.string.error_route)
            else -> getString(R.string.error_start)
        }
    }

    companion object {
        const val ACTION_START = "com.example.systemaudiobridge.START"
        const val ACTION_STOP = "com.example.systemaudiobridge.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"

        private const val TAG = "AudioBridgeService"
        private const val NOTIFICATION_ID = 42
        private const val CHANNEL_ID = "audio_bridge_channel"
        private const val CHANNEL_IN = AudioFormat.CHANNEL_IN_STEREO
        private const val CHANNEL_OUT = AudioFormat.CHANNEL_OUT_STEREO
        private const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
        private const val FRAME_BYTES = 4
    }
}
