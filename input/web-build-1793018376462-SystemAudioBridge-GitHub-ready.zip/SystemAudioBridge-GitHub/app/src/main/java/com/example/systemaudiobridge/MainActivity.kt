package com.example.systemaudiobridge

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.systemaudiobridge.databinding.ActivityMainBinding
import com.google.android.material.button.MaterialButton
import com.google.android.material.slider.Slider
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val mainHandler = Handler(Looper.getMainLooper())

    private val statusListener: (BridgeStatus.Snapshot) -> Unit = { snapshot ->
        runOnUiThread { render(snapshot) }
    }

    private val toneListener: () -> Unit = {
        runOnUiThread { renderTone() }
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) = renderSpeaker()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) = renderSpeaker()
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (missingPermissions().isEmpty() && result.values.all { it }) {
                launchProjection()
            } else {
                BridgeStatus.update(BridgeStatus.Phase.ERROR, getString(R.string.error_permission))
            }
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                val intent = Intent(this, AudioBridgeService::class.java).apply {
                    action = AudioBridgeService.ACTION_START
                    putExtra(AudioBridgeService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(AudioBridgeService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, intent)
            } else {
                BridgeStatus.update(BridgeStatus.Phase.ERROR, getString(R.string.error_projection))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MixControl.ensureInit(this)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnStartStop.setOnClickListener {
            if (BridgeStatus.snapshot().phase == BridgeStatus.Phase.BRIDGING) {
                stopBridge()
            } else {
                checkPermissionsAndStart()
            }
        }
        binding.btnOutput.setOnClickListener { openMediaOutput() }
        wireVolumes()
        wireEq()
        wireTone()
        wireSync()
        restoreControls()
    }

    override fun onStart() {
        super.onStart()
        BridgeStatus.addListener(statusListener)
        ToneEngine.addListener(toneListener)
        SpeakerRouter.audioManager(this)
            .registerAudioDeviceCallback(deviceCallback, mainHandler)
        renderSpeaker()
    }

    override fun onStop() {
        BridgeStatus.removeListener(statusListener)
        ToneEngine.removeListener(toneListener)
        if (!isChangingConfigurations) ToneEngine.stop()
        try {
            SpeakerRouter.audioManager(this).unregisterAudioDeviceCallback(deviceCallback)
        } catch (_: Exception) {
        }
        super.onStop()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val handled = super.onKeyDown(keyCode, event)
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            binding.phoneSlider.post {
                val system = SpeakerRouter.musicPercent(this)
                MixControl.phonePercent = system
                binding.phoneSlider.value = system.toFloat()
                renderVolumeReadout()
            }
        }
        return handled
    }

    private fun wireVolumes() {
        binding.phoneSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) MixControl.setPhone(this, value.toInt())
            renderVolumeReadout()
        }
        binding.btSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) MixControl.btPercent = value.toInt()
            renderVolumeReadout()
        }
        binding.phoneMinus.setOnClickListener { nudgePhone(-5) }
        binding.phonePlus.setOnClickListener { nudgePhone(5) }
        binding.btMinus.setOnClickListener { nudgeBt(-5) }
        binding.btPlus.setOnClickListener { nudgeBt(5) }
    }

    private fun wireSync() {
        binding.switchStabilize.setOnCheckedChangeListener { _, checked ->
            MixControl.stabilize = checked
        }
        binding.delaySlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) MixControl.delayMs = value.toInt()
            binding.delayValue.text = "${value.toInt()} ms"
        }
    }

    private fun nudgePhone(delta: Int) {
        val v = (MixControl.phonePercent + delta).coerceIn(0, 100)
        binding.phoneSlider.value = v.toFloat()
        MixControl.setPhone(this, v)
        renderVolumeReadout()
    }

    private fun nudgeBt(delta: Int) {
        val v = (MixControl.btPercent + delta).coerceIn(0, 100)
        binding.btSlider.value = v.toFloat()
        MixControl.btPercent = v
        renderVolumeReadout()
    }

    private fun wireEq() {
        val sliders = eqSliders()
        val readouts = eqReadouts()
        sliders.forEachIndexed { index, slider ->
            slider.addOnChangeListener { _, value, fromUser ->
                if (fromUser) MixControl.setBand(index, value)
                readouts[index].text = dbText(value)
                binding.eqCurve.gains = MixControl.eqDb
            }
        }
        binding.btnFlat.setOnClickListener { applyPreset(floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f)) }
        binding.btnBass.setOnClickListener { applyPreset(floatArrayOf(6f, 4f, 1f, 0f, 0f, 1f)) }
        binding.btnVoice.setOnClickListener { applyPreset(floatArrayOf(-2f, 0f, 3f, 4f, 2f, 0f)) }
        binding.btnBright.setOnClickListener { applyPreset(floatArrayOf(0f, -1f, 0f, 2f, 4f, 6f)) }
    }

    private fun applyPreset(values: FloatArray) {
        MixControl.setBands(values)
        eqSliders().forEachIndexed { index, slider ->
            slider.value = values[index]
        }
        binding.eqCurve.gains = MixControl.eqDb
    }

    private fun wireTone() {
        binding.btnSine.setOnClickListener { ToneEngine.wave = ToneEngine.Wave.SINE; renderTone() }
        binding.btnSquare.setOnClickListener { ToneEngine.wave = ToneEngine.Wave.SQUARE; renderTone() }
        binding.btnSaw.setOnClickListener { ToneEngine.wave = ToneEngine.Wave.SAW; renderTone() }
        binding.btnNoise.setOnClickListener { ToneEngine.wave = ToneEngine.Wave.NOISE; renderTone() }
        binding.btnDestPhone.setOnClickListener { selectDest(ToneEngine.Dest.PHONE) }
        binding.btnDestBt.setOnClickListener { selectDest(ToneEngine.Dest.BLUETOOTH) }
        binding.btnDestBoth.setOnClickListener { selectDest(ToneEngine.Dest.BOTH) }
        binding.freqSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) ToneEngine.freqHz = freqFrom(value)
            binding.freqValue.text = formatFreq(if (fromUser) ToneEngine.freqHz else freqFrom(value))
        }
        binding.btnTone.setOnClickListener { ToneEngine.toggle(this) }
    }

    private fun selectDest(dest: ToneEngine.Dest) {
        val restart = ToneEngine.playing
        ToneEngine.dest = dest
        if (restart) ToneEngine.start(this) else renderTone()
    }

    private fun restoreControls() {
        binding.phoneSlider.value = MixControl.phonePercent.toFloat()
        binding.btSlider.value = MixControl.btPercent.toFloat()
        val eq = MixControl.eqDb
        eqSliders().forEachIndexed { index, slider ->
            slider.value = eq.getOrElse(index) { 0f }
        }
        binding.eqCurve.gains = eq
        binding.freqSlider.value = sliderFromFreq(ToneEngine.freqHz)
        binding.freqValue.text = formatFreq(ToneEngine.freqHz)
        binding.switchStabilize.isChecked = MixControl.stabilize
        binding.delaySlider.value = MixControl.delayMs.toFloat()
        binding.delayValue.text = "${MixControl.delayMs} ms"
        renderVolumeReadout()
        renderTone()
    }

    private fun eqSliders(): List<Slider> = listOf(
        binding.eq60, binding.eq160, binding.eq400, binding.eq1k, binding.eq2k, binding.eq8k
    )

    private fun eqReadouts(): List<TextView> = listOf(
        binding.eq60Value, binding.eq160Value, binding.eq400Value,
        binding.eq1kValue, binding.eq2kValue, binding.eq8kValue
    )

    private fun checkPermissionsAndStart() {
        if (SpeakerRouter.findOutput(this) == null) {
            BridgeStatus.update(BridgeStatus.Phase.ERROR, getString(R.string.error_no_speaker))
            renderSpeaker()
            return
        }
        val needed = missingPermissions()
        if (needed.isEmpty()) launchProjection() else permissionLauncher.launch(needed.toTypedArray())
    }

    private fun missingPermissions(): List<String> {
        val needed = ArrayList<String>(3)
        if (!granted(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !granted(Manifest.permission.POST_NOTIFICATIONS)
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !granted(Manifest.permission.BLUETOOTH_CONNECT)
        ) {
            needed.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return needed
    }

    private fun granted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun launchProjection() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun stopBridge() {
        BridgeStatus.update(BridgeStatus.Phase.IDLE, getString(R.string.stopped))
        startService(Intent(this, AudioBridgeService::class.java).setAction(AudioBridgeService.ACTION_STOP))
    }

    private fun openMediaOutput() {
        try {
            startActivity(Intent("android.settings.panel.action.MEDIA_OUTPUT"))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            } catch (_: Exception) {
                BridgeStatus.update(
                    BridgeStatus.snapshot().phase,
                    "Open quick settings and switch media output to This phone."
                )
            }
        }
    }

    private fun render(snapshot: BridgeStatus.Snapshot) {
        val bridging = snapshot.phase == BridgeStatus.Phase.BRIDGING
        binding.btnStartStop.text = getString(if (bridging) R.string.stop else R.string.start)
        binding.btnStartStop.backgroundTintList = ColorStateList.valueOf(
            getColor(if (bridging) R.color.danger else R.color.signal)
        )
        binding.btnStartStop.setTextColor(getColor(if (bridging) R.color.fg else R.color.on_signal))
        binding.statusText.text = getString(
            when (snapshot.phase) {
                BridgeStatus.Phase.IDLE -> R.string.status_idle
                BridgeStatus.Phase.BRIDGING -> R.string.status_running
                BridgeStatus.Phase.ERROR -> R.string.status_error
            }
        )
        binding.statusText.setTextColor(
            getColor(
                when (snapshot.phase) {
                    BridgeStatus.Phase.IDLE -> R.color.muted
                    BridgeStatus.Phase.BRIDGING -> R.color.signal
                    BridgeStatus.Phase.ERROR -> R.color.danger
                }
            )
        )
        binding.detailText.text = snapshot.detail
        renderSpeaker()
    }

    private fun renderSpeaker() {
        if (!::binding.isInitialized) return
        val speaker = SpeakerRouter.findOutput(this)
        binding.speakerText.text = if (speaker == null) {
            getString(R.string.speaker_missing)
        } else {
            getString(R.string.speaker_connected, speaker.label)
        }
        binding.speakerText.setTextColor(getColor(if (speaker == null) R.color.danger else R.color.signal))
    }

    private fun renderVolumeReadout() {
        if (!::binding.isInitialized) return
        binding.phoneValue.text = "${MixControl.phonePercent}%"
        binding.btValue.text = "${MixControl.btPercent}%"
        binding.volumeHint.setText(
            if (MixControl.phonePercent < 35) R.string.hint_phone_low else R.string.hint_volumes
        )
    }

    private fun renderTone() {
        if (!::binding.isInitialized) return
        styleToggle(binding.btnSine, ToneEngine.wave == ToneEngine.Wave.SINE)
        styleToggle(binding.btnSquare, ToneEngine.wave == ToneEngine.Wave.SQUARE)
        styleToggle(binding.btnSaw, ToneEngine.wave == ToneEngine.Wave.SAW)
        styleToggle(binding.btnNoise, ToneEngine.wave == ToneEngine.Wave.NOISE)
        styleToggle(binding.btnDestPhone, ToneEngine.dest == ToneEngine.Dest.PHONE)
        styleToggle(binding.btnDestBt, ToneEngine.dest == ToneEngine.Dest.BLUETOOTH)
        styleToggle(binding.btnDestBoth, ToneEngine.dest == ToneEngine.Dest.BOTH)
        binding.btnTone.setText(if (ToneEngine.playing) R.string.stop_tone else R.string.play_tone)
        styleToggle(binding.btnTone, ToneEngine.playing)
    }

    private fun styleToggle(button: MaterialButton, on: Boolean) {
        button.backgroundTintList = ColorStateList.valueOf(getColor(if (on) R.color.signal else R.color.surface))
        button.setTextColor(getColor(if (on) R.color.on_signal else R.color.fg))
        button.strokeColor = ColorStateList.valueOf(getColor(if (on) R.color.signal else R.color.line))
    }

    private fun dbText(value: Float): String {
        val rounded = value.roundToInt()
        return if (rounded > 0) "+$rounded" else rounded.toString()
    }

    private fun freqFrom(slider: Float): Float {
        val t = (slider / 1000f).coerceIn(0f, 1f).toDouble()
        return (40.0 * Math.pow(200.0, t)).toFloat()
    }

    private fun sliderFromFreq(freq: Float): Float {
        val safe = freq.coerceIn(40f, 8000f)
        val t = ln(safe / 40f) / ln(200f)
        return (t * 1000f).roundToInt().toFloat().coerceIn(0f, 1000f)
    }

    private fun formatFreq(freq: Float): String {
        return if (freq >= 1000f) String.format("%.1f kHz", freq / 1000f) else "${freq.roundToInt()} Hz"
    }
}
