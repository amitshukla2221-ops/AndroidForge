package com.example.systemaudiobridge

import android.content.Context
import kotlin.math.abs

/**
 * Phone level is the system media stream only.
 * Bluetooth level, delay, and the stabilizer never read that stream back.
 */
object MixControl {
    val BANDS_HZ = intArrayOf(60, 160, 400, 1000, 2500, 8000)

    @Volatile var phonePercent: Int = 100
    @Volatile var btPercent: Int = 100
    @Volatile var delayMs: Int = 0
    @Volatile var stabilize: Boolean = false
    @Volatile var eqDb: FloatArray = FloatArray(BANDS_HZ.size)

    @Volatile private var ready = false

    fun ensureInit(context: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            phonePercent = SpeakerRouter.musicPercent(context)
            ready = true
        }
    }

    fun setPhone(context: Context, percent: Int) {
        val p = percent.coerceIn(0, 100)
        phonePercent = p
        SpeakerRouter.setMusicPercent(context, p)
    }

    fun setBand(index: Int, db: Float) {
        val next = eqDb.copyOf()
        next[index.coerceIn(0, next.lastIndex)] = db.coerceIn(-12f, 12f)
        eqDb = next
    }

    fun setBands(values: FloatArray) {
        val next = FloatArray(BANDS_HZ.size)
        for (i in next.indices) {
            next[i] = values.getOrElse(i) { 0f }.coerceIn(-12f, 12f)
        }
        eqDb = next
    }

    fun btGain(): Float = BridgePolicy.btLinear(btPercent)

    fun toneBluetoothGain(): Float = btGain()

    fun eqActive(): Boolean {
        val eq = eqDb
        for (v in eq) {
            if (abs(v) >= 0.25f) return true
        }
        return false
    }
}
