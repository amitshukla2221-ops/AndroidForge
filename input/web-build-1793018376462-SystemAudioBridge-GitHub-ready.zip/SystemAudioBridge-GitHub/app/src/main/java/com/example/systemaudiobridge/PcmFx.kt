package com.example.systemaudiobridge

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Peaking EQ plus gain, run on the Bluetooth copy and on generated tones.
 * State stays on the audio thread. Coefficients swap when the curve changes.
 */
class StereoEq(private val rate: Int) {
    private val bands = MixControl.BANDS_HZ
    private val left = Array(bands.size) { Biquad() }
    private val right = Array(bands.size) { Biquad() }
    private var lastEq: FloatArray? = null

    fun process(buf: ShortArray, count: Int, gain: Float) {
        if (count < 2) return
        if (gain <= 0.001f) {
            java.util.Arrays.fill(buf, 0, count, 0.toShort())
            return
        }
        val eq = MixControl.eqDb
        if (eq !== lastEq) {
            lastEq = eq
            for (i in bands.indices) {
                val db = eq.getOrElse(i) { 0f }
                left[i].setPeaking(rate, bands[i], db)
                right[i].setPeaking(rate, bands[i], db)
            }
        }
        var i = 0
        while (i + 1 < count) {
            var l = buf[i] * gain
            var r = buf[i + 1] * gain
            for (b in bands.indices) {
                l = left[b].step(l)
                r = right[b].step(r)
            }
            buf[i] = clip(l)
            buf[i + 1] = clip(r)
            i += 2
        }
    }

    private fun clip(sample: Float): Short {
        var n = sample / 32768f
        val ax = abs(n)
        if (ax > 0.72f) {
            val sign = if (n < 0f) -1f else 1f
            if (ax >= 1.4f) {
                n = sign
            } else {
                val t = (ax - 0.72f) / 0.68f
                n = sign * (0.72f + 0.28f * (t / (1f + t * 0.65f)))
            }
        }
        return (n * 32767f).toInt().coerceIn(-32767, 32767).toShort()
    }

    private class Biquad {
        private var b0 = 1f
        private var b1 = 0f
        private var b2 = 0f
        private var a1 = 0f
        private var a2 = 0f
        private var x1 = 0f
        private var x2 = 0f
        private var y1 = 0f
        private var y2 = 0f

        fun setPeaking(rate: Int, freq: Int, db: Float, q: Float = 1.15f) {
            if (abs(db) < 0.25f || rate <= 0) {
                b0 = 1f
                b1 = 0f
                b2 = 0f
                a1 = 0f
                a2 = 0f
                return
            }
            val a = 10.0.pow(db / 40.0)
            val w0 = 2.0 * PI * freq / rate
            val c = cos(w0)
            val alpha = sin(w0) / (2.0 * q)
            val bb0 = 1 + alpha * a
            val bb1 = -2 * c
            val bb2 = 1 - alpha * a
            val aa0 = 1 + alpha / a
            b0 = (bb0 / aa0).toFloat()
            b1 = (bb1 / aa0).toFloat()
            b2 = (bb2 / aa0).toFloat()
            a1 = ((-2 * c) / aa0).toFloat()
            a2 = ((1 - alpha / a) / aa0).toFloat()
        }

        fun step(x: Float): Float {
            val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1
            x1 = x
            y2 = y1
            y1 = y
            return y
        }
    }
}
