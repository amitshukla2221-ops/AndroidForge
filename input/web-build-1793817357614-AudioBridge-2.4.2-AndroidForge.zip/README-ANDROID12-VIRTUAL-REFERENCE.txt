SYSTEM AUDIO BRIDGE 2.4.2 — SILENT REFERENCE + ECHO-SUPPRESSION TEST

DESIGN
- Captures eligible media/game/unknown audio from other apps using Android AudioPlaybackCapture.
- One shared capture ring buffer feeds two independent output readers.
- The silent reference is a software timing clock only. It does not create an audible third output and does not need a full-volume AudioTrack.
- Tablet speaker and Bluetooth copies retain independent delay, gain/mute and EQ controls.
- Sync is manual buffer offset, not automatic measurement of acoustic latency.

ECHO-SUPPRESSION CHANGE
- Once capture is audible and both output tracks are present, the service temporarily suppresses the original STREAM_MUSIC route so the default output does not also play the unbuffered original on top of its bridge copy.
- It checks capture shortly afterwards. If this Android 12 device also silences playback capture when STREAM_MUSIC is muted, it restores the original media volume and disables further mute attempts for that session. This preserves playback but means echo can remain on devices with that behavior.
- The saved media volume is restored when the bridge stops or the service exits.

LIMITS / VERIFICATION
- Some apps prohibit playback capture; those apps cannot be copied.
- Android 12 devices vary in whether muting STREAM_MUSIC also mutes captured audio. The safety check handles the observed failure mode, but only a real-device test can establish whether the tablet supports echo-free dual-copy playback.
- Logic tests cover manual delay math, reader recovery and software gain. They do not test Android routing or acoustic synchronization.

ANDROIDFORGE
- ZIP root contains settings.gradle and build.gradle; upload the ZIP as a Gradle project.
- applicationId and signing key are retained for update compatibility with the 2.4.x project.
- versionName 2.4.2, versionCode 242.
