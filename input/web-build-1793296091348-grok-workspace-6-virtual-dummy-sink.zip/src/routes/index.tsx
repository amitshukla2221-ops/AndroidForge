import { createFileRoute } from "@tanstack/react-router";
import { AudioLines, Bluetooth, Download, SlidersHorizontal, Speaker } from "lucide-react";
import type { ReactNode } from "react";

export const Route = createFileRoute("/")({ component: Home });

const APK = "/SystemAudioBridge-2.1.0.apk";

function Home() {
  return (
    <main className="mx-auto min-h-screen max-w-3xl px-5 py-10 sm:px-8 sm:py-16">
      <p className="text-xs font-medium tracking-[0.22em] text-primary uppercase">Version 2.1.0</p>
      <h1 className="font-display mt-3 text-5xl leading-none font-medium text-fg sm:text-6xl">
        System Audio Bridge
      </h1>
      <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted">
        One capture of whatever is playing. A silent primary that adds nothing. Two full copies —
        Honor Pad speaker and Bluetooth speaker — each with its own sync and equalizer.
      </p>

      <a
        href={APK}
        download="SystemAudioBridge-2.1.0.apk"
        className="mt-8 inline-flex min-h-12 items-center gap-3 rounded-2xl bg-primary px-5 py-3 text-base font-semibold text-primary-ink no-underline"
      >
        <Download className="size-5" aria-hidden />
        Download APK
        <span className="font-medium opacity-70">45 KB</span>
      </a>
      <p className="mt-3 text-sm text-muted">Android 10 or newer. Installs over 2.0.0. Uninstall 1.3 or 1.4 first if Android reports a conflict.</p>

      <section className="mt-12 grid gap-3 sm:grid-cols-3">
        <Card icon={<Speaker className="size-5" aria-hidden />} title="Both outputs stay up" body="The bridge does not mute media volume unless both copies are already playing on a stream that ignores it." />
        <Card icon={<AudioLines className="size-5" aria-hidden />} title="Sync, forward or delay" body="Each side runs from −500 ms to +500 ms. Positive waits. Negative plays that speaker sooner." />
        <Card icon={<SlidersHorizontal className="size-5" aria-hidden />} title="Separate equalizers" body="Five bands per output. Flat leaves the audio untouched. Bass, Vocal, Treble, and Music are starting points." />
      </section>

      <section className="mt-10 rounded-card border border-line bg-surface p-5 sm:p-7">
        <h2 className="font-display text-3xl font-medium">Install on the Pad</h2>
        <ol className="mt-4 space-y-3 text-base leading-relaxed text-fg">
          <li className="flex gap-3"><Step n="1" />Download the file, then open it from the notification or the Files app.</li>
          <li className="flex gap-3"><Step n="2" />If the tablet blocks it: Settings, Security, More settings, Install unknown apps, and allow the browser you used.</li>
          <li className="flex gap-3"><Step n="3" />Open Audio Bridge. Tap Start. Allow microphone, nearby Bluetooth, and notifications. On the capture screen, allow it and include audio.</li>
          <li className="flex gap-3"><Step n="4" />Play music in another app. The tablet speaker and the Bluetooth speaker should both receive the copy.</li>
          <li className="flex gap-3"><Step n="5" />If the room smears, move Sync until the echo disappears. Shape each speaker on its own faders. Flat is the clean setting.</li>
        </ol>
      </section>

      <section className="mt-6 rounded-card border border-line bg-surface p-5 sm:p-7">
        <div className="flex items-center gap-2 text-primary">
          <Bluetooth className="size-5" aria-hidden />
          <h2 className="font-display text-3xl font-medium text-fg">How the sound is kept clean</h2>
        </div>
        <ul className="mt-4 space-y-2 text-base leading-relaxed text-muted">
          <li>Capture is 48 kHz stereo. With the equalizer on Flat and level at full, the copy is not reprocessed.</li>
          <li>A boosted band runs through a soft limiter so it bends instead of crackling.</li>
          <li>The silent primary writes digital silence and does not carry the program.</li>
          <li>Bluetooth speakers are preferred over earbuds when both are connected. Only one Bluetooth music device can play at a time.</li>
          <li>Stopping the bridge puts the media volume back if it was changed.</li>
        </ul>
      </section>
    </main>
  );
}

function Card({ icon, title, body }: { icon: ReactNode; title: string; body: string }) {
  return (
    <article className="rounded-card border border-line bg-surface p-4">
      <div className="text-primary">{icon}</div>
      <h2 className="mt-3 text-base font-semibold text-fg">{title}</h2>
      <p className="mt-1 text-sm leading-relaxed text-muted">{body}</p>
    </article>
  );
}

function Step({ n }: { n: string }) {
  return (
    <span className="mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-ink">
      {n}
    </span>
  );
}
