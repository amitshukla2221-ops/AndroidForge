import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Bluetooth, i as Download, n as Speaker, o as AudioLines, r as SlidersHorizontal } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CohfUUC8.js
var import_jsx_runtime = require_jsx_runtime();
var APK = "/SystemAudioBridge-2.1.0.apk";
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-3xl px-5 py-10 sm:px-8 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-[0.22em] text-primary uppercase",
				children: "Version 2.1.0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-3 text-5xl leading-none font-medium text-fg sm:text-6xl",
				children: "System Audio Bridge"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-xl text-lg leading-relaxed text-muted",
				children: "One capture of whatever is playing. A silent primary that adds nothing. Two full copies — Honor Pad speaker and Bluetooth speaker — each with its own sync and equalizer."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: APK,
				download: "SystemAudioBridge-2.1.0.apk",
				className: "mt-8 inline-flex min-h-12 items-center gap-3 rounded-2xl bg-primary px-5 py-3 text-base font-semibold text-primary-ink no-underline",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
						className: "size-5",
						"aria-hidden": true
					}),
					"Download APK",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium opacity-70",
						children: "45 KB"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Android 10 or newer. Installs over 2.0.0. Uninstall 1.3 or 1.4 first if Android reports a conflict."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12 grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Speaker, {
							className: "size-5",
							"aria-hidden": true
						}),
						title: "Both outputs stay up",
						body: "The bridge does not mute media volume unless both copies are already playing on a stream that ignores it."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, {
							className: "size-5",
							"aria-hidden": true
						}),
						title: "Sync, forward or delay",
						body: "Each side runs from −500 ms to +500 ms. Positive waits. Negative plays that speaker sooner."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
							className: "size-5",
							"aria-hidden": true
						}),
						title: "Separate equalizers",
						body: "Five bands per output. Flat leaves the audio untouched. Bass, Vocal, Treble, and Music are starting points."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 rounded-card border border-line bg-surface p-5 sm:p-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl font-medium",
					children: "Install on the Pad"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-4 space-y-3 text-base leading-relaxed text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "1" }), "Download the file, then open it from the notification or the Files app."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "2" }), "If the tablet blocks it: Settings, Security, More settings, Install unknown apps, and allow the browser you used."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "3" }), "Open Audio Bridge. Tap Start. Allow microphone, nearby Bluetooth, and notifications. On the capture screen, allow it and include audio."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "4" }), "Play music in another app. The tablet speaker and the Bluetooth speaker should both receive the copy."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, { n: "5" }), "If the room smears, move Sync until the echo disappears. Shape each speaker on its own faders. Flat is the clean setting."]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-card border border-line bg-surface p-5 sm:p-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bluetooth, {
						className: "size-5",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-medium text-fg",
						children: "How the sound is kept clean"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2 text-base leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Capture is 48 kHz stereo. With the equalizer on Flat and level at full, the copy is not reprocessed." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A boosted band runs through a soft limiter so it bends instead of crackling." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The silent primary writes digital silence and does not carry the program." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Bluetooth speakers are preferred over earbuds when both are connected. Only one Bluetooth music device can play at a time." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stopping the bridge puts the media volume back if it was changed." })
					]
				})]
			})
		]
	});
}
function Card({ icon, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-primary",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-base font-semibold text-fg",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: body
			})
		]
	});
}
function Step({ n }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-ink",
		children: n
	});
}
//#endregion
export { Home as component };
