//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DXIbmbs-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-xwGo3RHe.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-xwGo3RHe.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-2MSnlwtQ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
