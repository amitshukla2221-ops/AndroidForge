#!/bin/sh
set -eu
ROOT="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_SDK_ROOT:-/tmp/sdk}"
BT="$SDK/android-14"
JAR="$SDK/android-34-ext12/android.jar"
OUT="$ROOT/build"
rm -rf "$OUT"
mkdir -p "$OUT/compiled" "$OUT/classes" "$OUT/gen" "$OUT/dex"

"$BT/aapt2" compile --dir "$ROOT/res" -o "$OUT/compiled/resources.zip"
"$BT/aapt2" link -o "$OUT/linked.apk" \
  -I "$JAR" \
  --manifest "$ROOT/AndroidManifest.xml" \
  --java "$OUT/gen" \
  --min-sdk-version 29 \
  --target-sdk-version 34 \
  --version-code 210 \
  --version-name 2.1.0 \
  "$OUT/compiled/resources.zip"

javac --release 11 -classpath "$JAR" -d "$OUT/classes" \
  $(find "$ROOT/src" "$OUT/gen" -name '*.java')

"$BT/d8" --min-api 29 --output "$OUT/dex" $(find "$OUT/classes" -name '*.class')

cp "$OUT/linked.apk" "$OUT/unsigned.apk"
python3 - "$OUT/unsigned.apk" "$OUT/dex/classes.dex" <<'PY'
import sys, zipfile
apk, dex = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(apk, "a", compression=zipfile.ZIP_DEFLATED) as z:
    z.write(dex, "classes.dex")
PY
"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

KS="$ROOT/bridge-release.keystore"
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -storepass bridgepass -keypass bridgepass \
    -alias bridge -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=System Audio Bridge, O=Audio Bridge, C=US"
fi
"$BT/apksigner" sign --ks "$KS" --ks-pass pass:bridgepass --key-pass pass:bridgepass \
  --v1-signing-enabled false --v2-signing-enabled true --v3-signing-enabled true \
  --out "$OUT/SystemAudioBridge-2.1.0.apk" "$OUT/aligned.apk"
"$BT/apksigner" verify --verbose "$OUT/SystemAudioBridge-2.1.0.apk"
echo "BUILT $OUT/SystemAudioBridge-2.1.0.apk"
