package com.example.systemaudiobridge;

public final class Pcm {
    private Pcm() {
    }

    public static void toFloat(short[] in, int count, float[] out) {
        for (int i = 0; i < count; i++) {
            out[i] = in[i] / 32768f;
        }
    }

    /** Soft knee so a boosted EQ bends instead of wrapping into crackle. */
    public static float limit(float x) {
        float ax = x < 0f ? -x : x;
        if (ax <= 0.89f) {
            return x;
        }
        float y = 0.89f + (ax - 0.89f) / (1f + (ax - 0.89f) * 6f);
        if (y > 0.999f) {
            y = 0.999f;
        }
        return x < 0f ? -y : y;
    }

    public static void toShort(float[] in, int count, short[] out, int[] ditherState) {
        int state = ditherState[0];
        for (int i = 0; i < count; i++) {
            float x = limit(in[i]);
            int r1 = state * 1664525 + 1013904223;
            int r2 = r1 * 1664525 + 1013904223;
            state = r2;
            float dither = ((r1 >>> 8) / 16777216f) - ((r2 >>> 8) / 16777216f);
            int v = Math.round(x * 32768f + dither);
            if (v > 32767) {
                v = 32767;
            } else if (v < -32768) {
                v = -32768;
            }
            out[i] = (short) v;
        }
        ditherState[0] = state;
    }

    public static void silence(short[] samples, int count) {
        for (int i = 0; i < count; i++) {
            samples[i] = 0;
        }
    }

    public static void fadeIn(short[] samples, int count, int frames) {
        int pairs = count >> 1;
        int n = frames < pairs ? frames : pairs;
        if (n <= 1) {
            return;
        }
        for (int i = 0; i < n; i++) {
            float g = i / (float) n;
            int l = Math.round(samples[i * 2] * g);
            int r = Math.round(samples[i * 2 + 1] * g);
            samples[i * 2] = (short) l;
            samples[i * 2 + 1] = (short) r;
        }
    }

    public static boolean audible(short[] samples, int count) {
        if (samples == null || count <= 0) {
            return false;
        }
        int peaks = 0;
        long sum = 0;
        int n = 0;
        for (int i = 0; i < count; i += 4) {
            int v = samples[i];
            if (v < 0) {
                v = -v;
            }
            if (v > 500) {
                peaks++;
            }
            sum += (long) v * (long) v;
            n++;
        }
        if (n == 0) {
            return false;
        }
        return peaks >= 6 || (sum / n) > 1200L;
    }
}
