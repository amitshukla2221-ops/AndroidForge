package com.example.systemaudiobridge;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Five vertical graphic-EQ faders. +12 dB at the top, −12 at the bottom, 0 in the center. */
public final class EqFaderView extends View {
    public interface Listener {
        void onBand(int index, int db, boolean done);
    }

    private final int[] bands = new int[EqPresets.BANDS];
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint zero = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumb = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint value = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private Listener listener;
    private int drag = -1;

    public EqFaderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        track.setColor(0xFF243140);
        fill.setColor(0xFF1DE0C4);
        zero.setColor(0x66E7B15A);
        thumb.setColor(0xFFE7EEF4);
        label.setColor(0xFF8EA0B0);
        label.setTextAlign(Paint.Align.CENTER);
        label.setTextSize(sp(11));
        value.setColor(0xFFE7EEF4);
        value.setTextAlign(Paint.Align.CENTER);
        value.setTextSize(sp(12));
        setClickable(true);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setBands(int[] db) {
        if (drag >= 0 || db == null) {
            return;
        }
        for (int i = 0; i < bands.length && i < db.length; i++) {
            bands[i] = EqPresets.clampDb(db[i]);
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float labelH = sp(16);
        float valueH = sp(16);
        float top = valueH + dp(4);
        float bottom = h - labelH - dp(6);
        float trackH = bottom - top;
        if (trackH < dp(40)) {
            return;
        }
        float col = w / EqPresets.BANDS;
        float mid = top + trackH / 2f;
        for (int i = 0; i < EqPresets.BANDS; i++) {
            float cx = col * i + col / 2f;
            float barW = Math.min(dp(10), col * 0.28f);
            rect.set(cx - barW / 2f, top, cx + barW / 2f, bottom);
            canvas.drawRoundRect(rect, barW, barW, track);
            canvas.drawLine(cx - dp(14), mid, cx + dp(14), mid, zero);
            float t = (12 - bands[i]) / 24f;
            float y = top + trackH * t;
            rect.set(cx - barW / 2f, Math.min(y, mid), cx + barW / 2f, Math.max(y, mid));
            canvas.drawRoundRect(rect, barW, barW, fill);
            canvas.drawCircle(cx, y, dp(8), thumb);
            String db = bands[i] > 0 ? "+" + bands[i] : String.valueOf(bands[i]);
            canvas.drawText(db, cx, valueH, value);
            canvas.drawText(freqLabel(i), cx, h - dp(2), label);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN
                || action == MotionEvent.ACTION_MOVE
                || action == MotionEvent.ACTION_UP
                || action == MotionEvent.ACTION_CANCEL) {
            int index = column(event.getX());
            if (action == MotionEvent.ACTION_DOWN) {
                drag = index;
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            if (drag >= 0) {
                int db = dbAt(event.getY());
                if (bands[drag] != db) {
                    bands[drag] = db;
                    invalidate();
                    if (listener != null) {
                        listener.onBand(drag, db, false);
                    }
                }
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                if (listener != null && drag >= 0) {
                    listener.onBand(drag, bands[drag], true);
                }
                drag = -1;
            }
            return true;
        }
        return super.onTouchEvent(event);
    }

    private int column(float x) {
        int index = (int) (x / (getWidth() / (float) EqPresets.BANDS));
        if (index < 0) {
            return 0;
        }
        if (index >= EqPresets.BANDS) {
            return EqPresets.BANDS - 1;
        }
        return index;
    }

    private int dbAt(float y) {
        float top = sp(16) + dp(4);
        float bottom = getHeight() - sp(16) - dp(6);
        float t = (y - top) / (bottom - top);
        if (t < 0f) {
            t = 0f;
        }
        if (t > 1f) {
            t = 1f;
        }
        return EqPresets.clampDb(Math.round(12f - t * 24f));
    }

    private static String freqLabel(int index) {
        int f = GraphicEq.FREQS[index];
        if (f >= 1000) {
            return (f / 1000) + "k";
        }
        return String.valueOf(f);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private float sp(float value) {
        return value * getResources().getDisplayMetrics().scaledDensity;
    }
}
