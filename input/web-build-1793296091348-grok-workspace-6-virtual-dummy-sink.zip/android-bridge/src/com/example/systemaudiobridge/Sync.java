package com.example.systemaudiobridge;

/** Relative sync. Negative shift plays that output sooner; positive makes it wait. */
public final class Sync {
    public static final int MAX_MS = 500;
    /** Cushion so both readers stay behind the capture writer. */
    public static final int BASE_MS = 180;

    private Sync() {
    }

    public static int clamp(int value) {
        if (value < -MAX_MS) {
            return -MAX_MS;
        }
        if (value > MAX_MS) {
            return MAX_MS;
        }
        return value;
    }

    /**
     * How far behind the capture writer this side should read, in milliseconds.
     * The earlier side keeps {@link #BASE_MS}. The later side waits the difference.
     */
    public static int absoluteDelayMs(int thisShift, int otherShift) {
        int mine = clamp(thisShift);
        int other = clamp(otherShift);
        int earliest = mine < other ? mine : other;
        return BASE_MS + (mine - earliest);
    }

    public static int delayFrames(int sampleRate, int delayMs) {
        if (sampleRate <= 0 || delayMs <= 0) {
            return 0;
        }
        return (int) ((long) sampleRate * (long) delayMs / 1000L);
    }
}
