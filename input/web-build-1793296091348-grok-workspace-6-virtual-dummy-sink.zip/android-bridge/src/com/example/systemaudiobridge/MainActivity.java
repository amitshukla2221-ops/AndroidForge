package com.example.systemaudiobridge;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.ArrayList;

public final class MainActivity extends Activity {
    private static final int REQ_PERMS = 7;
    private static final int REQ_CAPTURE = 8;

    private TextView statusView;
    private TextView hearingView;
    private TextView pathView;
    private TextView primaryView;
    private TextView originalView;
    private TextView speakerRoute;
    private TextView btName;
    private TextView speakerVolVal;
    private TextView btVolVal;
    private TextView speakerSyncVal;
    private TextView btSyncVal;
    private SeekBar speakerVol;
    private SeekBar btVol;
    private SeekBar speakerSync;
    private SeekBar btSync;
    private Button speakerMute;
    private Button btMute;
    private Button toggle;
    private EqFaderView speakerEq;
    private EqFaderView btEq;
    private LinearLayout speakerPresets;
    private LinearLayout btPresets;
    private boolean dragSpeakerVol;
    private boolean dragBtVol;
    private boolean dragSpeakerSync;
    private boolean dragBtSync;

    private final BridgeBus.Listener listener = new BridgeBus.Listener() {
        @Override
        public void onChange() {
            render();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!MixState.running) {
            SystemSilence.recoverAbandoned(this);
            Prefs.load(this);
        }
        setContentView(R.layout.activity_main);
        statusView = (TextView) findViewById(R.id.status);
        hearingView = (TextView) findViewById(R.id.hearing);
        pathView = (TextView) findViewById(R.id.path);
        primaryView = (TextView) findViewById(R.id.primary_label);
        originalView = (TextView) findViewById(R.id.original_label);
        speakerRoute = (TextView) findViewById(R.id.speaker_route);
        btName = (TextView) findViewById(R.id.bt_name);
        speakerVol = (SeekBar) findViewById(R.id.speaker_vol);
        btVol = (SeekBar) findViewById(R.id.bt_vol);
        speakerSync = (SeekBar) findViewById(R.id.speaker_sync);
        btSync = (SeekBar) findViewById(R.id.bt_sync);
        speakerVolVal = (TextView) findViewById(R.id.speaker_vol_val);
        btVolVal = (TextView) findViewById(R.id.bt_vol_val);
        speakerSyncVal = (TextView) findViewById(R.id.speaker_sync_val);
        btSyncVal = (TextView) findViewById(R.id.bt_sync_val);
        speakerMute = (Button) findViewById(R.id.speaker_mute);
        btMute = (Button) findViewById(R.id.bt_mute);
        toggle = (Button) findViewById(R.id.toggle);
        speakerEq = (EqFaderView) findViewById(R.id.speaker_eq);
        btEq = (EqFaderView) findViewById(R.id.bt_eq);
        speakerPresets = (LinearLayout) findViewById(R.id.speaker_presets);
        btPresets = (LinearLayout) findViewById(R.id.bt_presets);

        speakerVol.setMax(100);
        btVol.setMax(100);
        speakerSync.setMax(1000);
        btSync.setMax(1000);
        speakerVol.setOnSeekBarChangeListener(volumeListener(true));
        btVol.setOnSeekBarChangeListener(volumeListener(false));
        speakerSync.setOnSeekBarChangeListener(syncListener(true));
        btSync.setOnSeekBarChangeListener(syncListener(false));
        speakerEq.setListener(eqListener(true));
        btEq.setListener(eqListener(false));
        buildPresets(speakerPresets, true);
        buildPresets(btPresets, false);

        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onToggle();
            }
        });
        speakerMute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MixState.speakerMuted = !MixState.speakerMuted;
                Prefs.save(MainActivity.this);
                render();
            }
        });
        btMute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MixState.btMuted = !MixState.btMuted;
                Prefs.save(MainActivity.this);
                render();
            }
        });
        findViewById(R.id.reset_sync).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MixState.speakerShiftMs = 0;
                MixState.btShiftMs = 0;
                Prefs.save(MainActivity.this);
                render();
            }
        });
        render();
    }

    @Override
    protected void onStart() {
        super.onStart();
        BridgeBus.listen(listener);
        render();
    }

    @Override
    protected void onStop() {
        BridgeBus.unlisten(listener);
        Prefs.save(this);
        super.onStop();
    }

    private void buildPresets(LinearLayout row, final boolean speaker) {
        int gap = dp(8);
        for (int i = 0; i < EqPresets.NAMES.length; i++) {
            final String name = EqPresets.NAMES[i];
            Button chip = new Button(this);
            chip.setText(name);
            chip.setAllCaps(false);
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            chip.setMinWidth(0);
            chip.setMinimumWidth(0);
            chip.setMinHeight(dp(40));
            chip.setMinimumHeight(dp(40));
            chip.setPadding(dp(14), 0, dp(14), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(40));
            lp.setMarginEnd(gap);
            chip.setLayoutParams(lp);
            chip.setTag(name);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (speaker) {
                        MixState.applySpeakerPreset(name);
                    } else {
                        MixState.applyBtPreset(name);
                    }
                    Prefs.save(MainActivity.this);
                    render();
                }
            });
            row.addView(chip);
        }
    }

    private EqFaderView.Listener eqListener(final boolean speaker) {
        return new EqFaderView.Listener() {
            @Override
            public void onBand(int index, int db, boolean done) {
                if (speaker) {
                    MixState.setSpeakerBand(index, db);
                } else {
                    MixState.setBtBand(index, db);
                }
                paintChips(speaker ? speakerPresets : btPresets, speaker ? MixState.speakerPreset : MixState.btPreset);
                if (done) {
                    Prefs.save(MainActivity.this);
                }
            }
        };
    }

    private SeekBar.OnSeekBarChangeListener volumeListener(final boolean speaker) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) {
                    return;
                }
                if (speaker) {
                    MixState.speakerVolume = progress;
                    speakerVolVal.setText(progress + "%");
                } else {
                    MixState.btVolume = progress;
                    btVolVal.setText(progress + "%");
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (speaker) {
                    dragSpeakerVol = true;
                } else {
                    dragBtVol = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (speaker) {
                    dragSpeakerVol = false;
                } else {
                    dragBtVol = false;
                }
                Prefs.save(MainActivity.this);
            }
        };
    }

    private SeekBar.OnSeekBarChangeListener syncListener(final boolean speaker) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) {
                    return;
                }
                int ms = progress - Sync.MAX_MS;
                if (speaker) {
                    MixState.speakerShiftMs = Sync.clamp(ms);
                    speakerSyncVal.setText(syncText(MixState.speakerShiftMs));
                } else {
                    MixState.btShiftMs = Sync.clamp(ms);
                    btSyncVal.setText(syncText(MixState.btShiftMs));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (speaker) {
                    dragSpeakerSync = true;
                } else {
                    dragBtSync = true;
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (speaker) {
                    dragSpeakerSync = false;
                } else {
                    dragBtSync = false;
                }
                Prefs.save(MainActivity.this);
            }
        };
    }

    private void onToggle() {
        if (MixState.running) {
            Intent stop = new Intent(this, AudioBridgeService.class);
            stop.setAction(AudioBridgeService.ACTION_STOP);
            startService(stop);
            return;
        }
        Prefs.save(this);
        ArrayList<String> needed = new ArrayList<String>();
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(android.Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 31
                && checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            needed.add(android.Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            needed.add(android.Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!needed.isEmpty()) {
            requestPermissions(needed.toArray(new String[0]), REQ_PERMS);
        } else {
            launchCapture();
        }
    }

    private void launchCapture() {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) {
            return;
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            statusView.setText("Audio capture permission is required.");
            return;
        }
        launchCapture();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) {
            return;
        }
        if (resultCode != RESULT_OK || data == null) {
            statusView.setText("Capture cancelled.");
            return;
        }
        Intent start = new Intent(this, AudioBridgeService.class);
        start.setAction(AudioBridgeService.ACTION_START);
        start.putExtra(AudioBridgeService.EXTRA_CODE, resultCode);
        start.putExtra(AudioBridgeService.EXTRA_DATA, data);
        startForegroundService(start);
        statusView.setText("Starting bridge…");
    }

    private void render() {
        if (!dragSpeakerVol) {
            speakerVol.setProgress(MixState.speakerVolume);
            speakerVolVal.setText(MixState.speakerVolume + "%");
        }
        if (!dragBtVol) {
            btVol.setProgress(MixState.btVolume);
            btVolVal.setText(MixState.btVolume + "%");
        }
        if (!dragSpeakerSync) {
            speakerSync.setProgress(MixState.speakerShiftMs + Sync.MAX_MS);
            speakerSyncVal.setText(syncText(MixState.speakerShiftMs));
        }
        if (!dragBtSync) {
            btSync.setProgress(MixState.btShiftMs + Sync.MAX_MS);
            btSyncVal.setText(syncText(MixState.btShiftMs));
        }
        int[] speakerBands = new int[EqPresets.BANDS];
        int[] btBands = new int[EqPresets.BANDS];
        MixState.copySpeakerEq(speakerBands);
        MixState.copyBtEq(btBands);
        speakerEq.setBands(speakerBands);
        btEq.setBands(btBands);
        paintChips(speakerPresets, MixState.speakerPreset);
        paintChips(btPresets, MixState.btPreset);
        speakerMute.setText(MixState.speakerMuted ? "Unmute speaker copy" : "Mute speaker copy");
        btMute.setText(MixState.btMuted ? "Unmute Bluetooth copy" : "Mute Bluetooth copy");
        statusView.setText(MixState.status == null ? "" : MixState.status);
        primaryView.setText(MixState.primaryLabel);
        originalView.setText(MixState.originalLabel);
        speakerRoute.setText(MixState.speakerRoute);
        btName.setText(MixState.btRoute);
        if (MixState.path != null && MixState.path.length() > 0) {
            pathView.setText(MixState.path);
        }
        if (!MixState.running) {
            toggle.setText("Start bridge");
            hearingView.setText("Bridge is off");
            hearingView.setTextColor(0xFFFFB4A8);
            return;
        }
        toggle.setText("Stop bridge");
        if (MixState.hearing) {
            hearingView.setText(MixState.originalQuiet ? "Hearing audio · original quiet" : "Hearing audio");
            hearingView.setTextColor(0xFF7DDEA2);
        } else {
            hearingView.setText("Running · quiet");
            hearingView.setTextColor(0xFFE7B15A);
        }
    }

    private void paintChips(LinearLayout row, String selected) {
        int n = row.getChildCount();
        for (int i = 0; i < n; i++) {
            View child = row.getChildAt(i);
            if (!(child instanceof Button)) {
                continue;
            }
            Button chip = (Button) child;
            boolean on = chip.getText().toString().equals(selected);
            chip.setBackgroundResource(on ? R.drawable.bg_chip_on : R.drawable.bg_chip);
            chip.setTextColor(on ? 0xFF06211C : 0xFFE7EEF4);
        }
    }

    private static String syncText(int ms) {
        if (ms == 0) {
            return "0 ms";
        }
        if (ms > 0) {
            return "+" + ms + " ms";
        }
        return "\u2212" + (-ms) + " ms";
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
