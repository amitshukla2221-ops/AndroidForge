package com.example.systemaudiobridge;

/**
 * Stereo five-band peaking EQ. Unity bands are skipped so a flat setting
 * does not touch the samples at all.
 */
public final class GraphicEq {
    public static final int[] FREQS = {60, 250, 1000, 4000, 12000};
    private static final double Q = 1.05;

    private final int rate;
    private final Biquad[] left = new Biquad[EqPresets.BANDS];
    private final Biquad[] right = new Biquad[EqPresets.BANDS];
    private final int[] current = new int[EqPresets.BANDS];
    private final int[] target = new int[EqPresets.BANDS];
    private boolean flat = true;

    public GraphicEq(int sampleRate) {
        rate = sampleRate < 8000 ? 48000 : sampleRate;
        for (int i = 0; i < EqPresets.BANDS; i++) {
            left[i] = new Biquad();
            right[i] = new Biquad();
            design(i, 0);
        }
    }

    public boolean isFlat() {
        return flat;
    }

    public void setTargets(int[] db) {
        boolean allZero = true;
        for (int i = 0; i < EqPresets.BANDS; i++) {
            int v = db == null ? 0 : EqPresets.clampDb(db[i]);
            target[i] = v;
            if (v != 0 || current[i] != 0) {
                allZero = false;
            }
        }
        flat = allZero;
    }

    /** Jump straight to these gains. Used by tests and by the first buffer. */
    public void setImmediate(int[] db) {
        setTargets(db);
        for (int i = 0; i < EqPresets.BANDS; i++) {
            if (current[i] != target[i]) {
                current[i] = target[i];
                design(i, current[i]);
            }
        }
        flat = true;
        for (int i = 0; i < EqPresets.BANDS; i++) {
            if (current[i] != 0) {
                flat = false;
                break;
            }
        }
    }

    public void process(float[] interleaved, int count) {
        slew();
        if (flat) {
            return;
        }
        int pairs = count >> 1;
        for (int i = 0; i < pairs; i++) {
            int p = i * 2;
            float l = interleaved[p];
            float r = interleaved[p + 1];
            for (int b = 0; b < EqPresets.BANDS; b++) {
                if (current[b] == 0) {
                    continue;
                }
                l = left[b].step(l);
                r = right[b].step(r);
            }
            interleaved[p] = l;
            interleaved[p + 1] = r;
        }
    }

    private void slew() {
        boolean allZero = true;
        for (int i = 0; i < EqPresets.BANDS; i++) {
            int c = current[i];
            int t = target[i];
            if (c != t) {
                int next = c < t ? c + 1 : c - 1;
                current[i] = next;
                design(i, next);
                c = next;
            }
            if (c != 0) {
                allZero = false;
            }
        }
        flat = allZero;
    }

    private void design(int band, int db) {
        double freq = FREQS[band];
        double nyquist = rate * 0.45;
        if (freq > nyquist) {
            freq = nyquist;
        }
        if (db == 0) {
            left[band].reset();
            right[band].reset();
            left[band].unity();
            right[band].unity();
            return;
        }
        double a = Math.pow(10.0, db / 40.0);
        double w0 = 2.0 * Math.PI * freq / rate;
        double cw = Math.cos(w0);
        double alpha = Math.sin(w0) / (2.0 * Q);
        double b0 = 1.0 + alpha * a;
        double b1 = -2.0 * cw;
        double b2 = 1.0 - alpha * a;
        double a0 = 1.0 + alpha / a;
        double a1 = -2.0 * cw;
        double a2 = 1.0 - alpha / a;
        left[band].set(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0);
        right[band].set(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0);
    }

    private static final class Biquad {
        float b0 = 1f;
        float b1;
        float b2;
        float a1;
        float a2;
        float z1;
        float z2;

        void unity() {
            b0 = 1f;
            b1 = 0f;
            b2 = 0f;
            a1 = 0f;
            a2 = 0f;
        }

        void reset() {
            z1 = 0f;
            z2 = 0f;
        }

        void set(double nb0, double nb1, double nb2, double na1, double na2) {
            b0 = (float) nb0;
            b1 = (float) nb1;
            b2 = (float) nb2;
            a1 = (float) na1;
            a2 = (float) na2;
        }

        void copyFrom(Biquad other) {
            b0 = other.b0;
            b1 = other.b1;
            b2 = other.b2;
            a1 = other.a1;
            a2 = other.a2;
            z1 = 0f;
            z2 = 0f;
        }

        float step(float x) {
            float y = b0 * x + z1;
            z1 = b1 * x - a1 * y + z2;
            z2 = b2 * x - a2 * y;
            if (z1 > -1e-20f && z1 < 1e-20f) {
                z1 = 0f;
            }
            if (z2 > -1e-20f && z2 < 1e-20f) {
                z2 = 0f;
            }
            return y;
        }
    }
}
