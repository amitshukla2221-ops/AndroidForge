package com.example.systemaudiobridge;

import android.os.Handler;
import android.os.Looper;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class BridgeBus {
    public interface Listener {
        void onChange();
    }

    private static final List<Listener> LISTENERS = new CopyOnWriteArrayList<Listener>();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private BridgeBus() {
    }

    public static void listen(Listener listener) {
        if (listener != null && !LISTENERS.contains(listener)) {
            LISTENERS.add(listener);
        }
    }

    public static void unlisten(Listener listener) {
        LISTENERS.remove(listener);
    }

    public static void post() {
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                Iterator<Listener> it = LISTENERS.iterator();
                while (it.hasNext()) {
                    it.next().onChange();
                }
            }
        });
    }
}
