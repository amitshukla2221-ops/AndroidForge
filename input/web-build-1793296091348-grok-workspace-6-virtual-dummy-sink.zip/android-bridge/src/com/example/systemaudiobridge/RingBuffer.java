package com.example.systemaudiobridge;

/** Stereo interleaved ring. Each output keeps its own cursor so sync can differ. */
public final class RingBuffer {
    private final short[] data;
    private final int frames;
    private long writeFrame;

    public RingBuffer(int sampleRate, int seconds) {
        int span = seconds < 2 ? 2 : seconds;
        frames = sampleRate * span;
        data = new short[frames * 2];
    }

    public synchronized void write(short[] src, int samples) {
        if (src == null || samples < 2) {
            return;
        }
        int n = samples >> 1;
        for (int i = 0; i < n; i++) {
            int p = (int) ((writeFrame + i) % frames) * 2;
            int s = i * 2;
            data[p] = src[s];
            data[p + 1] = src[s + 1];
        }
        writeFrame += n;
    }

    public synchronized long writeFrame() {
        return writeFrame;
    }

    public synchronized int capacityFrames() {
        return frames;
    }

    /**
     * Copy the next chunk. {@code cursor[0]} is the next frame.
     * {@code delayFrames} is how far behind the writer this reader must stay.
     * {@code snap} jumps to the new alignment (used when the sync slider lands).
     * Returns sample count, or 0 if the writer has not reached this read yet.
     */
    public synchronized int read(short[] dst, int dstSamples, long[] cursor, int delayFrames, boolean snap) {
        int want = dstSamples >> 1;
        if (dst == null || want <= 0 || cursor == null) {
            return 0;
        }
        long latest = writeFrame - (delayFrames > 0 ? delayFrames : 0);
        if (latest < 0) {
            latest = 0;
        }
        long oldest = writeFrame - frames;
        if (oldest < 0) {
            oldest = 0;
        }
        long c = cursor[0];
        if (snap || c < 0) {
            c = latest - want;
        }
        if (c < oldest) {
            c = oldest;
        }
        if (c < 0) {
            c = 0;
        }
        long maxBehind = frames - Math.min(frames / 8, 8000);
        if (maxBehind < want) {
            maxBehind = want;
        }
        if (latest - c > maxBehind) {
            c = latest - want;
            if (c < oldest) {
                c = oldest;
            }
        }
        if (latest - c < want) {
            cursor[0] = c;
            return 0;
        }
        for (int i = 0; i < want; i++) {
            int p = (int) ((c + i) % frames) * 2;
            int d = i * 2;
            dst[d] = data[p];
            dst[d + 1] = data[p + 1];
        }
        cursor[0] = c + want;
        return want * 2;
    }
}
