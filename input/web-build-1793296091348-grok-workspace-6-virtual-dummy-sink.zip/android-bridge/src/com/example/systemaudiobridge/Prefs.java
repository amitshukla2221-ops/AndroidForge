package com.example.systemaudiobridge;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String NAME = "bridge_route_v21";

    private Prefs() {
    }

    public static void load(Context context) {
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(NAME, 0);
        MixState.speakerVolume = MixState.clampVol(prefs.getInt("speaker_vol", 100));
        MixState.speakerShiftMs = Sync.clamp(prefs.getInt("speaker_shift", 0));
        MixState.speakerMuted = prefs.getBoolean("speaker_muted", false);
        MixState.btVolume = MixState.clampVol(prefs.getInt("bt_vol", 100));
        MixState.btShiftMs = Sync.clamp(prefs.getInt("bt_shift", 0));
        MixState.btMuted = prefs.getBoolean("bt_muted", false);
        readEq(prefs.getString("speaker_eq", null), MixState.speakerEq);
        readEq(prefs.getString("bt_eq", null), MixState.btEq);
        MixState.speakerPreset = EqPresets.match(MixState.speakerEq);
        MixState.btPreset = EqPresets.match(MixState.btEq);
    }

    public static void save(Context context) {
        SharedPreferences.Editor edit = context.getApplicationContext().getSharedPreferences(NAME, 0).edit();
        edit.putInt("speaker_vol", MixState.speakerVolume);
        edit.putInt("speaker_shift", MixState.speakerShiftMs);
        edit.putBoolean("speaker_muted", MixState.speakerMuted);
        edit.putInt("bt_vol", MixState.btVolume);
        edit.putInt("bt_shift", MixState.btShiftMs);
        edit.putBoolean("bt_muted", MixState.btMuted);
        edit.putString("speaker_eq", writeEq(MixState.speakerEq));
        edit.putString("bt_eq", writeEq(MixState.btEq));
        edit.apply();
    }

    private static void readEq(String raw, int[] dest) {
        synchronized (dest) {
            for (int i = 0; i < dest.length; i++) {
                dest[i] = 0;
            }
            if (raw == null || raw.length() == 0) {
                return;
            }
            String[] parts = raw.split(",");
            for (int i = 0; i < dest.length && i < parts.length; i++) {
                try {
                    dest[i] = EqPresets.clampDb(Integer.parseInt(parts[i].trim()));
                } catch (NumberFormatException ignored) {
                    dest[i] = 0;
                }
            }
        }
    }

    private static String writeEq(int[] src) {
        synchronized (src) {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < src.length; i++) {
                if (i > 0) {
                    b.append(',');
                }
                b.append(src[i]);
            }
            return b.toString();
        }
    }
}
