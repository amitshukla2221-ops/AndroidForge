package com.example.systemaudiobridge;

/** Five bands: 60 Hz, 250 Hz, 1 kHz, 4 kHz, 12 kHz. Gains are whole dB. */
public final class EqPresets {
    public static final int BANDS = 5;
    public static final String[] NAMES = {"Flat", "Bass", "Vocal", "Treble", "Music"};
    public static final int[][] GAINS = {
            {0, 0, 0, 0, 0},
            {6, 3, 0, 0, -1},
            {-1, 0, 4, 3, 0},
            {0, 0, 0, 3, 5},
            {3, 1, 0, 2, 3}
    };

    private EqPresets() {
    }

    public static int clampDb(int db) {
        if (db < -12) {
            return -12;
        }
        if (db > 12) {
            return 12;
        }
        return db;
    }

    public static String match(int[] db) {
        if (db == null || db.length < BANDS) {
            return "Custom";
        }
        for (int i = 0; i < NAMES.length; i++) {
            boolean same = true;
            for (int b = 0; b < BANDS; b++) {
                if (clampDb(db[b]) != GAINS[i][b]) {
                    same = false;
                    break;
                }
            }
            if (same) {
                return NAMES[i];
            }
        }
        return "Custom";
    }

    public static void apply(String name, int[] dest) {
        for (int i = 0; i < NAMES.length; i++) {
            if (NAMES[i].equals(name)) {
                for (int b = 0; b < BANDS; b++) {
                    dest[b] = GAINS[i][b];
                }
                return;
            }
        }
    }
}
