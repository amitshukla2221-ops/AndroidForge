package com.example.systemaudiobridge;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;
import java.util.ArrayList;
import java.util.List;

public final class Devices {
    public static final int TYPE_BUILTIN_SPEAKER = AudioDeviceInfo.TYPE_BUILTIN_SPEAKER;
    public static final int TYPE_BLUETOOTH_SCO = AudioDeviceInfo.TYPE_BLUETOOTH_SCO;
    public static final int TYPE_BLUETOOTH_A2DP = AudioDeviceInfo.TYPE_BLUETOOTH_A2DP;
    public static final int TYPE_BUILTIN_EARPIECE = AudioDeviceInfo.TYPE_BUILTIN_EARPIECE;
    public static final int TYPE_HEARING_AID = 23;
    public static final int TYPE_BLE_HEADSET = 26;
    public static final int TYPE_BLE_SPEAKER = 27;

    private Devices() {
    }

    public static AudioManager audioManager(Context context) {
        return (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
    }

    public static boolean isBluetoothOut(int type) {
        if (type == TYPE_BLUETOOTH_A2DP || type == TYPE_HEARING_AID) {
            return true;
        }
        if (Build.VERSION.SDK_INT >= 31 && (type == TYPE_BLE_HEADSET || type == TYPE_BLE_SPEAKER)) {
            return true;
        }
        return false;
    }

    public static boolean isCallRoute(int type) {
        return type == TYPE_BLUETOOTH_SCO || type == TYPE_BUILTIN_EARPIECE || type == AudioDeviceInfo.TYPE_TELEPHONY;
    }

    public static AudioDeviceInfo builtInSpeaker(AudioManager manager) {
        AudioDeviceInfo[] devices = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
        for (int i = 0; i < devices.length; i++) {
            if (devices[i].getType() == TYPE_BUILTIN_SPEAKER) {
                return devices[i];
            }
        }
        return null;
    }

    public static ArrayList<AudioDeviceInfo> bluetoothOutputs(AudioManager manager) {
        ArrayList<AudioDeviceInfo> list = new ArrayList<AudioDeviceInfo>();
        AudioDeviceInfo[] devices = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
        for (int i = 0; i < devices.length; i++) {
            if (isBluetoothOut(devices[i].getType())) {
                list.add(devices[i]);
            }
        }
        return list;
    }

    /** Prefer a Bluetooth speaker over earbuds when both are listed. One classic radio is the usual case. */
    public static AudioDeviceInfo chooseBluetooth(Context context) {
        ArrayList<AudioDeviceInfo> all = bluetoothOutputs(audioManager(context));
        AudioDeviceInfo best = null;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < all.size(); i++) {
            int score = score(all.get(i));
            if (score > bestScore) {
                bestScore = score;
                best = all.get(i);
            }
        }
        return best;
    }

    public static AudioDeviceInfo mediaDevice(Context context) {
        AudioManager manager = audioManager(context);
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build();
                java.lang.reflect.Method method;
                try {
                    method = AudioManager.class.getMethod("getAudioDevicesForAttributes", AudioAttributes.class);
                } catch (NoSuchMethodException missing) {
                    method = AudioManager.class.getMethod("getDevicesForAttributes", AudioAttributes.class);
                }
                Object result = method.invoke(manager, attrs);
                if (result instanceof List) {
                    List<?> list = (List<?>) result;
                    if (!list.isEmpty() && list.get(0) instanceof AudioDeviceInfo) {
                        return (AudioDeviceInfo) list.get(0);
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        ArrayList<AudioDeviceInfo> bt = bluetoothOutputs(manager);
        if (!bt.isEmpty()) {
            return bt.get(0);
        }
        return builtInSpeaker(manager);
    }

    public static boolean sameOutput(AudioDeviceInfo wanted, AudioDeviceInfo routed) {
        if (wanted == null || routed == null) {
            return false;
        }
        if (wanted.getId() == routed.getId()) {
            return true;
        }
        if (wanted.getType() == TYPE_BUILTIN_SPEAKER) {
            return routed.getType() == TYPE_BUILTIN_SPEAKER;
        }
        return isBluetoothOut(wanted.getType()) && isBluetoothOut(routed.getType());
    }

    public static String label(AudioDeviceInfo device) {
        if (device == null) {
            return "Bluetooth";
        }
        if (device.getType() == TYPE_BUILTIN_SPEAKER) {
            return "Built-in speaker";
        }
        try {
            CharSequence name = device.getProductName();
            if (name != null) {
                String trim = name.toString().trim();
                if (trim.length() > 0 && !"null".equalsIgnoreCase(trim)) {
                    return trim;
                }
            }
        } catch (SecurityException ignored) {
        }
        return "Bluetooth speaker";
    }

    private static int score(AudioDeviceInfo device) {
        int score = 0;
        int type = device.getType();
        if (type == TYPE_BLUETOOTH_A2DP) {
            score += 30;
        } else if (type == TYPE_BLE_SPEAKER) {
            score += 36;
        } else if (type == TYPE_BLE_HEADSET) {
            score += 8;
        } else if (type == TYPE_HEARING_AID) {
            score += 4;
        }
        String name = label(device).toLowerCase();
        if (contains(name, "speaker", "soundbar", "sound bar", "boom", "flip", "charge", "xtreme",
                "party", "srs", "soundlink", "megaboom", "homepod", "echo", "nest")) {
            score += 40;
        }
        if (contains(name, "headphone", "headset", "earbud", "airpod", "buds", "earphone", "neckband")) {
            score -= 25;
        }
        return score;
    }

    private static boolean contains(String name, String... keys) {
        for (int i = 0; i < keys.length; i++) {
            if (name.contains(keys[i])) {
                return true;
            }
        }
        return false;
    }
}
