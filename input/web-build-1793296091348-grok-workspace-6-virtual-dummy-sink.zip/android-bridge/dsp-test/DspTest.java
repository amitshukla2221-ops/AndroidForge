package com.example.systemaudiobridge;

public final class DspTest {
    private static int failed;

    public static void main(String[] args) {
        syncMath();
        ringAlignment();
        flatIsExact();
        boostIsSixDb();
        limiter();
        presets();
        muteRampsToSilence();
        if (failed > 0) {
            System.err.println("FAILED " + failed);
            System.exit(1);
        }
        System.out.println("DSP tests passed");
    }

    private static void syncMath() {
        eq(180, Sync.absoluteDelayMs(0, 0), "both zero");
        eq(180, Sync.absoluteDelayMs(-200, 100), "earlier side keeps base");
        eq(480, Sync.absoluteDelayMs(100, -200), "later side waits the gap");
        eq(180, Sync.absoluteDelayMs(500, 500), "same shift stays together");
        eq(680, Sync.absoluteDelayMs(500, 0), "positive waits");
        eq(180, Sync.absoluteDelayMs(-500, 0), "negative is the earlier side");
        eq(680, Sync.absoluteDelayMs(0, -500), "other side waits when this is forward");
        eq(-500, Sync.clamp(-900), "clamp low");
        eq(500, Sync.clamp(900), "clamp high");
    }

    private static void ringAlignment() {
        int rate = 48000;
        RingBuffer ring = new RingBuffer(rate, 4);
        int frames = 48000;
        short[] block = new short[1024];
        for (int f = 0; f < frames; f += 512) {
            for (int i = 0; i < 512; i++) {
                int id = f + i;
                block[i * 2] = (short) (id % 30000);
                block[i * 2 + 1] = (short) ((id + 7) % 30000);
            }
            ring.write(block, 1024);
        }
        long[] a = new long[] {0};
        long[] b = new long[] {0};
        short[] da = new short[1024];
        short[] db = new short[1024];
        int delayA = Sync.delayFrames(rate, Sync.absoluteDelayMs(-200, 100));
        int delayB = Sync.delayFrames(rate, Sync.absoluteDelayMs(100, -200));
        int guard = 0;
        while (ring.read(da, da.length, a, delayA, false) > 0 && guard++ < 100000) {
        }
        guard = 0;
        while (ring.read(db, db.length, b, delayB, false) > 0 && guard++ < 100000) {
        }
        long gap = a[0] - b[0];
        long expect = delayB - delayA;
        check(Math.abs(gap - expect) < 1200, "steady sync gap " + gap + " expected about " + expect);
        long[] c = new long[] {0};
        short[] snap = new short[1024];
        ring.read(snap, snap.length, c, 1000, true);
        long landed = ring.writeFrame() - 1000 - 512;
        check(c[0] == landed + 512, "snap lands on the new alignment");
    }

    private static void flatIsExact() {
        Tone tone = new Tone(48000);
        short[] buf = new short[2048];
        short[] copy = new short[2048];
        for (int i = 0; i < buf.length; i++) {
            buf[i] = (short) ((i * 17) % 20000 - 10000);
            copy[i] = buf[i];
        }
        tone.process(buf, buf.length, 1f, new int[5]);
        boolean same = true;
        for (int i = 0; i < buf.length; i++) {
            if (buf[i] != copy[i]) {
                same = false;
                break;
            }
        }
        check(same, "flat full-level path is bit-exact");
    }

    private static void boostIsSixDb() {
        int rate = 48000;
        int n = rate / 2;
        float[] dry = new float[n];
        double step = 2.0 * Math.PI * 1000.0 / rate;
        for (int i = 0; i < n; i += 2) {
            float s = (float) Math.sin(step * (i / 2));
            dry[i] = s * 0.2f;
            dry[i + 1] = s * 0.2f;
        }
        float[] wet = dry.clone();
        GraphicEq eq = new GraphicEq(rate);
        int[] bands = new int[] {0, 0, 6, 0, 0};
        eq.setImmediate(bands);
        eq.process(wet, n);
        int from = n / 2;
        double dryRms = rms(dry, from, n);
        double wetRms = rms(wet, from, n);
        double ratio = wetRms / dryRms;
        check(ratio > 1.85 && ratio < 2.15, "1 kHz +6 dB ratio was " + ratio);
        boolean finite = true;
        for (int i = 0; i < n; i++) {
            if (Float.isNaN(wet[i]) || Float.isInfinite(wet[i])) {
                finite = false;
            }
        }
        check(finite, "eq stays finite");
    }

    private static void limiter() {
        check(Math.abs(Pcm.limit(0.2f) - 0.2f) < 1e-6f, "quiet samples unchanged");
        float hot = Pcm.limit(3f);
        check(hot < 1f && hot > 0.9f, "hot sample is limited, got " + hot);
        check(Pcm.limit(-3f) > -1f && Pcm.limit(-3f) < -0.9f, "negative limit");
    }

    private static void presets() {
        int[] db = new int[5];
        EqPresets.apply("Bass", db);
        check("Bass".equals(EqPresets.match(db)), "bass matches");
        db[0] = 4;
        check("Custom".equals(EqPresets.match(db)), "edited band is custom");
        check(EqPresets.clampDb(40) == 12, "db clamp");
    }

    private static void muteRampsToSilence() {
        Tone tone = new Tone(48000);
        short[] buf = new short[1024];
        for (int i = 0; i < buf.length; i++) {
            buf[i] = 8000;
        }
        for (int i = 0; i < 80; i++) {
            for (int s = 0; s < buf.length; s++) {
                buf[s] = 8000;
            }
            tone.process(buf, buf.length, 0f, new int[5]);
        }
        int peak = 0;
        for (int i = 0; i < buf.length; i++) {
            int v = buf[i] < 0 ? -buf[i] : buf[i];
            if (v > peak) {
                peak = v;
            }
        }
        check(peak < 40, "muted chain settles to silence, peak " + peak);
    }

    private static double rms(float[] data, int from, int to) {
        double sum = 0;
        int n = 0;
        for (int i = from; i < to; i += 2) {
            sum += (double) data[i] * data[i];
            n++;
        }
        return Math.sqrt(sum / n);
    }

    private static void eq(int expect, int actual, String name) {
        if (expect != actual) {
            failed++;
            System.err.println(name + " expected " + expect + " got " + actual);
        }
    }

    private static void check(boolean ok, String name) {
        if (!ok) {
            failed++;
            System.err.println(name);
        }
    }
}
