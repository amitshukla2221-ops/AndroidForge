# System Audio Bridge — virtual dummy sink change

## Changes
- Removed the physical, near-silent `AudioTrack` that was previously used as the “silent primary” dummy.
- Removed its writer thread and lifecycle cleanup.
- Replaced it with a logical virtual sink: a discard-only concept that does not create an output track and does not touch Android's global media volume.
- Kept the separate internal-speaker and Bluetooth output tracks, including their per-output software gain, EQ, mute and delay controls.
- Updated route/status labels to identify the dummy as a virtual sink.

## Important limitation
This change does not itself make Android playback capture universal or guarantee original-output suppression. Capture remains subject to Android's playback-capture policy and each source app's capture policy. Original suppression still depends on whether the device can route both processed output tracks away from the media stream and safely suppress the original. If it cannot, the existing service deliberately falls back to keeping audio audible rather than risking total silence.

## Validation
Source-level sanity check only: balanced braces and parentheses; removed dummy-track/thread references were searched for. An Android build and device test were not run in this environment because no Android SDK (`android.jar`, `aapt2`, `d8`) is installed. Test on the Honor Pad 8 before relying on the APK.
