package com.example.systemaudiobridge;

/**
 * Manual sync only. The sliders are the only thing that moves timing.
 * A more negative shift plays that output sooner. Nothing here measures or corrects latency.
 */
public final class Sync {
    public static final int MAX_MS = 500;
    /** Cushion so both readers stay behind the capture writer. Same for both, so it is not an offset. */
    public static final int BASE_MS = 180;

    private Sync() {
    }

    public static int clamp(int value) {
        if (value < -MAX_MS) {
            return -MAX_MS;
        }
        if (value > MAX_MS) {
            return MAX_MS;
        }
        return value;
    }

    /**
     * How far behind the capture writer this side should read, in milliseconds.
     * The earlier side keeps {@link #BASE_MS}. The later side waits the difference.
     * Both numbers come from the sliders. This does not listen to the audio.
     */
    public static int absoluteDelayMs(int thisShift, int otherShift) {
        int mine = clamp(thisShift);
        int other = clamp(otherShift);
        int earliest = mine < other ? mine : other;
        return BASE_MS + (mine - earliest);
    }

    public static int delayFrames(int sampleRate, int delayMs) {
        if (sampleRate <= 0 || delayMs <= 0) {
            return 0;
        }
        return (int) ((long) sampleRate * (long) delayMs / 1000L);
    }

    /** Positive gap. Zero when the two manual shifts match. */
    public static int gapMs(int speakerShift, int btShift) {
        int speaker = clamp(speakerShift);
        int bt = clamp(btShift);
        int gap = speaker - bt;
        return gap < 0 ? -gap : gap;
    }

    /**
     * Who the sliders put first.
     * -1 tablet speaker, +1 Bluetooth, 0 together.
     */
    public static int leader(int speakerShift, int btShift) {
        int speaker = clamp(speakerShift);
        int bt = clamp(btShift);
        if (speaker < bt) {
            return -1;
        }
        if (bt < speaker) {
            return 1;
        }
        return 0;
    }

    /** Sentence shown above each sync slider. */
    public static String leadText(int speakerShift, int btShift) {
        int gap = gapMs(speakerShift, btShift);
        int who = leader(speakerShift, btShift);
        if (who == 0) {
            return "Together · 0 ms";
        }
        if (who < 0) {
            return "Tablet speaker is playing first by " + gap + " ms";
        }
        return "Bluetooth is playing first by " + gap + " ms";
    }
}
