package com.example.systemaudiobridge;

/**
 * One output's own chain. It never reads the other output.
 * Flat EQ keeps the captured samples: full level is bit-exact, any other level is a plain scale.
 * The soft limiter runs only while a band is boosted.
 */
public final class Tone {
    private final GraphicEq eq;
    private final float[] wet = new float[8192];
    private final int[] dither = new int[] {0x1234567};
    private float gain = 1f;
    private boolean settled = true;

    public Tone(int sampleRate) {
        eq = new GraphicEq(sampleRate);
        eq.setImmediate(new int[EqPresets.BANDS]);
    }

    public void process(short[] samples, int count, float targetGain, int[] bands) {
        if (count <= 0 || samples == null) {
            return;
        }
        if (targetGain < 0f) {
            targetGain = 0f;
        } else if (targetGain > 1f) {
            targetGain = 1f;
        }
        boolean wantFlat = true;
        if (bands != null) {
            for (int i = 0; i < EqPresets.BANDS; i++) {
                if (bands[i] != 0) {
                    wantFlat = false;
                    break;
                }
            }
        }
        if (wantFlat && settled && eq.isFlat()) {
            applyIntegerGain(samples, count, targetGain);
            settled = Math.abs(gain - targetGain) < 0.0005f;
            return;
        }
        if (count > wet.length) {
            applyBlockwise(samples, count, targetGain, bands);
            return;
        }
        eq.setTargets(bands);
        Pcm.toFloat(samples, count, wet);
        eq.process(wet, count);
        applyGain(wet, count, targetGain);
        Pcm.toShort(wet, count, samples, dither);
        settled = eq.isFlat() && Math.abs(gain - targetGain) < 0.0005f;
    }

    private void applyBlockwise(short[] samples, int count, float targetGain, int[] bands) {
        int off = 0;
        while (off < count) {
            int n = count - off;
            if (n > wet.length) {
                n = wet.length;
            }
            short[] slice = new short[n];
            System.arraycopy(samples, off, slice, 0, n);
            process(slice, n, targetGain, bands);
            System.arraycopy(slice, 0, samples, off, n);
            off += n;
        }
    }

    /** Plain multiply. No limiter, no dither, no filter. Full scale leaves the shorts untouched. */
    private void applyIntegerGain(short[] samples, int count, float target) {
        float step = 0.002f;
        float g = gain;
        for (int i = 0; i < count; i++) {
            if (g < target) {
                g += step;
                if (g > target) {
                    g = target;
                }
            } else if (g > target) {
                g -= step;
                if (g < target) {
                    g = target;
                }
            }
            if (g >= 0.9995f) {
                continue;
            }
            if (g <= 0.0005f) {
                samples[i] = 0;
                continue;
            }
            int v = Math.round(samples[i] * g);
            if (v > 32767) {
                v = 32767;
            } else if (v < -32768) {
                v = -32768;
            }
            samples[i] = (short) v;
        }
        gain = g;
    }

    private void applyGain(float[] buf, int count, float target) {
        float step = 0.00085f;
        float g = gain;
        for (int i = 0; i < count; i++) {
            if (g < target) {
                g += step;
                if (g > target) {
                    g = target;
                }
            } else if (g > target) {
                g -= step;
                if (g < target) {
                    g = target;
                }
            }
            buf[i] = Pcm.limit(buf[i] * g);
        }
        gain = g;
    }
}
