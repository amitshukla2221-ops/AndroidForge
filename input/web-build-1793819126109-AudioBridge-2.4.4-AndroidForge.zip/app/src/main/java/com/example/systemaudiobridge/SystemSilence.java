package com.example.systemaudiobridge;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Build;
import android.util.Log;

/**
 * Silences the system media stream and puts the same level back on stop.
 * Only used after both bridge copies are confirmed on a stream that does not follow media volume.
 */
public final class SystemSilence {
    private static final String TAG = "AudioBridge";
    private static final String PREFS = "bridge_silence_v2";

    private int savedMusic = -1;
    private boolean savedMusicMute;
    private int savedAlarm = -1;
    private boolean holdingMusic;
    private boolean holdingAlarm;
    private boolean volumeRegistered;
    private static final int MAX_AUX = 6;
    private final int[] auxStream = new int[MAX_AUX];
    private final int[] auxSaved = new int[MAX_AUX];
    private int auxCount;

    private final BroadcastReceiver volumeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!holdingMusic || intent == null) {
                return;
            }
            int stream = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1);
            int value = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1);
            if (stream != AudioManager.STREAM_MUSIC || value <= 0) {
                return;
            }
            savedMusic = value;
            persist(context);
            try {
                Devices.audioManager(context).setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
            } catch (Throwable ignored) {
            }
        }
    };

    public boolean isHoldingMusic() {
        return holdingMusic;
    }

    public boolean holdMusic(Context context) {
        if (holdingMusic) {
            return true;
        }
        AudioManager am = Devices.audioManager(context);
        if (am.isVolumeFixed()) {
            return false;
        }
        savedMusic = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        savedMusicMute = am.isStreamMute(AudioManager.STREAM_MUSIC);
        holdingMusic = true;
        persist(context);
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0);
        } catch (Throwable t) {
            Log.w(TAG, "mute", t);
            holdingMusic = false;
            clearMusicPref(context);
            return false;
        }
        if (savedMusic > 0 && am.getStreamVolume(AudioManager.STREAM_MUSIC) > 0) {
            holdingMusic = false;
            clearMusicPref(context);
            return false;
        }
        registerVolume(context);
        return true;
    }

    public void boostAlarm(Context context) {
        matchStreamToMusic(context, AudioManager.STREAM_ALARM);
    }

    /**
     * Puts this non-music stream at the same fraction as the user's media volume
     * so a copy played on alarm/notification/assistant is actually audible and the
     * in-app slider is the only loudness control. Restored on stop.
     */
    public void matchStreamToMusic(Context context, int stream) {
        if (stream < 0) {
            return;
        }
        for (int i = 0; i < auxCount; i++) {
            if (auxStream[i] == stream) {
                return;
            }
        }
        if (auxCount >= MAX_AUX) {
            return;
        }
        AudioManager am = Devices.audioManager(context);
        int now;
        int max;
        try {
            now = am.getStreamVolume(stream);
            max = am.getStreamMaxVolume(stream);
        } catch (Throwable t) {
            Log.w(TAG, "stream read", t);
            return;
        }
        if (max <= 0) {
            return;
        }
        int musicMax = 0;
        int music = savedMusic;
        try {
            musicMax = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            if (music < 0) {
                music = am.getStreamVolume(AudioManager.STREAM_MUSIC);
            }
        } catch (Throwable ignored) {
        }
        if (music <= 0) {
            music = musicMax > 0 ? Math.max(1, (musicMax * 7) / 10) : max;
        }
        int target = musicMax <= 0
                ? Math.max(1, (max * 7) / 10)
                : Math.max(1, Math.round(music * (max / (float) musicMax)));
        if (target > max) {
            target = max;
        }
        auxStream[auxCount] = stream;
        auxSaved[auxCount] = now;
        auxCount++;
        if (stream == AudioManager.STREAM_ALARM) {
            savedAlarm = now;
            holdingAlarm = true;
        }
        persist(context);
        if (now == target) {
            return;
        }
        try {
            am.setStreamVolume(stream, target, 0);
        } catch (Throwable t) {
            Log.w(TAG, "stream " + stream, t);
        }
    }

    /** Unmutes media only. Used when muting media also zeroes the capture on this device. */
    public void releaseMusic(Context context) {
        AudioManager am = Devices.audioManager(context);
        unregisterVolume(context);
        restoreMusic(am);
        holdingMusic = false;
        clearMusicPref(context);
    }

    public void restoreAll(Context context) {
        AudioManager am = Devices.audioManager(context);
        unregisterVolume(context);
        if (holdingAlarm && savedAlarm >= 0) {
            try {
                am.setStreamVolume(AudioManager.STREAM_ALARM, savedAlarm, 0);
            } catch (Throwable t) {
                Log.w(TAG, "restore alarm", t);
            }
        }
        holdingAlarm = false;
        savedAlarm = -1;
        restoreAux(am);
        restoreMusic(am);
        holdingMusic = false;
        clearAll(context);
    }

    private void restoreAux(AudioManager am) {
        for (int i = 0; i < auxCount; i++) {
            try {
                am.setStreamVolume(auxStream[i], Math.max(0, auxSaved[i]), 0);
            } catch (Throwable t) {
                Log.w(TAG, "restore stream", t);
            }
            auxStream[i] = 0;
            auxSaved[i] = 0;
        }
        auxCount = 0;
    }

    private void restoreMusic(AudioManager am) {
        if (!holdingMusic || savedMusic < 0) {
            return;
        }
        try {
            if (!savedMusicMute) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0);
            }
            am.setStreamVolume(AudioManager.STREAM_MUSIC, savedMusic, 0);
            if (savedMusicMute) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0);
            }
        } catch (Throwable t) {
            Log.w(TAG, "restore music", t);
        }
    }

    public static void recoverAbandoned(Context context) {
        SharedPreferences prefs = prefs(context);
        boolean music = prefs.getBoolean("music_holding", false);
        boolean alarm = prefs.getBoolean("alarm_holding", false);
        if (!music && !alarm) {
            return;
        }
        AudioManager am = Devices.audioManager(context);
        if (alarm) {
            try {
                am.setStreamVolume(AudioManager.STREAM_ALARM, prefs.getInt("alarm_index", 0), 0);
            } catch (Throwable ignored) {
            }
        }
        if (music) {
            int vol = prefs.getInt("music_index", 0);
            boolean muted = prefs.getBoolean("music_muted", false);
            try {
                if (!muted) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0);
                }
                am.setStreamVolume(AudioManager.STREAM_MUSIC, vol, 0);
                if (muted) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0);
                }
            } catch (Throwable ignored) {
            }
        }
        int aux = prefs.getInt("aux_count", 0);
        for (int i = 0; i < aux && i < MAX_AUX; i++) {
            int stream = prefs.getInt("aux_stream_" + i, -1);
            int level = prefs.getInt("aux_level_" + i, -1);
            if (stream < 0 || level < 0) {
                continue;
            }
            try {
                am.setStreamVolume(stream, level, 0);
            } catch (Throwable ignored) {
            }
        }
        prefs.edit()
                .putBoolean("music_holding", false)
                .putBoolean("alarm_holding", false)
                .putInt("aux_count", 0)
                .commit();
        Log.i(TAG, "restored media volume after an interrupted bridge");
    }

    private void persist(Context context) {
        SharedPreferences.Editor edit = prefs(context).edit()
                .putBoolean("music_holding", holdingMusic)
                .putInt("music_index", Math.max(0, savedMusic))
                .putBoolean("music_muted", savedMusicMute)
                .putBoolean("alarm_holding", holdingAlarm)
                .putInt("alarm_index", Math.max(0, savedAlarm))
                .putInt("aux_count", auxCount);
        for (int i = 0; i < MAX_AUX; i++) {
            if (i < auxCount) {
                edit.putInt("aux_stream_" + i, auxStream[i]);
                edit.putInt("aux_level_" + i, Math.max(0, auxSaved[i]));
            } else {
                edit.remove("aux_stream_" + i);
                edit.remove("aux_level_" + i);
            }
        }
        edit.commit();
    }

    private void clearMusicPref(Context context) {
        prefs(context).edit().putBoolean("music_holding", false).commit();
    }

    private void clearAll(Context context) {
        auxCount = 0;
        prefs(context).edit()
                .putBoolean("music_holding", false)
                .putBoolean("alarm_holding", false)
                .putInt("aux_count", 0)
                .commit();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, 0);
    }

    private void registerVolume(Context context) {
        if (volumeRegistered) {
            return;
        }
        Context app = context.getApplicationContext();
        IntentFilter filter = new IntentFilter("android.media.VOLUME_CHANGED_ACTION");
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                app.registerReceiver(volumeReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                app.registerReceiver(volumeReceiver, filter);
            }
            volumeRegistered = true;
        } catch (Throwable t) {
            Log.w(TAG, "volume receiver", t);
        }
    }

    private void unregisterVolume(Context context) {
        if (!volumeRegistered) {
            return;
        }
        try {
            context.getApplicationContext().unregisterReceiver(volumeReceiver);
        } catch (Throwable ignored) {
        }
        volumeRegistered = false;
    }
}
