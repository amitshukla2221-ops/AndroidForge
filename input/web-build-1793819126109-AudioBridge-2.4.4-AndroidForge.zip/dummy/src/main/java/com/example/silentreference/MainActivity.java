package com.example.silentreference;

import android.app.Activity;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Plays digital-zero PCM at unity AudioTrack gain. It is intentionally silent;
 * it does NOT capture, receive, or reroute audio from other applications.
 */
public final class MainActivity extends Activity {
    private AudioTrack track;
    private Thread writer;
    private volatile boolean running;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        TextView title = new TextView(this);
        title.setText("Silent Reference is running");
        title.setTextSize(22);
        TextView info = new TextView(this);
        info.setPadding(0, 16, 0, 0);
        info.setText("Digital silence is played at 100% AudioTrack gain. No sound is emitted. This app is only a silent playback test/reference; Audio Bridge remains responsible for capturing eligible audio and routing its copies.");
        info.setTextSize(16);
        root.addView(title);
        root.addView(info);
        setContentView(root);
        startSilentTrack();
    }

    private void startSilentTrack() {
        final int rate = 48000;
        int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        int bytes = Math.max(min, 4096);
        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        AudioFormat format = new AudioFormat.Builder()
                .setSampleRate(rate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build();
        track = new AudioTrack.Builder().setAudioAttributes(attributes).setAudioFormat(format)
                .setBufferSizeInBytes(bytes).setTransferMode(AudioTrack.MODE_STREAM).build();
        if (track.getState() != AudioTrack.STATE_INITIALIZED) {
            track.release(); track = null; return;
        }
        track.setVolume(1.0f); // Unity gain, not muted; samples are digital zero.
        track.play();
        final byte[] silence = new byte[4096];
        running = true;
        writer = new Thread(() -> {
            while (running && track != null) {
                try {
                    int n = track.write(silence, 0, silence.length, AudioTrack.WRITE_BLOCKING);
                    if (n < 0) break;
                } catch (Throwable ignored) { break; }
            }
        }, "SilentReferenceWriter");
        writer.setDaemon(true);
        writer.start();
    }

    @Override protected void onDestroy() {
        running = false;
        AudioTrack current = track;
        track = null;
        if (current != null) {
            try { current.pause(); } catch (Throwable ignored) { }
            try { current.flush(); } catch (Throwable ignored) { }
            try { current.release(); } catch (Throwable ignored) { }
        }
        super.onDestroy();
    }
}
