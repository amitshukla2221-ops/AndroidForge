System Audio Bridge 2.4.1 — Android 12 manual sync revision

WHAT CHANGED
- Removed automatic system media-volume muting from the bridge start/playback flow. The bridge no longer tries to set media volume to zero. This avoids the reported failure where capture became silent too.
- Kept the two independent buffer readers and per-output sync, volume, mute, and EQ controls.
- Sync remains manual: the displayed lead/gap is the slider-configured offset, not a measurement of acoustic hardware latency. Adjust the sliders while a song plays to compensate for actual Bluetooth latency.
- Version bumped to 2.4.1 (versionCode 241).

IMPORTANT LIMIT
Because the original song is no longer muted, the original app can remain audible on Android's default media output while a bridge copy is also sent there. This can cause overlap/echo on that output. Android 12 does not provide a universal ordinary-app API to mute only the original output while guaranteeing the captured signal stays unchanged on every tablet. This project cannot guarantee acoustic synchronization until tested on the target tablet and Bluetooth speaker.

ANDROIDFORGE
Upload this ZIP as-is to a NEW AndroidForge project/workspace. The ZIP root contains settings.gradle and build.gradle. Build app-debug.apk or app-release.apk from the Gradle project. This environment has no Android SDK/Gradle installation, so a full Android APK build could not be verified here.
