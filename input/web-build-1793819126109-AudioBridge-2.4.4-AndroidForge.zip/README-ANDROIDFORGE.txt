ANDROIDFORGE BUILD NOTES — AUDIO BRIDGE 2.4.3

This ZIP is a Gradle multi-project. The root includes settings.gradle and build.gradle.

Modules:
- :app — Audio Bridge 2.4.3, package com.systemaudiobridge.manualsync, versionCode 243. This is the main app and keeps its update-compatible signing configuration.
- :dummy — Silent Reference 1.0, package com.example.silentreference. This is a separate APK that writes digital-zero PCM at unity gain. It emits no audible sound and does not capture or reroute audio from other apps.

Use a workflow that builds both modules (for example, `gradle assembleDebug`) and uploads both APK outputs. The expected APKs are under app/build/outputs/apk/ and dummy/build/outputs/apk/.

Before consuming a limited build slot, ensure AndroidForge builds all included modules rather than only `:app`. No APK was compiled or tested in this workspace; physical audio routing and echo suppression still require a tablet test.
