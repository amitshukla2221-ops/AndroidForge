package com.example.systemaudiobridge;

/**
 * Desktop checks for the sync clock and the level slider. No Android runtime.
 * A stalled Bluetooth reader must rejoin its own offset, not freeze and not jump to the other side.
 */
public final class LogicTest {
    public static void main(String[] args) {
        testDelayMath();
        testReadersKeepOffsetWhenOneStalls();
        testSliderGain();
        testMuteIsSilent();
        System.out.println("ALL CHECKS PASSED");
    }

    private static void testDelayMath() {
        int speaker = Sync.absoluteDelayMs(-100, 50);
        int bt = Sync.absoluteDelayMs(50, -100);
        expect(speaker == Sync.BASE_MS, "earlier side keeps the base cushion");
        expect(bt == Sync.BASE_MS + 150, "later side waits the slider gap");
        expect(Sync.gapMs(-100, 50) == 150, "gap");
        expect(Sync.leader(-100, 50) == -1, "speaker leads");
        expect(Sync.leader(0, 0) == 0, "together");
        expect(Sync.delayFrames(48000, 200) == 9600, "200 ms at 48 kHz");
        expect(Sync.clamp(9000) == Sync.MAX_MS, "clamp");
    }

    private static void testReadersKeepOffsetWhenOneStalls() {
        int rate = 48000;
        RingBuffer ring = new RingBuffer(rate, 4);
        int chunk = 1024;
        short[] src = new short[chunk];
        for (int i = 0; i < chunk; i++) {
            src[i] = (short) ((i * 17) & 0x7fff);
        }
        long[] speaker = new long[] {-1L};
        long[] bt = new long[] {-1L};
        short[] dst = new short[chunk];
        int speakerDelay = Sync.delayFrames(rate, Sync.absoluteDelayMs(0, 200));
        int btDelay = Sync.delayFrames(rate, Sync.absoluteDelayMs(200, 0));
        expect(btDelay - speakerDelay == 9600, "slider gap is 200 ms of frames");

        // Fill past the base cushion so both readers can start.
        for (int i = 0; i < 800; i++) {
            ring.write(src, chunk);
        }
        int n1 = ring.read(dst, dst.length, speaker, speakerDelay, true);
        int n2 = ring.read(dst, dst.length, bt, btDelay, true);
        expect(n1 == chunk && n2 == chunk, "both sides start");
        long gap = speaker[0] - bt[0];
        expect(Math.abs(gap - 9600) <= chunk, "initial gap follows the slider, was " + gap);

        // Bluetooth write "hangs": its cursor stays put while capture and the speaker continue.
        long frozen = bt[0];
        for (int i = 0; i < 400; i++) {
            ring.write(src, chunk);
            ring.read(dst, dst.length, speaker, speakerDelay, false);
        }
        int resumed = ring.read(dst, dst.length, bt, btDelay, false);
        expect(resumed == chunk, "stalled side resumes");
        expect(bt[0] != frozen, "stalled side did not stay stuck");
        long gapAfter = speaker[0] - bt[0];
        expect(Math.abs(gapAfter - 9600) <= chunk * 2,
                "after a Bluetooth stall the slider gap remains, was " + gapAfter);

        // And it must not have snapped onto the speaker cursor.
        expect(Math.abs(speaker[0] - bt[0]) > 4000, "sides did not collapse together");
    }

    private static void testSliderGain() {
        Tone tone = new Tone(48000);
        short[] samples = new short[1000];
        for (int i = 0; i < samples.length; i++) {
            samples[i] = 10000;
        }
        tone.process(samples, samples.length, 0.5f, new int[EqPresets.BANDS]);
        int last = samples[samples.length - 1];
        expect(Math.abs(last - 5000) <= 2, "50% level scales the copy, got " + last);
        expect(samples[0] > 9000, "level ramps instead of clicking");
    }

    private static void testMuteIsSilent() {
        Tone tone = new Tone(48000);
        short[] samples = new short[800];
        for (int i = 0; i < samples.length; i++) {
            samples[i] = 12000;
        }
        tone.process(samples, samples.length, 0f, new int[EqPresets.BANDS]);
        int tail = 0;
        for (int i = 600; i < samples.length; i++) {
            int v = samples[i];
            if (v < 0) {
                v = -v;
            }
            if (v > tail) {
                tail = v;
            }
        }
        expect(tail == 0, "mute reaches silence, peak " + tail);
    }

    private static void expect(boolean ok, String message) {
        if (!ok) {
            throw new AssertionError(message);
        }
    }
}
