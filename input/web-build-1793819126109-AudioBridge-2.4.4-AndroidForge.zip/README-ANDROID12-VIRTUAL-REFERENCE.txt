SYSTEM AUDIO BRIDGE 2.4.2 — SILENT REFERENCE + ECHO-SUPPRESSION TEST

DESIGN
- Captures eligible media/game/unknown audio from other apps using Android AudioPlaybackCapture.
- One shared capture ring buffer feeds two independent output readers.
- The silent reference is a software timing clock only. It does not create an audible third output and does not need a full-volume AudioTrack.
- Tablet speaker and Bluetooth copies retain independent delay, gain/mute and EQ controls.
- Sync is manual buffer offset, not automatic measurement of acoustic latency.

ECHO-SUPPRESSION CHANGE
- Once capture is audible and both output tracks are present, the service temporarily suppresses the original STREAM_MUSIC route so the default output does not also play the unbuffered original on top of its bridge copy.
- It checks capture shortly afterwards. If this Android 12 device also silences playback capture when STREAM_MUSIC is muted, it restores the original media volume and disables further mute attempts for that session. This preserves playback but means echo can remain on devices with that behavior.
- The saved media volume is restored when the bridge stops or the service exits.

LIMITS / VERIFICATION
- Some apps prohibit playback capture; those apps cannot be copied.
- Android 12 devices vary in whether muting STREAM_MUSIC also mutes captured audio. The safety check handles the observed failure mode, but only a real-device test can establish whether the tablet supports echo-free dual-copy playback.
- Logic tests cover manual delay math, reader recovery and software gain. They do not test Android routing or acoustic synchronization.

ANDROIDFORGE
- ZIP root contains settings.gradle and build.gradle; upload the ZIP as a Gradle project.
- applicationId and signing key are retained for update compatibility with the 2.4.x project.
- versionName 2.4.2, versionCode 242.

2.4.3 REVISION REQUEST
- Added an ORIGINAL CAPTURE LEVEL slider at the top of the main app. It scales the captured PCM once before the shared ring buffer; tablet and Bluetooth sliders still scale their own copy afterward.
- Added a second Gradle module `:dummy`, producing a separate Silent Reference APK (`com.example.silentreference`). It continuously writes digital-zero PCM to an AudioTrack at unity gain (100% track gain). It is not muted; the samples themselves are zero, so no audible sound is emitted.
- IMPORTANT: the Silent Reference APK cannot receive or redirect another app's original audio. Android isolates apps. It is a silent-playback demonstration/reference only. Audio Bridge itself must capture eligible source audio and create both routed copies. Installing the dummy app does not fix Android's system-volume/capture coupling by itself.
- AndroidForge should run Gradle assembleDebug/assembleRelease to produce both app APKs; confirm the workflow publishes `app` and `dummy` outputs before using a limited build slot.


Revision note 2.4.4: both bridge AudioTracks use AudioAttributes.USAGE_MEDIA and are pinned independently with setPreferredDevice(). They are not created as alarm, notification, or assistant streams. Android/OEM routing still must be verified on the target tablet; a successful track creation alone does not prove audible output.
