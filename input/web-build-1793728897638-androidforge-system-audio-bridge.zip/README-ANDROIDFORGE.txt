System Audio Bridge 2.2.0 — AndroidForge Gradle project

UPLOAD:
1. Upload this ZIP as-is to AndroidForge. The ZIP root contains settings.gradle and build.gradle.
2. Choose the Gradle Android build option if AndroidForge asks.
3. Build the app module (assembleDebug or assembleRelease). The APK is normally at:
   app/build/outputs/apk/debug/app-debug.apk
   or app/build/outputs/apk/release/app-release.apk

PROJECT:
- Android application ID: com.example.systemaudiobridge
- Version: 2.2.0 (versionCode 220)
- Minimum Android: 10 (API 29)
- Target Android: 14 (API 34)
- Java 11 source compatibility; Android Gradle Plugin 8.7.3, compatible with Gradle 8.9.

UPDATE SIGNATURE:
The existing bridge-release.keystore from the supplied project is included and configured for
both debug and release variants, so APKs built from this project use the same signing key as
the original supplied build (assuming that original APK was built from this keystore).
Do not remove or replace app/bridge-release.keystore if you need in-place updates.
The keystore password and key password are configured as bridgepass in app/build.gradle.

If AndroidForge cannot access Google's Maven repository to download the Android Gradle Plugin,
the build will fail before compiling; that is a builder/network limitation, not a missing Gradle
project file. This package has been structured as a Gradle project but was not compiled here
because an Android SDK/Gradle build environment is not available in this session.
