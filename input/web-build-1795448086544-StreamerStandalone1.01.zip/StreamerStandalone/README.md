# Streamer (standalone)

Standalone Android app (arm64-v8a, landscape) that plays:
- direct video URLs (http/https)
- magnet links and .torrent files, streamed sequentially while downloading

No Kodi and no Elementum are needed. Engine: libtorrent via jlibtorrent. Player: AndroidX Media3.

## Build
Android Studio (JDK 17): open the folder, Build > Build APK.
Or CI: push this folder to a GitHub repo; the "Build APK" workflow
(.github/workflows/build.yml) produces app-debug.apk as a downloadable artifact.
The debug APK is signed with the debug key and installs normally.

## Credits / licenses
- jlibtorrent by FrostWire - MIT License
- libtorrent by Arvid Norberg - BSD License
- AndroidX Media3 / ExoPlayer - Apache License 2.0

This project does not use or copy code from Elementum, ElementumService, Stremio or UPlayer.
Use only with content you have the right to access.
