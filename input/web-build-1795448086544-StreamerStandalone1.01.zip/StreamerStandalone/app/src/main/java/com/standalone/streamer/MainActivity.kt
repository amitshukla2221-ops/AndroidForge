package com.standalone.streamer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private lateinit var input: EditText

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) playTorrentUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (32 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        val title = TextView(this).apply {
            text = "Streamer"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        input = EditText(this).apply {
            hint = "Paste magnet link or direct video URL"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
        }
        val play = Button(this).apply {
            text = "Play link"
            setOnClickListener { playLink(input.text.toString().trim()) }
        }
        val open = Button(this).apply {
            text = "Open .torrent file"
            setOnClickListener { picker.launch(arrayOf("*/*")) }
        }
        val lp = LinearLayout.LayoutParams(
            (480 * resources.displayMetrics.density).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        root.addView(title, lp)
        root.addView(input, lp)
        root.addView(play, lp)
        root.addView(open, lp)
        setContentView(root)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "magnet") playLink(data.toString()) else playTorrentUri(data)
    }

    private fun playLink(link: String) {
        if (link.isEmpty()) {
            Toast.makeText(this, "Enter a link first", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_LINK, link))
    }

    private fun playTorrentUri(uri: Uri) {
        val bytes = try {
            contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
        if (bytes == null || bytes.isEmpty()) {
            Toast.makeText(this, "Could not read file", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_TORRENT, bytes))
    }
}
