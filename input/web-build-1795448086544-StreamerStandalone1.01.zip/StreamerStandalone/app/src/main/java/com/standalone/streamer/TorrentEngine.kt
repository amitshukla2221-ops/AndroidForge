package com.standalone.streamer

import com.frostwire.jlibtorrent.Priority
import com.frostwire.jlibtorrent.SessionManager
import com.frostwire.jlibtorrent.TorrentFlags
import com.frostwire.jlibtorrent.TorrentHandle
import com.frostwire.jlibtorrent.TorrentInfo
import java.io.File

object TorrentEngine {

    private val session = SessionManager()

    @Synchronized
    fun start() {
        if (!session.isRunning) session.start()
    }

    @Synchronized
    fun stop() {
        if (session.isRunning) session.stop()
    }

    fun fetchMetadata(magnet: String, tempDir: File, timeoutSeconds: Int = 90): TorrentInfo? {
        val data = session.fetchMagnet(magnet, timeoutSeconds, tempDir) ?: return null
        return TorrentInfo.bdecode(data)
    }

    fun largestFile(ti: TorrentInfo): Int {
        val files = ti.files()
        var best = 0
        var bestSize = -1L
        for (i in 0 until files.numFiles()) {
            val s = files.fileSize(i)
            if (s > bestSize) {
                bestSize = s
                best = i
            }
        }
        return best
    }

    fun begin(ti: TorrentInfo, saveDir: File, fileIndex: Int): TorrentHandle? {
        session.download(ti, saveDir)
        var handle: TorrentHandle? = null
        var tries = 0
        while (handle == null && tries < 50) {
            handle = session.find(ti.infoHash())
            if (handle == null) Thread.sleep(100)
            tries++
        }
        val h = handle ?: return null
        val priorities = Array(ti.files().numFiles()) {
            if (it == fileIndex) Priority.NORMAL else Priority.IGNORE
        }
        h.prioritizeFiles(priorities)
        h.setFlags(TorrentFlags.SEQUENTIAL_DOWNLOAD)
        return h
    }
}
