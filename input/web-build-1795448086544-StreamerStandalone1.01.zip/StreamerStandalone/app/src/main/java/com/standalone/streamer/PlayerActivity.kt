package com.standalone.streamer

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import com.frostwire.jlibtorrent.TorrentHandle
import com.frostwire.jlibtorrent.TorrentInfo
import java.io.File

@UnstableApi
class PlayerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_LINK = "link"
        const val EXTRA_TORRENT = "torrent"
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())

    @Volatile
    private var closed = false
    private var usedTorrent = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        playerView = PlayerView(this)
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
        }
        root.addView(
            playerView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        root.addView(
            status,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)

        val link = intent.getStringExtra(EXTRA_LINK)
        val torrentBytes = intent.getByteArrayExtra(EXTRA_TORRENT)

        if (torrentBytes == null && link != null && !link.startsWith("magnet:")) {
            playDirect(link)
        } else {
            usedTorrent = true
            Thread { startTorrent(link, torrentBytes) }.start()
        }
    }

    private fun setStatus(text: String) {
        ui.post { if (!closed) status.text = text }
    }

    private fun newPlayer(): ExoPlayer {
        val p = ExoPlayer.Builder(this).build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                setStatus("Playback error: ${error.errorCodeName}")
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) ui.post { status.text = "" }
            }
        })
        playerView.player = p
        player = p
        return p
    }

    private fun playDirect(url: String) {
        val p = newPlayer()
        p.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
        p.prepare()
        p.playWhenReady = true
    }

    private fun startTorrent(link: String?, data: ByteArray?) {
        try {
            val dir = File(getExternalFilesDir(null) ?: filesDir, "torrents").apply { mkdirs() }
            setStatus("Starting engine...")
            TorrentEngine.start()

            val ti: TorrentInfo = if (data != null) {
                TorrentInfo.bdecode(data)
            } else {
                setStatus("Fetching torrent metadata...")
                TorrentEngine.fetchMetadata(link ?: "", dir)
                    ?: run {
                        setStatus("Could not fetch metadata (timeout)")
                        return
                    }
            }
            if (closed) return

            val idx = TorrentEngine.largestFile(ti)
            val handle = TorrentEngine.begin(ti, dir, idx)
            if (handle == null) {
                setStatus("Could not start torrent")
                return
            }
            val relPath = ti.files().filePath(idx)
            val name = File(relPath).name
            val file = File(dir, relPath)

            ui.post { if (!closed) startTorrentPlayback(ti, handle, idx, file, name) }
            monitor(handle)
        } catch (e: Exception) {
            setStatus("Error: ${e.message}")
        }
    }

    private fun startTorrentPlayback(ti: TorrentInfo, handle: TorrentHandle, idx: Int, file: File, name: String) {
        val factory = DataSource.Factory { TorrentDataSource(ti, handle, idx, file) }
        val item = MediaItem.fromUri(Uri.parse("torrent://stream/" + Uri.encode(name)))
        val source = ProgressiveMediaSource.Factory(factory).createMediaSource(item)
        val p = newPlayer()
        p.setMediaSource(source)
        p.prepare()
        p.playWhenReady = true
    }

    private fun monitor(handle: TorrentHandle) {
        while (!closed) {
            try {
                val st = handle.status()
                val kb = st.downloadRate() / 1024
                val pct = (st.progress() * 100).toInt()
                if (player?.playbackState != Player.STATE_READY) {
                    setStatus("Buffering... $kb KB/s | peers ${st.numPeers()} | $pct%")
                }
                Thread.sleep(1000)
            } catch (e: InterruptedException) {
                return
            } catch (e: Exception) {
                return
            }
        }
    }

    override fun onDestroy() {
        closed = true
        player?.release()
        player = null
        if (usedTorrent) Thread { TorrentEngine.stop() }.start()
        super.onDestroy()
    }
}
