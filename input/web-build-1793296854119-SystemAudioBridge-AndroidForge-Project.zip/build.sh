#!/bin/sh
set -eu
cd "$(dirname "$0")"
if command -v gradle >/dev/null 2>&1; then
  exec gradle --no-daemon assembleDebug
fi
echo "Gradle is not installed in this build environment. Open this project in AndroidForge and run assembleDebug." >&2
exit 127
