# System Audio Bridge 2.1.0 — AndroidForge project

This is a standard Android Gradle project prepared from the supplied `grok-workspace-6-virtual-dummy-sink.zip`.

## Build
- Android Gradle Plugin: 8.7.3
- Java: 11 source compatibility (build with JDK 17 for AGP)
- compile SDK: 35
- min SDK: 29 (Android 10+)
- target SDK: 34

Use the project root (the folder containing `settings.gradle` and `build.gradle`) in AndroidForge. If it asks for a Gradle task, use `assembleDebug` for a test APK or `assembleRelease` for an unsigned release APK. For initial device testing, use the debug APK.

## Important audio limitation
The app captures other apps only where Android's playback-capture rules and the source app permit it. The virtual/discard sink is an internal software concept; it does not itself silence the original physical output. The existing code attempts a system media-stream mute after a capture probe. Android may block or behave differently with that approach on some devices. Test carefully and confirm the original volume is restored when stopping the bridge.

This archive includes source and resources, not a guarantee that the audio-routing behaviour will work on every Android 12 device.
