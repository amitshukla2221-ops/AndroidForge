# System Audio Bridge 1.2 — separate speaker processing

## Included source changes
- Independent six-band tone curves for the built-in phone-speaker bridge copy and Bluetooth bridge copy.
- Independent copy-level controls for phone and Bluetooth destinations, each adjustable from 0–150% in 1% steps. Above 100% is digital gain and may trigger limiting or audible distortion depending on the source and device.
- The bridge selects the matching curve and level based on the destination it is actually routing to.
- Test tones use the matching destination curve and copy level as well.
- Revised EQ presets are deliberately moderate to preserve headroom.
- App version advanced to 1.2 (versionCode 3).

## Important Android limitation
The app processes only the captured bridge copy. When Android is playing the original directly to Bluetooth, a normal app cannot insert its EQ into that direct system route. The phone curve shapes the synchronized phone copy in that mode. The Bluetooth curve shapes the bridge copy when the app routes that copy to Bluetooth. These controls do not alter Android's untouched direct Bluetooth stream.

## Build and test status
Source ZIP only. A fresh APK was not built here: the Gradle wrapper needs Gradle 8.2 from services.gradle.org, which was unreachable in this environment, and no Android SDK was available. Build and test on AndroidForge/GitHub Actions, then verify both routes and listen for clipping on the target phone and speaker.
