# System Audio Bridge — reverse-route experiment

## Changes prepared
- When Android's system media route is Bluetooth, the bridge now chooses the built-in phone speaker for its captured copy. The original system route is not changed.
- When Bluetooth is not the active system media route, the bridge keeps the existing Bluetooth-copy behavior.
- The bridge copy volume label now describes what the control actually changes. The system volume slider is labelled separately.
- Added the synchronization controls referenced by `MainActivity`: a millisecond delay slider (0–300 ms) and a volume-stabilization switch. Delay is applied only to the captured copy; Android apps cannot impose a matching delay on the direct system Bluetooth stream.
- Updated status/help text to explain the automatic route selection.

## Build and test status
These are source changes only. A fresh APK could not be built in the current environment: the Gradle wrapper requires Gradle 8.2 from `services.gradle.org`, which is unreachable here, and the Android SDK configured in `local.properties` (`/opt/android-sdk`) is absent. The pre-existing APK in `app/build/outputs/apk/debug/` is not rebuilt and must not be treated as containing these changes.

## Device validation still required
1. Connect the Bluetooth speaker and choose it in Android's Media output panel.
2. Start the bridge and confirm status says the copy is routed to the phone speaker.
3. Play a non-DRM media source; adjust Delay bridge copy in 1 ms steps until both outputs sound aligned.
4. Check that changing System media volume and Bridge copy volume has the expected separate effects.
5. Switch Android's media route back to This phone and restart the bridge; the copy should go to Bluetooth.

Audio playback capture is limited by Android policy and source-app capture eligibility. DRM/protected apps may produce silence. Delay can compensate only by delaying the copied stream, not by moving the system Bluetooth path earlier or later.
