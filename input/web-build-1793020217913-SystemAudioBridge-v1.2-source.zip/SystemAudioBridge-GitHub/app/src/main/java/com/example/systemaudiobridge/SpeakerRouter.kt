package com.example.systemaudiobridge

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

data class SpeakerTarget(
    val device: AudioDeviceInfo,
    val label: String,
)

object SpeakerRouter {
    fun audioManager(context: Context): AudioManager =
        context.getSystemService(AudioManager::class.java)

    /**
     * Chooses the bridge's *copy* destination. When Android's media route is
     * already Bluetooth, leave that direct system path untouched and play the
     * captured copy through the built-in speaker. Otherwise retain the classic
     * bridge behavior and send the copy to Bluetooth.
     */
    fun findBridgeOutput(context: Context): SpeakerTarget? {
        if (mediaAlreadyOnBluetooth(context)) {
            val phone = findBuiltInSpeaker(context)
            if (phone != null) return SpeakerTarget(phone, "Phone speaker (Bluetooth is primary)")
        }
        return findOutput(context)
    }

    /** Finds an external Bluetooth output for availability/status checks. */
    fun findOutput(context: Context): SpeakerTarget? {
        val outputs = audioManager(context).getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val types = ArrayList<Int>(3)
        types.add(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            types.add(AudioDeviceInfo.TYPE_BLE_SPEAKER)
            types.add(AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
        for (type in types) {
            val match = outputs.firstOrNull { it.type == type } ?: continue
            return SpeakerTarget(match, labelFor(match))
        }
        return null
    }

    fun labelFor(device: AudioDeviceInfo): String {
        val name = try {
            device.productName?.toString()?.trim().orEmpty()
        } catch (_: SecurityException) {
            ""
        }
        if (name.isNotEmpty() && !name.equals("null", ignoreCase = true)) return name
        return when (device.type) {
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth speaker"
            else -> "Bluetooth audio"
        }
    }

    /**
     * True when the system media route is already a Bluetooth output.
     * In that case the phone speaker is usually silent until the user
     * picks "This phone" in the media output panel.
     */
    fun mediaAlreadyOnBluetooth(context: Context): Boolean {
        val am = audioManager(context)
        if (Build.VERSION.SDK_INT >= 33) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build()
            val routed = am.getAudioDevicesForAttributes(attrs)
            if (routed.isNotEmpty()) {
                return routed.any { isBluetoothOutput(it.type) }
            }
        }
        @Suppress("DEPRECATION")
        return am.isBluetoothA2dpOn
    }

    fun findBuiltInSpeaker(context: Context): AudioDeviceInfo? {
        val outputs = audioManager(context).getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        return outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
    }

    fun musicPercent(context: Context): Int {
        val am = audioManager(context)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        return (cur * 100f / max).toInt().coerceIn(0, 100)
    }

    fun setMusicPercent(context: Context, percent: Int) {
        val am = audioManager(context)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val min = if (Build.VERSION.SDK_INT >= 28) am.getStreamMinVolume(AudioManager.STREAM_MUSIC) else 0
        val span = (max - min).coerceAtLeast(0)
        val v = min + (span * (percent.coerceIn(0, 100) / 100f)).toInt()
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v.coerceIn(min, max), 0)
        } catch (_: SecurityException) {
        }
    }

    private fun isBluetoothOutput(type: Int): Boolean {
        if (type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) return true
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        return type == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
            type == AudioDeviceInfo.TYPE_BLE_HEADSET
    }
}
