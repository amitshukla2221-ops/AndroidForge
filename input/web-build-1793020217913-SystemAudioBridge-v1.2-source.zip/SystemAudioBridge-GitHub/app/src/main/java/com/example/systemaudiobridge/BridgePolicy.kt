package com.example.systemaudiobridge

/**
 * Decisions that used to tear the bridge down or couple the two volume sliders.
 * Pure logic so it can be tested without a phone.
 */
object BridgePolicy {
    const val ROUTE_GRACE_MS = 1500L
    const val READ_ERRORS_BEFORE_REOPEN = 6
    const val REOPENS_BEFORE_STOP = 3
    const val MAX_DELAY_MS = 300

    /** Bluetooth copy level. The phone slider is not an input. */
    fun btLinear(percent: Int): Float = percent.coerceIn(0, 100) / 100f

    /** A brief Bluetooth blip during a song change should not stop the bridge. */
    fun giveUpOnRoute(missingForMs: Long): Boolean = missingForMs >= ROUTE_GRACE_MS

    fun shouldReopen(consecutiveErrors: Int): Boolean =
        consecutiveErrors >= READ_ERRORS_BEFORE_REOPEN

    fun shouldStopAfterReopens(reopens: Int): Boolean = reopens > REOPENS_BEFORE_STOP

    fun chooseRate(deviceRates: IntArray): Int {
        if (deviceRates.isEmpty() || deviceRates.any { it == 48000 }) return 48000
        if (deviceRates.any { it == 44100 }) return 44100
        return deviceRates.filter { it in 22050..96000 }.minByOrNull { kotlin.math.abs(it - 48000) } ?: 48000
    }
}
