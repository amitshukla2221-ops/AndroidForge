package com.example.systemaudiobridge

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.sin

/**
 * Local test-tone generator. Samples stay in memory and are discarded on stop.
 */
object ToneEngine {
    enum class Wave { SINE, SQUARE, SAW, NOISE }
    enum class Dest { PHONE, BLUETOOTH, BOTH }

    @Volatile var wave: Wave = Wave.SINE
    @Volatile var dest: Dest = Dest.BOTH
    @Volatile var freqHz: Float = 440f
    @Volatile var playing: Boolean = false

    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val running = AtomicBoolean(false)
    private var thread: Thread? = null
    private var phoneTrack: AudioTrack? = null
    private var btTrack: AudioTrack? = null
    private val lock = Any()

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
        listener()
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun toggle(context: Context) {
        if (playing) stop() else start(context.applicationContext)
    }

    fun start(context: Context) {
        val app = context.applicationContext
        synchronized(lock) {
            stopLocked()
            val wantPhone = dest == Dest.PHONE || dest == Dest.BOTH
            val wantBt = dest == Dest.BLUETOOTH || dest == Dest.BOTH
            val speaker = if (wantBt) SpeakerRouter.findOutput(app) else null
            if (wantBt && speaker == null) {
                BridgeStatus.update(BridgeStatus.Phase.ERROR, app.getString(R.string.error_no_speaker))
                return
            }
            val rate = 48000
            val phone = if (wantPhone) buildTrack(rate, builtin = true, app) else null
            val bt = if (wantBt) buildTrack(rate, builtin = false, app) else null
            if (bt != null && speaker != null && !bt.setPreferredDevice(speaker.device)) {
                bt.release()
                phone?.release()
                BridgeStatus.update(BridgeStatus.Phase.ERROR, app.getString(R.string.error_route))
                return
            }
            if (phone != null) {
                SpeakerRouter.findBuiltInSpeaker(app)?.let { phone.setPreferredDevice(it) }
            }
            phoneTrack = phone
            btTrack = bt
            phone?.play()
            bt?.play()
            running.set(true)
            playing = true
            thread = Thread({
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
                runLoop(rate, phone, bt)
            }, "ToneEngine")
            thread?.start()
        }
        notifyListeners()
    }

    fun stop() {
        synchronized(lock) { stopLocked() }
        notifyListeners()
    }

    private fun stopLocked() {
        running.set(false)
        playing = false
        val worker = thread
        if (worker != null && worker !== Thread.currentThread()) {
            try {
                worker.join(800)
            } catch (_: InterruptedException) {
            }
        }
        thread = null
        release(phoneTrack)
        release(btTrack)
        phoneTrack = null
        btTrack = null
    }

    private fun runLoop(rate: Int, phone: AudioTrack?, bt: AudioTrack?) {
        val frames = 960
        val fxPhone = StereoEq(rate)
        val fxBt = StereoEq(rate)
        val raw = FloatArray(frames * 2)
        val phonePcm = ShortArray(frames * 2)
        val btPcm = ShortArray(frames * 2)
        var phase = 0.0
        var noise = 0x1234567
        while (running.get()) {
            val hz = freqHz.coerceIn(40f, 8000f).toDouble()
            val step = hz / rate
            val shape = wave
            var i = 0
            while (i < frames) {
                phase += step
                if (phase >= 1.0) phase -= 1.0
                val sample = when (shape) {
                    Wave.SINE -> sin(phase * 2.0 * PI).toFloat() * 0.55f
                    Wave.SQUARE -> (if (phase < 0.5) 0.42f else -0.42f)
                    Wave.SAW -> ((phase * 2.0 - 1.0).toFloat()) * 0.42f
                    Wave.NOISE -> {
                        noise = noise xor (noise shl 13)
                        noise = noise xor (noise ushr 17)
                        noise = noise xor (noise shl 5)
                        ((noise and 0xffff) / 32768f - 1f) * 0.28f
                    }
                }
                raw[i * 2] = sample
                raw[i * 2 + 1] = sample
                i++
            }
            var pushed = false
            if (phone != null && phone.playState == AudioTrack.PLAYSTATE_PLAYING) {
                toShort(raw, phonePcm, 1f)
                fxPhone.process(phonePcm, phonePcm.size, MixControl.phoneCopyGain(), MixControl.phoneEqDb)
                phone.write(phonePcm, 0, phonePcm.size)
                LiveLevels.push(phonePcm, phonePcm.size, rate)
                pushed = true
            }
            if (bt != null && bt.playState == AudioTrack.PLAYSTATE_PLAYING) {
                toShort(raw, btPcm, 1f)
                fxBt.process(btPcm, btPcm.size, MixControl.toneBluetoothGain(), MixControl.btEqDb)
                bt.write(btPcm, 0, btPcm.size)
                if (!pushed) LiveLevels.push(btPcm, btPcm.size, rate)
            }
        }
    }

    private fun toShort(src: FloatArray, dst: ShortArray, gain: Float) {
        var i = 0
        while (i < dst.size && i < src.size) {
            val v = (src[i] * gain * 32767f).toInt().coerceIn(-32767, 32767)
            dst[i] = v.toShort()
            i++
        }
    }

    private fun buildTrack(rate: Int, builtin: Boolean, context: Context): AudioTrack {
        val min = AudioTrack.getMinBufferSize(
            rate,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(rate / 5)
        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(
                        if (builtin) AudioAttributes.CONTENT_TYPE_SONIFICATION
                        else AudioAttributes.CONTENT_TYPE_MUSIC
                    )
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(min * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
        return builder.build()
    }

    private fun release(track: AudioTrack?) {
        if (track == null) return
        try {
            track.pause()
        } catch (_: Exception) {
        }
        try {
            track.flush()
        } catch (_: Exception) {
        }
        try {
            track.stop()
        } catch (_: Exception) {
        }
        try {
            track.release()
        } catch (_: Exception) {
        }
    }

    private fun notifyListeners() {
        for (listener in listeners) listener()
    }
}
