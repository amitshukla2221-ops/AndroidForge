package com.example.systemaudiobridge

import android.content.Context
import kotlin.math.abs

/**
 * Phone level is the system media stream only.
 * Bluetooth level, delay, and the stabilizer never read that stream back.
 */
object MixControl {
    val BANDS_HZ = intArrayOf(60, 160, 400, 1000, 2500, 8000)

    @Volatile var phonePercent: Int = 100
    @Volatile var btPercent: Int = 100
    @Volatile var phoneCopyPercent: Int = 100
    @Volatile var delayMs: Int = 0
    @Volatile var stabilize: Boolean = false
    @Volatile var phoneEqDb: FloatArray = FloatArray(BANDS_HZ.size)
    @Volatile var btEqDb: FloatArray = FloatArray(BANDS_HZ.size)

    @Volatile private var ready = false

    fun ensureInit(context: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            phonePercent = SpeakerRouter.musicPercent(context)
            ready = true
        }
    }

    fun setPhone(context: Context, percent: Int) {
        val p = percent.coerceIn(0, 100)
        phonePercent = p
        SpeakerRouter.setMusicPercent(context, p)
    }

    fun setBand(phone: Boolean, index: Int, db: Float) {
        val current = if (phone) phoneEqDb else btEqDb
        val next = current.copyOf()
        next[index.coerceIn(0, next.lastIndex)] = db.coerceIn(-12f, 12f)
        if (phone) phoneEqDb = next else btEqDb = next
    }

    fun setBands(phone: Boolean, values: FloatArray) {
        val next = FloatArray(BANDS_HZ.size)
        for (i in next.indices) next[i] = values.getOrElse(i) { 0f }.coerceIn(-12f, 12f)
        if (phone) phoneEqDb = next else btEqDb = next
    }

    fun copyGain(phone: Boolean): Float =
        (if (phone) phoneCopyPercent else btPercent).coerceIn(0, 150) / 100f

    fun eqActive(eq: FloatArray): Boolean = eq.any { abs(it) >= 0.25f }

    fun btGain(): Float = copyGain(false)

    fun phoneCopyGain(): Float = copyGain(true)

    fun toneBluetoothGain(): Float = btGain()

    
}
