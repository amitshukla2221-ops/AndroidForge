package com.example.systemaudiobridge

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Optional slow level rider for the Bluetooth copy.
 * Boost is capped at +6 dB. Peaks are limited so a loud song cannot square off.
 */
class LevelStabilizer {
    private var env = 0.05f
    private var agc = 1f

    fun apply(buf: ShortArray, count: Int, slider: Float, enabled: Boolean) {
        val target = slider.coerceIn(0f, 1.5f)
        if (!enabled) {
            Limiter.apply(buf, count, target)
            return
        }
        if (target <= 0.001f) {
            java.util.Arrays.fill(buf, 0, count, 0.toShort())
            return
        }
        var sum = 0.0
        var n = 0
        var i = 0
        while (i < count) {
            val s = buf[i] / 32768.0
            sum += s * s
            i++
            n++
        }
        val rms = sqrt(sum / n.coerceAtLeast(1)).toFloat()
        val follow = if (rms > env) 0.4f else 0.08f
        env += (rms - env) * follow
        val desired = 0.09f * target
        val want = if (env < 0.0008f) agc else (desired / env).coerceIn(0.25f, 2f)
        val glide = if (want < agc) 0.3f else 0.05f
        agc += (want - agc) * glide
        Limiter.apply(buf, count, agc)
    }

    fun currentAgc(): Float = agc
}

object Limiter {
    fun apply(buf: ShortArray, count: Int, gain: Float) {
        if (gain <= 0.001f) {
            java.util.Arrays.fill(buf, 0, count, 0.toShort())
            return
        }
        var i = 0
        while (i < count) {
            var n = buf[i] / 32768f * gain
            val ax = abs(n)
            if (ax > 0.9f) {
                val sign = if (n < 0f) -1f else 1f
                val over = (ax - 0.9f) / 0.9f
                n = sign * (0.9f + 0.08f * (over / (1f + over)))
            }
            buf[i] = (n * 32767f).toInt().coerceIn(-32767, 32767).toShort()
            i++
        }
    }
}
