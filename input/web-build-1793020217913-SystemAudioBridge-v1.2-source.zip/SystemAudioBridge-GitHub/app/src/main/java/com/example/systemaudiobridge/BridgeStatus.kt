package com.example.systemaudiobridge

import java.util.concurrent.CopyOnWriteArrayList

object BridgeStatus {
    enum class Phase { IDLE, BRIDGING, ERROR }

    data class Snapshot(val phase: Phase, val detail: String)

    @Volatile
    private var current = Snapshot(Phase.IDLE, "Connect a Bluetooth speaker, then start the bridge.")

    private val listeners = CopyOnWriteArrayList<(Snapshot) -> Unit>()

    fun snapshot(): Snapshot = current

    fun update(phase: Phase, detail: String) {
        val next = Snapshot(phase, detail)
        current = next
        for (listener in listeners) {
            listener(next)
        }
    }

    fun addListener(listener: (Snapshot) -> Unit) {
        listeners.add(listener)
        listener(current)
    }

    fun removeListener(listener: (Snapshot) -> Unit) {
        listeners.remove(listener)
    }
}
