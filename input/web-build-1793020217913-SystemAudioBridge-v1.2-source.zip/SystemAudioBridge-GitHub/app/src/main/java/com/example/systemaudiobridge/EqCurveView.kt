package com.example.systemaudiobridge

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln

/** Smooth frequency curve, the same idea as a wavelet graphic EQ. */
class EqCurveView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var gains: FloatArray = FloatArray(MixControl.BANDS_HZ.size)
        set(value) {
            field = value
            invalidate()
        }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x55E2A23A
        style = Paint.Style.FILL
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE2A23A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
    }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF31342C.toInt()
        strokeWidth = dp(1f)
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFF3F1EA.toInt()
        style = Paint.Style.FILL
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA39E92.toInt()
        textSize = dp(10f)
    }
    private val curve = Path()
    private val freqs = MixControl.BANDS_HZ

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = dp(8f)
        val right = width - dp(8f)
        val top = dp(14f)
        val bottom = height - dp(16f)
        if (right <= left || bottom <= top) return
        val mid = (top + bottom) / 2f

        canvas.drawLine(left, top, right, top, grid)
        canvas.drawLine(left, mid, right, mid, grid)
        canvas.drawLine(left, bottom, right, bottom, grid)
        canvas.drawText("+12", left, top - dp(2f), text)
        canvas.drawText("0", left, mid - dp(2f), text)
        canvas.drawText("-12", left, bottom - dp(2f), text)

        val steps = 72
        val linePath = Path()
        var firstX = left
        for (s in 0..steps) {
            val t = s / steps.toFloat()
            val freq = (30.0 * Math.pow(16000.0 / 30.0, t.toDouble())).toFloat()
            val x = left + (right - left) * t
            val y = yFor(gainAt(freq), top, bottom)
            if (s == 0) {
                firstX = x
                linePath.moveTo(x, y)
            } else {
                linePath.lineTo(x, y)
            }
        }
        curve.rewind()
        curve.addPath(linePath)
        curve.lineTo(right, mid)
        curve.lineTo(firstX, mid)
        curve.close()
        canvas.drawPath(curve, fill)
        canvas.drawPath(linePath, stroke)

        for (i in freqs.indices) {
            val t = logT(freqs[i].toFloat(), 30f, 16000f)
            val x = left + (right - left) * t
            val db = gains.getOrElse(i) { 0f }
            val y = yFor(db, top, bottom)
            canvas.drawCircle(x, y, dp(3.2f), dot)
        }
    }

    private fun yFor(db: Float, top: Float, bottom: Float): Float {
        val clamped = db.coerceIn(-12f, 12f)
        val n = (12f - clamped) / 24f
        return top + (bottom - top) * n
    }

    private fun gainAt(freq: Float): Float {
        if (gains.isEmpty()) return 0f
        if (freq <= freqs[0]) return gains[0]
        if (freq >= freqs.last()) return gains.last()
        var i = 0
        while (i < freqs.size - 1 && freq > freqs[i + 1]) i++
        val f0 = ln(freqs[i].toFloat())
        val f1 = ln(freqs[i + 1].toFloat())
        val denom = (f1 - f0).takeIf { it != 0f } ?: return gains[i]
        val t = ((ln(freq) - f0) / denom).coerceIn(0f, 1f)
        val s = ((1.0 - cos(t * PI)) / 2.0).toFloat()
        val g0 = gains.getOrElse(i) { 0f }
        val g1 = gains.getOrElse(i + 1) { 0f }
        return g0 * (1f - s) + g1 * s
    }

    private fun logT(freq: Float, min: Float, max: Float): Float {
        val denom = ln(max / min)
        if (denom == 0f) return 0f
        return (ln(freq.coerceIn(min, max) / min) / denom).coerceIn(0f, 1f)
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
}
