package com.example.systemaudiobridge

/**
 * Sample-accurate delay for the Bluetooth copy only.
 * Delay 0 writes each sample back unchanged. The buffer is memory only.
 */
class StereoDelay(private val rate: Int, maxMs: Int = BridgePolicy.MAX_DELAY_MS) {
    private val cap = (rate.coerceAtLeast(8000) * maxMs / 1000).coerceAtLeast(2)
    private val left = ShortArray(cap)
    private val right = ShortArray(cap)
    private var write = 0

    fun apply(buf: ShortArray, samples: Int, delayMs: Int) {
        if (samples < 2) return
        val frames = (rate * delayMs.coerceIn(0, BridgePolicy.MAX_DELAY_MS) / 1000).coerceIn(0, cap - 1)
        var i = 0
        while (i + 1 < samples) {
            left[write] = buf[i]
            right[write] = buf[i + 1]
            val read = if (write >= frames) write - frames else write - frames + cap
            buf[i] = left[read]
            buf[i + 1] = right[read]
            write++
            if (write == cap) write = 0
            i += 2
        }
    }
}
