package com.example.systemaudiobridge

import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max

/** Short scrolling peaks for the on-screen wave. Never stored to disk. */
object LiveLevels {
    const val BARS = 56

    private val bars = FloatArray(BARS)
    private val lock = Any()
    private var acc = 0
    private var accFrames = 0

    @Volatile var lastMs: Long = 0L

    fun push(pcm: ShortArray, samples: Int, rate: Int) {
        val perBar = (rate / 18).coerceAtLeast(128)
        var i = 0
        while (i + 1 < samples) {
            val peak = max(abs(pcm[i].toInt()), abs(pcm[i + 1].toInt()))
            if (peak > acc) acc = peak
            accFrames++
            if (accFrames >= perBar) {
                scroll(acc / 32768f)
                acc = 0
                accFrames = 0
            }
            i += 2
        }
        lastMs = SystemClock.elapsedRealtime()
    }

    fun copyInto(out: FloatArray) {
        synchronized(lock) {
            val n = minOf(out.size, BARS)
            System.arraycopy(bars, 0, out, 0, n)
        }
    }

    private fun scroll(value: Float) {
        synchronized(lock) {
            System.arraycopy(bars, 1, bars, 0, BARS - 1)
            bars[BARS - 1] = value.coerceIn(0f, 1f)
        }
    }
}
