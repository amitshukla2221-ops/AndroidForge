package com.example.systemaudiobridge

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View

/** Live mirrored wave of what is being sent out. Draws nothing from storage. */
class WaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    private val bars = FloatArray(LiveLevels.BARS)
    private val wave = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE2A23A.toInt()
        style = Paint.Style.FILL
        alpha = 210
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x66F3F1EA
        strokeWidth = dp(1f)
        style = Paint.Style.STROKE
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA39E92.toInt()
        textSize = dp(11f)
    }
    private var running = false

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            val fresh = SystemClock.elapsedRealtime() - LiveLevels.lastMs < 280L
            if (fresh) {
                LiveLevels.copyInto(bars)
            } else {
                for (i in bars.indices) bars[i] *= 0.84f
            }
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        Choreographer.getInstance().postFrameCallback(frame)
    }

    override fun onDetachedFromWindow() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w < 2f || h < 2f) return
        val mid = h / 2f
        val amp = h * 0.42f
        val n = bars.size
        val step = w / (n - 1).coerceAtLeast(1)

        wave.rewind()
        wave.moveTo(0f, mid)
        for (i in 0 until n) {
            wave.lineTo(i * step, mid - bars[i] * amp)
        }
        for (i in n - 1 downTo 0) {
            wave.lineTo(i * step, mid + bars[i] * amp * 0.72f)
        }
        wave.close()
        canvas.drawPath(wave, fill)
        canvas.drawLine(0f, mid, w, mid, line)

        var quiet = 0f
        for (v in bars) if (v > quiet) quiet = v
        val caption = if (quiet > 0.02f) "LIVE" else "QUIET"
        canvas.drawText(caption, dp(10f), dp(16f), label)
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
}
