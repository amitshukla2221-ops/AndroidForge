package com.example.systemaudiobridge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class BridgeLogicTest {
    @Test
    fun bluetoothGainIgnoresPhoneLevel() {
        assertEquals(0.4f, BridgePolicy.btLinear(40), 0.0001f)
        assertEquals(1f, BridgePolicy.btLinear(100), 0.0001f)
        assertEquals(0f, BridgePolicy.btLinear(0), 0.0001f)
        assertEquals(1f, BridgePolicy.btLinear(140), 0.0001f)
    }

    @Test
    fun songChangeBlipDoesNotDropTheBridge() {
        assertFalse(BridgePolicy.giveUpOnRoute(0))
        assertFalse(BridgePolicy.giveUpOnRoute(400))
        assertFalse(BridgePolicy.giveUpOnRoute(1499))
        assertTrue(BridgePolicy.giveUpOnRoute(1500))
    }

    @Test
    fun captureErrorsReopenBeforeStopping() {
        assertFalse(BridgePolicy.shouldReopen(1))
        assertFalse(BridgePolicy.shouldReopen(5))
        assertTrue(BridgePolicy.shouldReopen(6))
        assertFalse(BridgePolicy.shouldStopAfterReopens(3))
        assertTrue(BridgePolicy.shouldStopAfterReopens(4))
    }

    @Test
    fun sampleRatePrefersBluetoothNative() {
        assertEquals(48000, BridgePolicy.chooseRate(intArrayOf()))
        assertEquals(48000, BridgePolicy.chooseRate(intArrayOf(44100, 48000)))
        assertEquals(44100, BridgePolicy.chooseRate(intArrayOf(44100, 16000)))
        assertEquals(32000, BridgePolicy.chooseRate(intArrayOf(8000, 32000)))
    }

    @Test
    fun delayZeroIsTransparentAndPositiveDelayShifts() {
        val delay = StereoDelay(rate = 1000, maxMs = 300)
        val input = shortArrayOf(1000, -1000, 2000, -2000, 3000, -3000, 4000, -4000)
        val copy = input.copyOf()
        delay.apply(copy, copy.size, 0)
        assertTrue(copy.contentEquals(input))

        val delayed = StereoDelay(rate = 1000, maxMs = 300)
        val buf = input.copyOf()
        delayed.apply(buf, buf.size, 2)
        assertEquals(0, buf[0].toInt())
        assertEquals(0, buf[1].toInt())
        assertEquals(1000, buf[4].toInt())
        assertEquals(-1000, buf[5].toInt())
    }

    @Test
    fun stabilizerCapsBoostNearSixDb() {
        val stab = LevelStabilizer()
        val quiet = ShortArray(2000) { 400 }
        val before = 400.0
        stab.apply(quiet, quiet.size, slider = 1f, enabled = true)
        val after = quiet.maxOf { abs(it.toInt()) }.toDouble()
        assertTrue("boost ${after / before} exceeded +6 dB", after / before < 2.15)
        assertTrue(quiet.all { abs(it.toInt()) <= 32767 })
    }

    @Test
    fun limiterDoesNotSquareOffAHotSignal() {
        val hot = ShortArray(64) { 30000 }
        Limiter.apply(hot, hot.size, 4f)
        assertTrue(hot.all { it > 28000 && it < 32767 })
    }

    @Test
    fun fixedSliderDoesNotExplode() {
        val buf = ShortArray(8) { 16000 }
        Limiter.apply(buf, buf.size, 0.5f)
        assertEquals(8000, buf[0].toInt(), 40)
    }

    private fun assertEquals(expected: Int, actual: Int, tolerance: Int) {
        assertTrue("expected $expected ±$tolerance but was $actual", abs(expected - actual) <= tolerance)
    }
}
