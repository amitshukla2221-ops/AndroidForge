# Build System Audio Bridge APK on GitHub (phone-friendly workflow)

This repository contains the Android project and a GitHub Actions workflow. GitHub's cloud runner will download Gradle/Android build dependencies and produce a **debug APK** as a downloadable artifact.

## 1. Create a GitHub repository
1. Open https://github.com/new and sign in.
2. Repository name: `SystemAudioBridge`.
3. Choose **Private** if you don't want the source public. Select **Create repository**.
4. On your computer, extract this ZIP. The folder you upload must contain `settings.gradle.kts`, `build.gradle.kts`, `gradlew`, `app/`, and `.github/` at the repository root. Do not upload the ZIP as a single file and expect GitHub to extract it.

## 2. Upload the extracted files
GitHub's web uploader can upload files, but not upload a ZIP and automatically unpack it. On a computer, open the new repository, choose **Add file → Upload files**, drag the extracted project files/folders into the page, then commit. If you're using only an Android phone, use a Git client that can push a local folder, or a cloud IDE that can import a ZIP and push the extracted files to GitHub. Avoid putting passwords or signing keys in the repository.

## 3. Run the APK build
1. In the repository, open **Actions**.
2. Approve/enable Actions if GitHub asks.
3. Choose **Build Android APK** on the left.
4. Tap **Run workflow**, choose `main`, then run it. A push to `main` also triggers a build.
5. Wait for the run to finish with a green check mark. If it fails, open the run and read the first red error step.
6. Open the successful run and scroll to **Artifacts**. Download `SystemAudioBridge-debug-apk` and extract the downloaded artifact ZIP to get `app-debug.apk`.
7. Transfer `app-debug.apk` to the phone and install it. Android may ask you to allow installation from the browser/files app.

## Important limitations
- This workflow builds the code; it does not prove that Bluetooth and phone-speaker audio are synchronized. Test with your actual Android phone and Bluetooth speaker.
- This is a debug-signed APK for testing, not a Play Store release. Installing over an app signed with a different key may fail; uninstall the older app first (this can erase its app data) or use the original signing key.
- Android playback capture can be blocked by DRM or by the source app's capture policy.
- A delay slider can delay the captured copy, but a normal third-party app cannot arbitrarily delay or advance Android's direct Bluetooth system output.
