SYSTEM AUDIO BRIDGE 2.3.4 — ANDROID 12

This is a Gradle source project ZIP for AndroidForge, not a prebuilt or device-tested APK.

Changes in 2.3.4:
- Removed automatic calls that set/mute Android STREAM_MUSIC when the two output copies start.
- The shared capture ring is documented and reported as the silent virtual timing reference.
- UI/status text warns that original app playback is unchanged and may cause echo.
- Version bumped to 2.3.4.

Important platform constraint:
Android AudioPlaybackCapture duplicates eligible app audio; it does not take ownership of or reroute the source app's original playback. On a normal Android 12 device, a third-party app cannot universally suppress only the source's built-in-speaker route while preserving the system media volume. Without muting the original stream or using privileged/system-level routing, echo may remain. This ZIP intentionally prioritizes preserving the user's system volume, so it does NOT promise echo-free dual output.

Capture is limited to apps/sounds allowed by Android playback-capture policy (typically media/game usage, user consent, same user profile). Some apps prohibit capture.

Checks performed: ZIP integrity; Gradle version fields; service source contains no call to silence.holdMusic; new status warning present. No Gradle build or physical-device audio test was available in this environment.
