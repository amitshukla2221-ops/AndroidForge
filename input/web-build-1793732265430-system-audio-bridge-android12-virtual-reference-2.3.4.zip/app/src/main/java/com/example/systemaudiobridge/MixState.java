package com.example.systemaudiobridge;

public final class MixState {
    public static volatile int speakerVolume = 100;
    public static volatile int speakerShiftMs = 0;
    public static volatile boolean speakerMuted = false;
    public static final int[] speakerEq = new int[EqPresets.BANDS];

    public static volatile int btVolume = 100;
    public static volatile int btShiftMs = 0;
    public static volatile boolean btMuted = false;
    public static final int[] btEq = new int[EqPresets.BANDS];

    public static volatile boolean running = false;
    public static volatile boolean hearing = false;
    public static volatile boolean originalQuiet = false;
    public static volatile int captureRate = 48000;

    public static volatile String status = "Idle. Start the bridge, then play audio in another app.";
    public static volatile String primaryLabel = "Together · 0 ms";
    public static volatile String originalLabel = "Each level slider controls only that speaker. Nothing is blended across them.";
    public static volatile String speakerRoute = "Built-in speaker";
    public static volatile String btRoute = "Nothing connected";
    public static volatile String path = "";
    public static volatile String speakerPreset = "Flat";
    public static volatile String btPreset = "Flat";

    private MixState() {
    }

    public static int clampVol(int value) {
        if (value < 0) {
            return 0;
        }
        if (value > 100) {
            return 100;
        }
        return value;
    }

    public static void copySpeakerEq(int[] dest) {
        synchronized (speakerEq) {
            System.arraycopy(speakerEq, 0, dest, 0, EqPresets.BANDS);
        }
    }

    public static void copyBtEq(int[] dest) {
        synchronized (btEq) {
            System.arraycopy(btEq, 0, dest, 0, EqPresets.BANDS);
        }
    }

    public static void setSpeakerBand(int index, int db) {
        synchronized (speakerEq) {
            speakerEq[index] = EqPresets.clampDb(db);
            speakerPreset = EqPresets.match(speakerEq);
        }
    }

    public static void setBtBand(int index, int db) {
        synchronized (btEq) {
            btEq[index] = EqPresets.clampDb(db);
            btPreset = EqPresets.match(btEq);
        }
    }

    public static void applySpeakerPreset(String name) {
        synchronized (speakerEq) {
            EqPresets.apply(name, speakerEq);
            speakerPreset = EqPresets.match(speakerEq);
        }
    }

    public static void applyBtPreset(String name) {
        synchronized (btEq) {
            EqPresets.apply(name, btEq);
            btPreset = EqPresets.match(btEq);
        }
    }
}
