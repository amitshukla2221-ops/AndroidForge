package com.example.systemaudiobridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;

/**
 * One capture of other apps, then two independent copies.
 * Each copy is opened once onto its own device and left there.
 * Sync comes only from the sliders. Volume is applied inside that copy only.
 * Tracks are never flushed, never moved to the other speaker, and never cycled
 * through stream types after a pin succeeds.
 */
public final class AudioBridgeService extends Service {
    public static final String ACTION_START = "com.example.systemaudiobridge.START";
    public static final String ACTION_STOP = "com.example.systemaudiobridge.STOP";
    public static final String EXTRA_CODE = "resultCode";
    public static final String EXTRA_DATA = "data";

    private static final String TAG = "AudioBridge";
    private static final String CHANNEL = "audio_bridge_v22";
    private static final int NOTIFICATION_ID = 42;
    private static final int CHUNK = 1024;
    /** Non-music usages, tried once. Music is the last resort because muting it would silence that copy. */
    private static final int[] PIN_USAGES = {
            AudioAttributes.USAGE_ALARM,
            AudioAttributes.USAGE_ASSISTANCE_SONIFICATION,
            AudioAttributes.USAGE_NOTIFICATION,
            AudioAttributes.USAGE_NOTIFICATION_EVENT
    };

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final SystemSilence silence = new SystemSilence();
    private final Object routeLock = new Object();
    private final short[] silenceChunk = new short[CHUNK];

    private final AudioDeviceCallback deviceCallback = new AudioDeviceCallback() {
        @Override
        public void onAudioDevicesAdded(AudioDeviceInfo[] added) {
            devicesChanged = true;
        }

        @Override
        public void onAudioDevicesRemoved(AudioDeviceInfo[] removed) {
            devicesChanged = true;
        }
    };

    private MediaProjection projection;
    private MediaSession session;
    private AudioPlaybackCaptureConfiguration captureConfig;
    private AudioRecord record;
    private RingBuffer ring;
    private int rate = 48000;
    private volatile boolean running;
    private boolean halted;
    private boolean devicesRegistered;
    private volatile boolean devicesChanged;
    private boolean silenceGaveUp;
    private String quietNote = "";
    private String lastSignature = "";
    private PowerManager.WakeLock wakeLock;

    private volatile AudioTrack speakerTrack;
    private volatile AudioTrack btTrack;
    private AudioDeviceInfo speakerDevice;
    private AudioDeviceInfo btDevice;
    private int speakerDevId = Integer.MIN_VALUE;
    private int btDevId = Integer.MIN_VALUE;
    // Lock the Bluetooth output chosen at session start. Do not silently hop to another device.
    private int selectedBluetoothId = Integer.MIN_VALUE;
    private int speakerFailedId = Integer.MIN_VALUE;
    private int btFailedId = Integer.MIN_VALUE;
    private int speakerUsage = -1;
    private int btUsage = -1;

    private Thread captureThread;
    private Thread speakerThread;
    private Thread btThread;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (!MixState.running) {
            SystemSilence.recoverAbandoned(this);
        }
        NotificationChannel channel = new NotificationChannel(
                CHANNEL, "Audio bridge", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Keeps the audio bridge alive");
        channel.setSound(null, null);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(channel);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            MixState.status = "Stopped. Levels were left as you set them.";
            MixState.running = false;
            BridgeBus.post();
            requestHalt();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) || running) {
            return START_NOT_STICKY;
        }
        try {
            startForeground(
                    NOTIFICATION_ID,
                    notification("Starting bridge"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } catch (Exception e) {
            Log.e(TAG, "foreground", e);
            MixState.status = "Android blocked the bridge notification.";
            MixState.running = false;
            BridgeBus.post();
            stopSelf();
            return START_NOT_STICKY;
        }
        int code = intent.getIntExtra(EXTRA_CODE, 0);
        Intent data = readData(intent);
        if (data == null) {
            fail("Capture permission missing. Start again.");
            return START_NOT_STICKY;
        }
        try {
            startCapture(code, data);
        } catch (Throwable t) {
            Log.e(TAG, "start", t);
            String message = "no-speaker".equals(t.getMessage())
                    ? "No built-in speaker available."
                    : "Could not start capture. Allow screen audio and retry.";
            fail(message);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        requestHalt();
        super.onDestroy();
    }

    private void startCapture(int resultCode, Intent data) {
        Prefs.load(this);
        AudioManager am = Devices.audioManager(this);
        if (Devices.builtInSpeaker(am) == null) {
            throw new IllegalStateException("no-speaker");
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        MediaProjection created = mpm.getMediaProjection(resultCode, data);
        if (created == null) {
            throw new IllegalStateException("projection");
        }
        projection = created;
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                if (running) {
                    MixState.status = "Capture stopped.";
                    MixState.running = false;
                    BridgeBus.post();
                }
                requestHalt();
            }
        }, mainHandler);

        rate = 48000;
        captureConfig = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build();
        record = openRecord(rate);
        if (record == null) {
            rate = 44100;
            record = openRecord(rate);
        }
        if (record == null) {
            throw new IllegalStateException("record");
        }
        MixState.captureRate = rate;
        ring = new RingBuffer(rate, 4);
        record.startRecording();
        openSession();

        silenceGaveUp = false;
        quietNote = "";
        speakerDevId = Integer.MIN_VALUE;
        btDevId = Integer.MIN_VALUE;
        selectedBluetoothId = Integer.MIN_VALUE;
        speakerFailedId = Integer.MIN_VALUE;
        btFailedId = Integer.MIN_VALUE;
        speakerUsage = -1;
        btUsage = -1;
        MixState.originalQuiet = false;
        devicesChanged = true;

        running = true;
        MixState.running = true;
        acquireWake();
        if (!devicesRegistered) {
            am.registerAudioDeviceCallback(deviceCallback, mainHandler);
            devicesRegistered = true;
        }
        captureThread = new Thread(new Runnable() {
            @Override
            public void run() {
                captureLoop();
            }
        }, "BridgeCapture");
        speakerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                playLoop(true);
            }
        }, "BridgeSpeaker");
        btThread = new Thread(new Runnable() {
            @Override
            public void run() {
                playLoop(false);
            }
        }, "BridgeBluetooth");
        captureThread.start();
        speakerThread.start();
        btThread.start();
        MixState.status = "Starting both outputs…";
        BridgeBus.post();
    }

    private void captureLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        short[] buf = new short[CHUNK];
        int errors = 0;
        while (running) {
            if (devicesChanged) {
                devicesChanged = false;
                try {
                    reconcile();
                } catch (Throwable t) {
                    Log.w(TAG, "route", t);
                }
            }
            int n;
            try {
                n = record.read(buf, 0, buf.length);
            } catch (Throwable t) {
                n = -1;
            }
            if (n < 0) {
                errors++;
                if (errors >= 8) {
                    errors = 0;
                    reopenRecord();
                } else {
                    sleep(15);
                }
                continue;
            }
            errors = 0;
            if (n < 2) {
                sleep(4);
                continue;
            }
            if ((n & 1) != 0) {
                n--;
            }
            ring.write(buf, n);
            boolean hot = Pcm.audible(buf, n);
            if (hot != MixState.hearing) {
                MixState.hearing = hot;
                publishRoute();
            }
        }
    }

    /**
     * Plays one copy. The buffer, gain, EQ, and delay belong to this side only.
     * A slider change moves this side's read cursor. It does not pause, flush, or reroute the track.
     */
    private void playLoop(final boolean speakerSide) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        short[] buf = new short[CHUNK];
        long[] cursor = new long[] {0L};
        Tone tone = new Tone(rate);
        int[] db = new int[EqPresets.BANDS];
        int appliedDelay = -1;
        int pendingDelay = Integer.MIN_VALUE;
        long pendingSince = 0L;
        AudioTrack seen = null;
        while (running) {
            AudioTrack track = speakerSide ? speakerTrack : btTrack;
            if (track == null || ring == null) {
                sleep(20);
                continue;
            }
            if (track != seen) {
                seen = track;
                cursor[0] = -1L;
                appliedDelay = -1;
                tone = new Tone(rate);
            }
            int shift = speakerSide ? MixState.speakerShiftMs : MixState.btShiftMs;
            int other = speakerSide ? MixState.btShiftMs : MixState.speakerShiftMs;
            int delayMs = Sync.absoluteDelayMs(shift, other);
            long now = SystemClock.elapsedRealtime();
            boolean snap = cursor[0] < 0;
            int useDelay = delayMs;
            if (!snap && delayMs != appliedDelay) {
                if (delayMs != pendingDelay) {
                    pendingDelay = delayMs;
                    pendingSince = now;
                } else if (now - pendingSince >= 80L) {
                    snap = true;
                }
                if (!snap && appliedDelay >= 0) {
                    useDelay = appliedDelay;
                }
            }
            int delayFrames = Sync.delayFrames(rate, useDelay);
            int n = ring.read(buf, buf.length, cursor, delayFrames, snap);
            if (snap) {
                appliedDelay = useDelay;
                pendingDelay = appliedDelay;
            }
            if (n < 2) {
                sleep(3);
                continue;
            }
            if (speakerSide) {
                MixState.copySpeakerEq(db);
            } else {
                MixState.copyBtEq(db);
            }
            boolean muted = speakerSide ? MixState.speakerMuted : MixState.btMuted;
            int vol = speakerSide ? MixState.speakerVolume : MixState.btVolume;
            float gain = muted || vol <= 0 ? 0f : vol / 100f;
            tone.process(buf, n, gain, db);
            if (snap) {
                Pcm.fadeIn(buf, n, 32);
            }
            int off = 0;
            while (off < n && running) {
                AudioTrack current = speakerSide ? speakerTrack : btTrack;
                if (current == null || current != track) {
                    break;
                }
                int wrote;
                try {
                    wrote = current.write(buf, off, n - off);
                } catch (Throwable t) {
                    wrote = 0;
                    sleep(20);
                    break;
                }
                if (wrote < 0) {
                    // Keep the same track. Reopening here is what made the sound hop.
                    sleep(20);
                    break;
                }
                if (wrote == 0) {
                    sleep(2);
                    continue;
                }
                off += wrote;
            }
        }
    }

    /**
     * Opens a side only when it has no track, or when that device actually appeared or disappeared.
     * A live track on the same device id is never replaced. A device that already failed is not retried
     * until its id changes, so a callback storm cannot hop the audio.
     */
    private void reconcile() {
        synchronized (routeLock) {
            if (!running) {
                return;
            }
            AudioDeviceInfo sp = Devices.builtInSpeaker(Devices.audioManager(this));
            AudioDeviceInfo bt = getSessionBluetoothOutput();
            if (sp == null) {
                if (speakerTrack != null) {
                    dropSpeaker();
                }
                speakerDevice = null;
                speakerDevId = Integer.MIN_VALUE;
            } else if (speakerTrack != null && sp.getId() == speakerDevId) {
                speakerDevice = sp;
            } else if (speakerTrack == null && sp.getId() == speakerFailedId) {
                speakerDevice = sp;
            } else {
                int remembered = speakerUsage;
                dropSpeaker();
                Opened opened = openPinned(sp, remembered);
                speakerTrack = opened.track;
                speakerUsage = opened.usage;
                speakerDevice = sp;
                if (speakerTrack == null) {
                    speakerDevId = Integer.MIN_VALUE;
                    speakerFailedId = sp.getId();
                } else {
                    speakerDevId = sp.getId();
                    speakerFailedId = Integer.MIN_VALUE;
                }
                Log.i(TAG, "speaker usage " + speakerUsage + " id " + speakerDevId);
            }
            if (bt == null) {
                if (btTrack != null) {
                    dropBt();
                }
                btDevice = null;
                btDevId = Integer.MIN_VALUE;
            } else if (btTrack != null && bt.getId() == btDevId) {
                btDevice = bt;
            } else if (btTrack == null && bt.getId() == btFailedId) {
                btDevice = bt;
            } else {
                int remembered = btUsage;
                dropBt();
                Opened opened = openPinned(bt, remembered);
                btTrack = opened.track;
                btUsage = opened.usage;
                btDevice = bt;
                if (btTrack == null) {
                    btDevId = Integer.MIN_VALUE;
                    btFailedId = bt.getId();
                } else {
                    btDevId = bt.getId();
                    btFailedId = Integer.MIN_VALUE;
                }
                Log.i(TAG, "bluetooth usage " + btUsage + " id " + btDevId);
            }
            maybeSilence();
            publishRoute();
        }
    }

    /**
     * The shared capture ring is the silent virtual reference: it has a clock and sample
     * position but is never attached to a physical output. The two AudioTracks read copies
     * from that same reference with their own manual offsets and gains.
     *
     * IMPORTANT Android limitation: AudioPlaybackCapture copies eligible playback; it does
     * not reroute or silence the originating app. This service deliberately does NOT change
     * STREAM_MUSIC or mute the original stream. Therefore the source app may still be audible
     * through Android's normal route, which can sound like an echo when the tablet copy plays.
     * An ordinary third-party app on Android 12 cannot universally mute only that original
     * physical route while preserving the system media volume. Do not pretend otherwise.
     */
    private void maybeSilence() {
        MixState.originalQuiet = false;
        if (speakerTrack != null && btTrack != null) {
            quietNote = "Silent reference active. Original app playback is unchanged; if you hear an echo, Android is still playing the source separately.";
        } else {
            quietNote = "Silent reference ready. Both outputs must connect; original app playback is unchanged.";
        }
    }

    private Opened openPinned(AudioDeviceInfo device, int rememberedUsage) {
        if (rememberedUsage >= 0) {
            Opened again = tryOpen(device, rememberedUsage);
            if (again.track != null) {
                return again;
            }
        }
        for (int i = 0; i < PIN_USAGES.length; i++) {
            int usage = PIN_USAGES[i];
            if (usage == rememberedUsage) {
                continue;
            }
            Opened opened = tryOpen(device, usage);
            if (opened.track != null) {
                return opened;
            }
        }
        if (rememberedUsage != AudioAttributes.USAGE_MEDIA) {
            return tryOpen(device, AudioAttributes.USAGE_MEDIA);
        }
        return new Opened();
    }

    /** Keeps the track only when it actually landed on the requested device. */
    private Opened tryOpen(AudioDeviceInfo device, int usage) {
        Opened opened = new Opened();
        AudioTrack track = buildTrack(usage);
        if (track == null) {
            return opened;
        }
        boolean pinned;
        try {
            pinned = track.setPreferredDevice(device);
        } catch (Throwable t) {
            pinned = false;
        }
        if (!pinned) {
            releaseTrack(track);
            return opened;
        }
        try {
            track.setVolume(1f);
            track.play();
            track.write(silenceChunk, 0, Math.min(silenceChunk.length, 256));
        } catch (Throwable t) {
            releaseTrack(track);
            return opened;
        }
        AudioDeviceInfo routed = routedOf(track);
        if (routed == null) {
            sleep(50);
            routed = routedOf(track);
        }
        if (routed == null || Devices.isCallRoute(routed.getType()) || !Devices.sameOutput(device, routed)) {
            releaseTrack(track);
            return opened;
        }
        opened.track = track;
        opened.usage = usage;
        return opened;
    }

    /**
     * Select a Bluetooth output once per bridge session. If it disappears, leave that side silent/off
     * rather than routing its audio to a different Bluetooth device. Stop and start to choose again.
     */
    private AudioDeviceInfo getSessionBluetoothOutput() {
        AudioManager manager = Devices.audioManager(this);
        if (selectedBluetoothId == Integer.MIN_VALUE) {
            AudioDeviceInfo selected = Devices.chooseBluetooth(this);
            if (selected != null) {
                selectedBluetoothId = selected.getId();
            }
            return selected;
        }
        AudioDeviceInfo[] outputs = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
        for (int i = 0; i < outputs.length; i++) {
            AudioDeviceInfo candidate = outputs[i];
            if (candidate.getId() == selectedBluetoothId && Devices.isBluetoothOut(candidate.getType())) {
                return candidate;
            }
        }
        return null;
    }

    private void publishRoute() {
        synchronized (routeLock) {
            String speakerName = "Built-in speaker";
            if (speakerDevice == null || speakerTrack == null) {
                speakerName = "Built-in speaker · off";
            }
            String btName;
            if (btDevice == null) {
                btName = "Nothing connected";
            } else if (btTrack == null) {
                btName = Devices.label(btDevice) + " · off";
            } else {
                btName = Devices.label(btDevice);
            }
            MixState.speakerRoute = speakerName;
            MixState.btRoute = btName;
            MixState.originalQuiet = silence.isHoldingMusic();
            MixState.primaryLabel = Sync.leadText(MixState.speakerShiftMs, MixState.btShiftMs);
            if (quietNote.length() > 0) {
                MixState.originalLabel = quietNote;
            } else {
                MixState.originalLabel = "Silent reference clock; original app playback is unchanged. Each output has its own software gain.";
            }
            StringBuilder path = new StringBuilder();
            path.append("Other apps\n");
            path.append("        ↓\n");
            path.append("Capture · ").append(rate).append(" Hz stereo\n");
            path.append("        ├── tablet speaker  (own level, own sync)\n");
            path.append("        └── ");
            path.append(btDevice == null ? "Bluetooth waiting" : "Bluetooth speaker  (own level, own sync)");
            MixState.path = path.toString();

            String status = "Tablet " + (speakerTrack != null ? "on" : "off")
                    + " · Bluetooth " + (btTrack != null ? "on" : (btDevice == null ? "not connected" : "off"))
                    + ". Sync is manual. Original system playback is not muted; echo may occur.";
            if (!MixState.hearing) {
                status = status + " Waiting for audio.";
            }
            MixState.status = status;
            String sig = speakerDevId + ":" + btDevId + ":" + (speakerTrack != null) + ":" + (btTrack != null)
                    + ":" + silence.isHoldingMusic() + ":" + MixState.hearing;
            if (!sig.equals(lastSignature)) {
                lastSignature = sig;
                updateNotification("Tablet " + (speakerTrack != null ? "on" : "off")
                        + " · Bluetooth " + (btTrack != null ? "on" : "off"));
                BridgeBus.post();
            }
        }
    }

    private static boolean isNonMusic(int usage) {
        return usage >= 0
                && usage != AudioAttributes.USAGE_MEDIA
                && usage != AudioAttributes.USAGE_GAME
                && usage != AudioAttributes.USAGE_UNKNOWN;
    }

    private AudioTrack buildTrack(int usage) {
        int min = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) {
            return null;
        }
        int buffer = Math.max(min * 2, rate * 4 * 100 / 1000);
        try {
            AudioTrack.Builder builder = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(usage)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_NONE)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build())
                    .setBufferSizeInBytes(buffer)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_NONE);
            if (Build.VERSION.SDK_INT >= 33) {
                builder.setOffloadedPlayback(false);
            }
            AudioTrack track = builder.build();
            if (track.getState() != AudioTrack.STATE_INITIALIZED) {
                track.release();
                return null;
            }
            return track;
        } catch (Throwable t) {
            Log.w(TAG, "track", t);
            return null;
        }
    }

    private AudioRecord openRecord(int sampleRate) {
        int min = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) {
            return null;
        }
        int buffer = Math.max(min * 2, sampleRate * 4 * 160 / 1000);
        try {
            AudioRecord built = new AudioRecord.Builder()
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                            .build())
                    .setBufferSizeInBytes(buffer)
                    .setAudioPlaybackCaptureConfig(captureConfig)
                    .build();
            if (built.getState() != AudioRecord.STATE_INITIALIZED) {
                built.release();
                return null;
            }
            return built;
        } catch (Throwable t) {
            Log.w(TAG, "record", t);
            return null;
        }
    }

    private void reopenRecord() {
        AudioRecord fresh = openRecord(rate);
        if (fresh == null) {
            return;
        }
        AudioRecord old = record;
        record = fresh;
        if (old != null) {
            try {
                old.stop();
            } catch (Exception ignored) {
            }
            try {
                old.release();
            } catch (Exception ignored) {
            }
        }
        try {
            fresh.startRecording();
        } catch (Throwable t) {
            Log.w(TAG, "restart record", t);
        }
    }

    private void openSession() {
        try {
            session = new MediaSession(this, "SystemAudioBridge");
            session.setPlaybackState(new PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_STOP)
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build());
            session.setCallback(new MediaSession.Callback() {
                @Override
                public void onStop() {
                    requestHalt();
                }
            }, mainHandler);
            session.setActive(true);
        } catch (Throwable t) {
            Log.w(TAG, "session", t);
        }
    }

    private AudioDeviceInfo routedOf(AudioTrack track) {
        try {
            return track.getRoutedDevice();
        } catch (Throwable t) {
            return null;
        }
    }

    private void fail(String message) {
        MixState.status = message;
        MixState.running = false;
        BridgeBus.post();
        requestHalt();
    }

    private void requestHalt() {
        if (halted) {
            return;
        }
        halted = true;
        running = false;
        MixState.running = false;
        MixState.hearing = false;
        MixState.originalQuiet = false;
        MixState.primaryLabel = Sync.leadText(MixState.speakerShiftMs, MixState.btShiftMs);
        MixState.originalLabel = "Media volume restored if it was changed.";
        joinThread(captureThread, 700);
        joinThread(speakerThread, 500);
        joinThread(btThread, 500);
        captureThread = null;
        speakerThread = null;
        btThread = null;
        dropSpeaker();
        dropBt();
        if (record != null) {
            try {
                record.stop();
            } catch (Exception ignored) {
            }
            try {
                record.release();
            } catch (Exception ignored) {
            }
            record = null;
        }
        if (projection != null) {
            try {
                projection.stop();
            } catch (Exception ignored) {
            }
            projection = null;
        }
        if (session != null) {
            try {
                session.setActive(false);
                session.release();
            } catch (Exception ignored) {
            }
            session = null;
        }
        if (devicesRegistered) {
            try {
                Devices.audioManager(this).unregisterAudioDeviceCallback(deviceCallback);
            } catch (Exception ignored) {
            }
            devicesRegistered = false;
        }
        silence.restoreAll(this);
        releaseWake();
        try {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } catch (Throwable ignored) {
        }
        stopSelf();
        BridgeBus.post();
    }

    private void dropSpeaker() {
        AudioTrack old = speakerTrack;
        speakerTrack = null;
        speakerUsage = -1;
        releaseTrack(old);
    }

    private void dropBt() {
        AudioTrack old = btTrack;
        btTrack = null;
        btUsage = -1;
        releaseTrack(old);
    }

    private void releaseTrack(AudioTrack track) {
        if (track == null) {
            return;
        }
        try {
            track.pause();
        } catch (Exception ignored) {
        }
        try {
            track.flush();
        } catch (Exception ignored) {
        }
        try {
            track.stop();
        } catch (Exception ignored) {
        }
        try {
            track.release();
        } catch (Exception ignored) {
        }
    }

    private void acquireWake() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SystemAudioBridge:run");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(6L * 60L * 60L * 1000L);
        } catch (Exception ignored) {
        }
    }

    private void releaseWake() {
        PowerManager.WakeLock lock = wakeLock;
        wakeLock = null;
        if (lock != null) {
            try {
                if (lock.isHeld()) {
                    lock.release();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pending = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("System Audio Bridge")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentIntent(pending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void updateNotification(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, notification(text));
        } catch (Exception ignored) {
        }
    }

    private static Intent readData(Intent intent) {
        if (intent == null) {
            return null;
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                return intent.getParcelableExtra(EXTRA_DATA, Intent.class);
            }
            return intent.getParcelableExtra(EXTRA_DATA);
        } catch (Exception e) {
            return null;
        }
    }

    private static void joinThread(Thread thread, long ms) {
        if (thread == null) {
            return;
        }
        try {
            thread.join(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private static final class Opened {
        AudioTrack track;
        int usage = -1;
    }
}
