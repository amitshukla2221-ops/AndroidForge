package com.standalone.streamer

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeViewModel : ViewModel() {
    var rows by mutableStateOf<List<Pair<String, List<Movie>>>>(emptyList())
    var results by mutableStateOf<List<Movie>?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var selected by mutableStateOf<Movie?>(null)
    var showSettings by mutableStateOf(false)

    fun load(key: String) {
        if (key.isBlank()) {
            error = null
            rows = emptyList()
            return
        }
        viewModelScope.launch {
            loading = true
            error = null
            try {
                rows = withContext(Dispatchers.IO) {
                    listOf(
                        "Trending this week" to Tmdb.list("/trending/movie/week", key),
                        "Popular" to Tmdb.list("/movie/popular", key),
                        "Top rated" to Tmdb.list("/movie/top_rated", key),
                        "Now playing" to Tmdb.list("/movie/now_playing", key),
                        "Upcoming" to Tmdb.list("/movie/upcoming", key)
                    )
                }
            } catch (e: Exception) {
                error = e.message ?: "Could not load"
            }
            loading = false
        }
    }

    fun search(key: String, query: String) {
        if (query.isBlank()) { results = null; return }
        viewModelScope.launch {
            loading = true
            error = null
            try {
                results = withContext(Dispatchers.IO) { Tmdb.search(query.trim(), key) }
            } catch (e: Exception) {
                error = e.message ?: "Search failed"
            }
            loading = false
        }
    }
}
