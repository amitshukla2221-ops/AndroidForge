package com.standalone.streamer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {

    private val vm: HomeViewModel by viewModels()
    private lateinit var prefs: Prefs
    private var pendingMovie: Movie? = null

    private val localPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val m = pendingMovie
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            if (m != null) prefs.setSource(m.id, uri.toString())
            playLink(uri.toString())
        }
    }

    private val torrentPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) playTorrentUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        if (vm.rows.isEmpty()) vm.load(prefs.tmdbKey)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App()
                }
            }
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "magnet") playLink(data.toString()) else playTorrentUri(data)
    }

    private fun playLink(link: String) {
        val ok = link.startsWith("magnet:?xt=urn:btih:") || link.startsWith("http://") ||
            link.startsWith("https://") || link.startsWith("content://")
        if (!ok) {
            Toast.makeText(this, "Enter a magnet link or http(s) URL", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_LINK, link))
    }

    private fun playTorrentUri(uri: Uri) {
        val bytes = try {
            contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
        if (bytes == null || bytes.isEmpty()) {
            Toast.makeText(this, "Could not read file", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_TORRENT, bytes))
    }

    // ---------------------------------------------------------------- UI

    @Composable
    private fun App() {
        BackHandler(enabled = vm.selected != null || vm.showSettings) {
            if (vm.showSettings) vm.showSettings = false else vm.selected = null
        }
        val sel = vm.selected
        when {
            vm.showSettings -> SettingsScreen()
            sel != null -> DetailScreen(sel)
            else -> HomeScreen()
        }
    }

    @Composable
    private fun HomeScreen() {
        var query by remember { mutableStateOf("") }
        val noKey = prefs.tmdbKey.isBlank()
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Streamer", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it; if (it.isBlank()) vm.results = null },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("Search movies") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.search(prefs.tmdbKey, query) })
                )
                TextButton(onClick = { vm.showSettings = true }) { Text("Settings") }
            }
            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }

            if (noKey) {
                SetupCard()
            }
            val res = vm.results
            if (res != null) {
                Text("Results", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 8.dp))
                if (res.isEmpty()) Text("Nothing found")
                else LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(res, key = { it.id }) { PosterCard(it) }
                }
            }
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.rows) { (title, movies) ->
                    Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(movies, key = { it.id }) { PosterCard(it) }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    @Composable
    private fun SetupCard() {
        Card(Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Add your TMDB key to see posters and movie info", fontWeight = FontWeight.Bold)
                Text(
                    "Make a free account at themoviedb.org, open Settings > API, and copy your API key " +
                        "(or the long Read Access Token). Paste it in Settings here."
                )
                Button(onClick = { vm.showSettings = true }) { Text("Open Settings") }
            }
        }
    }

    @Composable
    private fun PosterCard(m: Movie) {
        Column(Modifier.width(140.dp).clickable { vm.selected = m }) {
            Box(
                Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                AsyncImage(
                    model = Tmdb.posterUrl(m.poster),
                    contentDescription = m.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Text(m.title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
            Text(m.year, style = MaterialTheme.typography.bodySmall)
        }
    }

    @Composable
    private fun DetailScreen(m: Movie) {
        var saved by remember(m.id) { mutableStateOf(prefs.source(m.id)) }
        var showPaste by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().height(220.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
                AsyncImage(
                    model = Tmdb.backdropUrl(m.backdrop ?: m.poster),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(m.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("${m.year}  |  TMDB ${"%.1f".format(m.rating)}")
                Text(m.overview.ifEmpty { "No description." })
                Spacer(Modifier.height(4.dp))
                saved?.let { s ->
                    Button(onClick = { playLink(s) }, modifier = Modifier.fillMaxWidth()) { Text("Play saved source") }
                    TextButton(onClick = { prefs.clearSource(m.id); saved = null }) { Text("Forget saved source") }
                }
                OutlinedButton(
                    onClick = { pendingMovie = m; localPicker.launch(arrayOf("video/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Play a video file from this device") }
                OutlinedButton(onClick = { showPaste = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Paste magnet link or video URL")
                }
                OutlinedButton(
                    onClick = { torrentPicker.launch(arrayOf("*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Open a .torrent file") }
                Text(
                    "Streamer does not search for or supply video. Use sources you have the right to watch.",
                    style = MaterialTheme.typography.bodySmall
                )
                TextButton(onClick = { vm.selected = null }) { Text("Back") }
            }
        }
        if (showPaste) {
            var text by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showPaste = false },
                title = { Text("Source for ${m.title}") },
                text = {
                    OutlinedTextField(
                        value = text, onValueChange = { text = it },
                        placeholder = { Text("magnet:?xt=urn:btih:... or https://...") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val s = text.trim()
                        showPaste = false
                        if (s.isNotEmpty()) {
                            prefs.setSource(m.id, s)
                            saved = s
                            playLink(s)
                        }
                    }) { Text("Play") }
                },
                dismissButton = { TextButton(onClick = { showPaste = false }) { Text("Cancel") } }
            )
        }
    }

    @Composable
    private fun SettingsScreen() {
        var key by remember { mutableStateOf(prefs.tmdbKey) }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Settings", style = MaterialTheme.typography.headlineMedium)
            OutlinedTextField(
                value = key, onValueChange = { key = it },
                label = { Text("TMDB API key or read access token") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Get a free key at themoviedb.org > Settings > API. It is stored only on this device. " +
                    "This product uses the TMDB API but is not endorsed or certified by TMDB.",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = {
                    prefs.tmdbKey = key
                    vm.showSettings = false
                    vm.load(prefs.tmdbKey)
                }) { Text("Save") }
                TextButton(onClick = { vm.showSettings = false }) { Text("Cancel") }
            }
        }
    }
}
