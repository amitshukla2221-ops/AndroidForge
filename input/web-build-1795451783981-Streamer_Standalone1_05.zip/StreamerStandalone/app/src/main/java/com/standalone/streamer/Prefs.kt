package com.standalone.streamer

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("streamer", Context.MODE_PRIVATE)

    var tmdbKey: String
        get() = sp.getString("tmdb", "") ?: ""
        set(v) { sp.edit().putString("tmdb", v.trim()).apply() }

    /** The source (magnet / URL / local content uri) the user chose for a movie. */
    fun source(movieId: Int): String? = sp.getString("src_$movieId", null)
    fun setSource(movieId: Int, s: String) { sp.edit().putString("src_$movieId", s).apply() }
    fun clearSource(movieId: Int) { sp.edit().remove("src_$movieId").apply() }
}
