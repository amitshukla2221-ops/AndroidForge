package com.standalone.streamer

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Movie(
    val id: Int,
    val title: String,
    val year: String,
    val overview: String,
    val poster: String?,
    val backdrop: String?,
    val rating: Double
)

/** Metadata only (posters, plots, ratings) from TMDB. Needs the user's own free API key. */
object Tmdb {
    private const val IMG = "https://image.tmdb.org/t/p/"

    fun posterUrl(path: String?) = path?.let { IMG + "w342" + it }
    fun backdropUrl(path: String?) = path?.let { IMG + "w780" + it }

    private fun get(path: String, key: String, params: String = ""): JSONObject {
        val bearer = key.length > 40 // v4 read token vs v3 api key
        val q = "language=en-US$params" + if (bearer) "" else "&api_key=$key"
        val c = URL("https://api.themoviedb.org/3$path?$q").openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        if (bearer) c.setRequestProperty("Authorization", "Bearer $key")
        try {
            val code = c.responseCode
            if (code == 401) throw IOException("TMDB rejected the key (401). Check it in Settings.")
            if (code !in 200..299) throw IOException("TMDB error $code")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    private fun JSONObject.str(name: String): String? =
        if (isNull(name)) null else optString(name).ifEmpty { null }

    fun list(path: String, key: String, params: String = ""): List<Movie> {
        val arr = get(path, key, params).getJSONArray("results")
        val out = ArrayList<Movie>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += Movie(
                id = o.getInt("id"),
                title = o.str("title") ?: continue,
                year = (o.str("release_date") ?: "").take(4),
                overview = o.str("overview") ?: "",
                poster = o.str("poster_path"),
                backdrop = o.str("backdrop_path"),
                rating = o.optDouble("vote_average", 0.0)
            )
        }
        return out
    }

    fun search(query: String, key: String): List<Movie> =
        list("/search/movie", key, "&query=" + URLEncoder.encode(query, "UTF-8"))
}
