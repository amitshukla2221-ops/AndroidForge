System Audio Bridge Manual 2.4.1 — AndroidForge Gradle project

UPLOAD
1. Upload this ZIP as-is to AndroidForge. The ZIP root contains settings.gradle and build.gradle.
2. Choose the Gradle Android build option if prompted.
3. Build the app module (assembleDebug or assembleRelease). Expected APK paths:
   app/build/outputs/apk/debug/app-debug.apk
   app/build/outputs/apk/release/app-release.apk

WHAT CHANGED
- Application ID is now com.systemaudiobridge.manualsync, so Android treats it as a separate app and offers Install rather than Update for the old package. The old app remains installed separately.
- Version 2.4.1 (versionCode 241), minimum Android 10 (API 29), target API 34.
- The Bluetooth output selected for a bridge session is locked. If it disappears, the Bluetooth copy stops instead of silently hopping to another Bluetooth device. Stop and restart the bridge to select a different connected device.
- Sync is manual; no automatic latency measurement or correction is implemented. The labels above each sync slider show the configured lead and gap, not a measurement from the hardware. Adjust while audio is playing to compensate for real speaker/Bluetooth latency.
- Each output has its own gain, mute, EQ, and read delay.
- This revision never mutes or changes Android system media volume. This avoids Android 12 devices that apply stream volume before playback capture, which made both copies silent. The original app may remain audible on the default output and can therefore overlap with the bridge copy; see limitations below.

IMPORTANT LIMITS / TESTING
This is a source project, not a prebuilt or device-verified APK. This environment has no Android SDK or Gradle installation, so the AndroidForge build must be run to create the APK. Android playback capture is restricted by the source app and Android policy, and simultaneous built-in-speaker plus Bluetooth output depends on device/OS audio routing support. Test with the actual phone and speakers.

Signing
The included bridge-release.keystore is configured for debug and release. Because the application ID is new, this APK installs as a separate app regardless of the old app's ID/signature. Do not share this keystore or its password publicly.

ANDROIDFORGE STALE-WORKSPACE CHECK
The source app/src/main/AndroidManifest.xml in this archive intentionally has NO package= attribute. The namespace is set only in app/build.gradle. If a build log still says package=\"com.systemaudiobridge.manualsync\" is in this source manifest, AndroidForge is not building this archive's manifest. Start a NEW AndroidForge project/workspace and upload this ZIP as-is; do not retry the old workspace.
