package com.example.systemaudiobridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;

/**
 * One capture of other apps, then two independent copies.
 * Each copy is pinned to its own device on a non-music stream so it does not follow
 * the system media route. That is what keeps sync alive when Bluetooth is the default
 * output: opening a media track onto the built-in speaker from the capture thread
 * deadlocks AudioFlinger on Android 12 and the write never returns.
 * Sync is a fixed offset from the capture clock. A stalled write drops audio instead
 * of blocking, then the reader rejoins the same offset.
 * Volume is software gain inside each copy. Never change the system media volume:
 * some Android 12 devices apply that volume before playback capture, making both copies silent.
 * Sync is a manual buffer offset, not an automatic measurement of hardware latency.
 */
public final class AudioBridgeService extends Service {
    public static final String ACTION_START = "com.example.systemaudiobridge.START";
    public static final String ACTION_STOP = "com.example.systemaudiobridge.STOP";
    public static final String EXTRA_CODE = "resultCode";
    public static final String EXTRA_DATA = "data";

    private static final String TAG = "AudioBridge";
    private static final String CHANNEL = "audio_bridge_v22";
    private static final int NOTIFICATION_ID = 42;
    private static final int CHUNK = 1024;
    /**
     * Non-music usages only. USAGE_MEDIA pinned to the speaker while Bluetooth is the
     * default media device is the call that hangs Android 12. Alarm/assistant/notification
     * can be pinned without tearing down the A2DP media output, and they stay audible
     * after the original music stream is silenced.
     */
    private static final int[] SPEAKER_USAGES = {
            AudioAttributes.USAGE_ALARM,
            AudioAttributes.USAGE_NOTIFICATION,
            AudioAttributes.USAGE_ASSISTANT,
            AudioAttributes.USAGE_ASSISTANCE_SONIFICATION
    };
    private static final int[] BLUETOOTH_USAGES = {
            AudioAttributes.USAGE_ASSISTANT,
            AudioAttributes.USAGE_NOTIFICATION,
            AudioAttributes.USAGE_NOTIFICATION_EVENT,
            AudioAttributes.USAGE_ALARM,
            AudioAttributes.USAGE_ASSISTANCE_SONIFICATION
    };

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final SystemSilence silence = new SystemSilence();
    private final Object routeLock = new Object();
    private final short[] silenceChunk = new short[CHUNK];

    private final AudioDeviceCallback deviceCallback = new AudioDeviceCallback() {
        @Override
        public void onAudioDevicesAdded(AudioDeviceInfo[] added) {
            devicesChanged = true;
        }

        @Override
        public void onAudioDevicesRemoved(AudioDeviceInfo[] removed) {
            devicesChanged = true;
        }
    };

    private MediaProjection projection;
    private MediaSession session;
    private AudioPlaybackCaptureConfiguration captureConfig;
    private AudioRecord record;
    private RingBuffer ring;
    private int rate = 48000;
    private volatile boolean running;
    private boolean halted;
    private boolean devicesRegistered;
    private volatile boolean devicesChanged;
    private boolean silenceGaveUp;
    private String quietNote = "";
    private String lastSignature = "";
    private PowerManager.WakeLock wakeLock;

    private volatile AudioTrack speakerTrack;
    private volatile AudioTrack btTrack;
    private AudioDeviceInfo speakerDevice;
    private AudioDeviceInfo btDevice;
    private int speakerDevId = Integer.MIN_VALUE;
    private int btDevId = Integer.MIN_VALUE;
    // Lock the Bluetooth output chosen at session start. Do not silently hop to another device.
    private int selectedBluetoothId = Integer.MIN_VALUE;
    private int speakerFailedId = Integer.MIN_VALUE;
    private int btFailedId = Integer.MIN_VALUE;
    private int speakerUsage = -1;
    private int btUsage = -1;

    private Thread captureThread;
    private Thread speakerThread;
    private Thread btThread;
    private Thread routeThread;
    private volatile boolean starting;
    private volatile boolean speakerStalled;
    private volatile boolean btStalled;
    private volatile boolean routeBlocked;
    private int stuckRoutes;
    private int speakerUsageCursor;
    private int btUsageCursor;
    private long nextSpeakerTry;
    private long nextBtTry;
    private boolean heardBeforeMute;

    private final Runnable verifyMute = new Runnable() {
        @Override
        public void run() {
            if (!running || silenceGaveUp || !silence.isHoldingMusic()) {
                return;
            }
            // Exact digital silence after a confirmed signal means this device
            // tapped capture after stream volume. Put media back so the copies live.
            if (heardBeforeMute && MixState.capturePeak <= 0) {
                silence.releaseMusic(AudioBridgeService.this);
                silenceGaveUp = true;
                quietNote = "This tablet silenced capture along with the media stream, so the original volume was put back. Echo on the built-in speaker may remain. Level sliders still scale each copy.";
                publishRoute();
            }
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (!MixState.running) {
            SystemSilence.recoverAbandoned(this);
        }
        NotificationChannel channel = new NotificationChannel(
                CHANNEL, "Audio bridge", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Keeps the audio bridge alive");
        channel.setSound(null, null);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(channel);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            MixState.status = "Stopped. Levels were left as you set them.";
            MixState.running = false;
            BridgeBus.post();
            requestHalt();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) || running || starting) {
            return START_NOT_STICKY;
        }
        final int code = intent.getIntExtra(EXTRA_CODE, 0);
        final Intent data = readData(intent);
        if (data == null) {
            fail("Capture permission missing. Start again.");
            return START_NOT_STICKY;
        }
        try {
            startForeground(
                    NOTIFICATION_ID,
                    notification("Starting bridge"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } catch (Exception e) {
            Log.e(TAG, "foreground", e);
            MixState.status = "Android blocked the bridge notification.";
            MixState.running = false;
            BridgeBus.post();
            stopSelf();
            return START_NOT_STICKY;
        }
        starting = true;
        // Projection and track setup must not run on the main thread. On Android 12
        // a speaker pin while Bluetooth is the default output can block inside AudioFlinger.
        Thread starter = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    startCapture(code, data);
                } catch (Throwable t) {
                    Log.e(TAG, "start", t);
                    String message = "no-speaker".equals(t.getMessage())
                            ? "No built-in speaker available."
                            : "Could not start capture. Allow screen audio and retry.";
                    fail(message);
                } finally {
                    starting = false;
                }
            }
        }, "BridgeStart");
        starter.start();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        requestHalt();
        super.onDestroy();
    }

    private void startCapture(int resultCode, Intent data) {
        Prefs.load(this);
        AudioManager am = Devices.audioManager(this);
        if (Devices.builtInSpeaker(am) == null) {
            throw new IllegalStateException("no-speaker");
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        MediaProjection created = mpm.getMediaProjection(resultCode, data);
        if (created == null) {
            throw new IllegalStateException("projection");
        }
        projection = created;
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                if (running) {
                    MixState.status = "Capture stopped.";
                    MixState.running = false;
                    BridgeBus.post();
                }
                requestHalt();
            }
        }, mainHandler);

        rate = 48000;
        captureConfig = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build();
        record = openRecord(rate);
        if (record == null) {
            rate = 44100;
            record = openRecord(rate);
        }
        if (record == null) {
            throw new IllegalStateException("record");
        }
        MixState.captureRate = rate;
        ring = new RingBuffer(rate, 4);
        record.startRecording();
        openSession();

        silenceGaveUp = false;
        quietNote = "";
        speakerDevId = Integer.MIN_VALUE;
        btDevId = Integer.MIN_VALUE;
        selectedBluetoothId = Integer.MIN_VALUE;
        speakerFailedId = Integer.MIN_VALUE;
        btFailedId = Integer.MIN_VALUE;
        speakerUsage = -1;
        btUsage = -1;
        speakerUsageCursor = 0;
        btUsageCursor = 0;
        nextSpeakerTry = 0L;
        nextBtTry = 0L;
        speakerStalled = false;
        btStalled = false;
        routeBlocked = false;
        stuckRoutes = 0;
        heardBeforeMute = false;
        MixState.capturePeak = 0;
        MixState.originalQuiet = false;
        devicesChanged = true;

        running = true;
        MixState.running = true;
        acquireWake();
        if (!devicesRegistered) {
            am.registerAudioDeviceCallback(deviceCallback, mainHandler);
            devicesRegistered = true;
        }
        captureThread = new Thread(new Runnable() {
            @Override
            public void run() {
                captureLoop();
            }
        }, "BridgeCapture");
        speakerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                playLoop(true);
            }
        }, "BridgeSpeaker");
        btThread = new Thread(new Runnable() {
            @Override
            public void run() {
                playLoop(false);
            }
        }, "BridgeBluetooth");
        routeThread = new Thread(new Runnable() {
            @Override
            public void run() {
                routeLoop();
            }
        }, "BridgeRoute");
        captureThread.start();
        routeThread.start();
        speakerThread.start();
        btThread.start();
        MixState.status = "Starting both outputs…";
        BridgeBus.post();
    }

    private void captureLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        short[] buf = new short[CHUNK];
        int errors = 0;
        while (running) {
            int n;
            try {
                n = record.read(buf, 0, buf.length);
            } catch (Throwable t) {
                n = -1;
            }
            if (n < 0) {
                errors++;
                if (errors >= 8) {
                    errors = 0;
                    reopenRecord();
                } else {
                    sleep(15);
                }
                continue;
            }
            errors = 0;
            if (n < 2) {
                sleep(4);
                continue;
            }
            if ((n & 1) != 0) {
                n--;
            }
            ring.write(buf, n);
            int peak = 0;
            for (int i = 0; i < n; i += 8) {
                int v = buf[i];
                if (v < 0) {
                    v = -v;
                }
                if (v > peak) {
                    peak = v;
                }
            }
            MixState.capturePeak = peak;
            boolean hot = Pcm.audible(buf, n);
            if (hot != MixState.hearing) {
                MixState.hearing = hot;
                publishRoute();
            }
        }
    }

    /**
     * Plays one copy from the capture clock. Writes are non-blocking: a Bluetooth
     * sink that stops draining must not freeze this thread, or the slider stops
     * meaning anything. Late audio is dropped by the ring and the offset is kept.
     */
    private void playLoop(final boolean speakerSide) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        short[] buf = new short[CHUNK];
        long[] cursor = new long[] {-1L};
        Tone tone = new Tone(rate);
        int[] db = new int[EqPresets.BANDS];
        int appliedDelay = -1;
        int pendingDelay = Integer.MIN_VALUE;
        long pendingSince = 0L;
        AudioTrack seen = null;
        long nextNanos = 0L;
        int starved = 0;
        final long chunkFrames = CHUNK / 2L;
        while (running) {
            AudioTrack track = speakerSide ? speakerTrack : btTrack;
            if (track == null || ring == null) {
                seen = null;
                nextNanos = 0L;
                starved = 0;
                cursor[0] = -1L;
                sleep(20);
                continue;
            }
            if (track != seen) {
                seen = track;
                cursor[0] = -1L;
                appliedDelay = -1;
                tone = new Tone(rate);
                nextNanos = 0L;
                starved = 0;
            }
            long chunkNanos = chunkFrames * 1_000_000_000L / (long) rate;
            long nowNs = System.nanoTime();
            if (nextNanos == 0L) {
                nextNanos = nowNs;
            }
            long waitMs = (nextNanos - nowNs) / 1_000_000L;
            if (waitMs > 2L) {
                sleep(waitMs);
                continue;
            }
            if (nowNs - nextNanos > chunkNanos * 3L) {
                nextNanos = nowNs;
            }
            nextNanos += chunkNanos;

            int shift = speakerSide ? MixState.speakerShiftMs : MixState.btShiftMs;
            int other = speakerSide ? MixState.btShiftMs : MixState.speakerShiftMs;
            int delayMs = Sync.absoluteDelayMs(shift, other);
            long nowMs = SystemClock.elapsedRealtime();
            boolean snap = cursor[0] < 0L;
            int useDelay = delayMs;
            if (!snap && delayMs != appliedDelay) {
                if (delayMs != pendingDelay) {
                    pendingDelay = delayMs;
                    pendingSince = nowMs;
                } else if (nowMs - pendingSince >= 80L) {
                    snap = true;
                }
                if (!snap && appliedDelay >= 0) {
                    useDelay = appliedDelay;
                }
            }
            int delayFrames = Sync.delayFrames(rate, useDelay);
            int n = ring.read(buf, buf.length, cursor, delayFrames, snap);
            if (snap && n >= 2) {
                appliedDelay = useDelay;
                pendingDelay = appliedDelay;
            }
            if (n < 2) {
                continue;
            }
            if (speakerSide) {
                MixState.copySpeakerEq(db);
            } else {
                MixState.copyBtEq(db);
            }
            boolean muted = speakerSide ? MixState.speakerMuted : MixState.btMuted;
            int vol = speakerSide ? MixState.speakerVolume : MixState.btVolume;
            float gain = muted || vol <= 0 ? 0f : vol / 100f;
            tone.process(buf, n, gain, db);
            if (snap) {
                Pcm.fadeIn(buf, n, 32);
            }
            int off = 0;
            int spins = 0;
            boolean failed = false;
            while (off < n && running && spins < 3) {
                AudioTrack current = speakerSide ? speakerTrack : btTrack;
                if (current == null || current != track) {
                    failed = true;
                    break;
                }
                int wrote;
                try {
                    wrote = current.write(buf, off, n - off, AudioTrack.WRITE_NON_BLOCKING);
                } catch (Throwable t) {
                    wrote = AudioTrack.ERROR_DEAD_OBJECT;
                }
                if (wrote < 0) {
                    failed = true;
                    break;
                }
                if (wrote == 0) {
                    spins++;
                    sleep(2);
                    continue;
                }
                off += wrote;
            }
            if (failed || off == 0) {
                starved++;
                if (starved >= 25) {
                    starved = 0;
                    if (speakerSide) {
                        speakerStalled = true;
                    } else {
                        btStalled = true;
                    }
                    devicesChanged = true;
                }
            } else {
                starved = 0;
            }
        }
    }

    /** Routing never runs on the capture thread. A stuck pin must not stop the clock. */
    private void routeLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        while (running) {
            boolean need = devicesChanged || speakerStalled || btStalled
                    || speakerTrack == null || (btTrack == null && !routeBlocked);
            if (speakerTrack == null && routeBlocked) {
                need = devicesChanged || speakerStalled || btStalled;
            }
            if (need && !routeBlocked) {
                devicesChanged = false;
                final boolean[] done = new boolean[] {false};
                Thread worker = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            reconcile();
                        } catch (Throwable t) {
                            Log.w(TAG, "route", t);
                        } finally {
                            done[0] = true;
                        }
                    }
                }, "BridgeRouteOnce");
                worker.setDaemon(true);
                worker.start();
                try {
                    // One pass tries several usages. That is slow, not a hang.
                    // Capture and the sliders keep running while this waits.
                    worker.join(12000);
                } catch (InterruptedException ignored) {
                }
                if (!done[0]) {
                    routeBlocked = true;
                    Log.w(TAG, "route call blocked; capture clock kept running");
                    quietNote = "Routing stalled while Bluetooth was the default output. Capture is still running. Stop the bridge, toggle Bluetooth, then start again.";
                    MixState.status = quietNote;
                    BridgeBus.post();
                }
            } else if (routeBlocked && (speakerStalled || btStalled)) {
                speakerStalled = false;
                btStalled = false;
            }
            sleep(200);
        }
    }

    /**
     * Opens a side only when it has no track, or when that device appeared or disappeared.
     * A live track on the same device id is never replaced. Failures retry on a timer
     * instead of pinning USAGE_MEDIA, which is the Bluetooth-default hang.
     */
    private void reconcile() {
        synchronized (routeLock) {
            if (!running || routeBlocked) {
                return;
            }
            long now = SystemClock.elapsedRealtime();
            if (speakerStalled) {
                speakerStalled = false;
                dropSpeaker();
                speakerUsageCursor++;
                nextSpeakerTry = 0L;
            }
            if (btStalled) {
                btStalled = false;
                dropBt();
                btUsageCursor++;
                nextBtTry = 0L;
            }
            AudioDeviceInfo sp = Devices.builtInSpeaker(Devices.audioManager(this));
            AudioDeviceInfo bt = getSessionBluetoothOutput();
            if (sp == null) {
                if (speakerTrack != null) {
                    dropSpeaker();
                }
                speakerDevice = null;
                speakerDevId = Integer.MIN_VALUE;
            } else if (speakerTrack != null && sp.getId() == speakerDevId) {
                speakerDevice = sp;
            } else if (now >= nextSpeakerTry) {
                int avoid = btTrack != null ? btUsage : -1;
                dropSpeaker();
                Opened opened = openPinned(sp, SPEAKER_USAGES, speakerUsageCursor, avoid);
                speakerTrack = opened.track;
                speakerUsage = opened.usage;
                speakerDevice = sp;
                if (speakerTrack == null) {
                    speakerDevId = Integer.MIN_VALUE;
                    speakerUsageCursor++;
                    nextSpeakerTry = now + (opened.blocked ? 1500L : 900L);
                } else {
                    speakerDevId = sp.getId();
                    speakerFailedId = Integer.MIN_VALUE;
                    nextSpeakerTry = 0L;
                }
                Log.i(TAG, "speaker usage " + speakerUsage + " id " + speakerDevId);
            }
            if (bt == null) {
                if (btTrack != null) {
                    dropBt();
                }
                btDevice = null;
                btDevId = Integer.MIN_VALUE;
            } else if (btTrack != null && bt.getId() == btDevId) {
                btDevice = bt;
            } else if (now >= nextBtTry) {
                int avoid = speakerTrack != null ? speakerUsage : -1;
                dropBt();
                Opened opened = openPinned(bt, BLUETOOTH_USAGES, btUsageCursor, avoid);
                btTrack = opened.track;
                btUsage = opened.usage;
                btDevice = bt;
                if (btTrack == null) {
                    btDevId = Integer.MIN_VALUE;
                    btUsageCursor++;
                    nextBtTry = now + (opened.blocked ? 1500L : 900L);
                } else {
                    btDevId = bt.getId();
                    btFailedId = Integer.MIN_VALUE;
                    nextBtTry = 0L;
                }
                Log.i(TAG, "bluetooth usage " + btUsage + " id " + btDevId);
            }
            if (!running) {
                dropSpeaker();
                dropBt();
                return;
            }
            // Keep the source app's media volume untouched. Muting it can also mute
            // AudioPlaybackCapture on some Android 12 tablet implementations.
            publishRoute();
        }
    }

    /** System media volume is deliberately never modified by the bridge. */
    private void maybeSilence() {
        MixState.originalQuiet = false;
        quietNote = "System media volume unchanged. Adjust sync sliders manually to compensate for output latency.";
    }

    private Opened openPinned(AudioDeviceInfo device, int[] usages, int cursor, int avoidUsage) {
        int n = usages.length;
        for (int i = 0; i < n; i++) {
            int usage = usages[Math.floorMod(cursor + i, n)];
            if (usage == avoidUsage && i < n - 1) {
                continue;
            }
            Opened opened = tryOpen(device, usage);
            if (opened.blocked) {
                return opened;
            }
            if (opened.track != null) {
                return opened;
            }
        }
        return new Opened();
    }

    /** Keeps the track only when it actually landed on the requested device. Never blocks the write. */
    private Opened tryOpen(AudioDeviceInfo device, int usage) {
        Opened opened = new Opened();
        AudioTrack track = buildTrack(usage);
        if (track == null) {
            return opened;
        }
        int pinned = pinDevice(track, device, 800);
        if (pinned < 0) {
            opened.blocked = true;
            return opened;
        }
        if (pinned == 0) {
            releaseTrack(track);
            return opened;
        }
        try {
            track.setVolume(1f);
            track.play();
            track.write(silenceChunk, 0, Math.min(silenceChunk.length, 256), AudioTrack.WRITE_NON_BLOCKING);
        } catch (Throwable t) {
            releaseTrack(track);
            return opened;
        }
        AudioDeviceInfo routed = null;
        for (int i = 0; i < 6 && routed == null; i++) {
            routed = routedOf(track);
            if (routed == null) {
                sleep(40);
            }
        }
        if (routed == null || Devices.isCallRoute(routed.getType()) || !Devices.sameOutput(device, routed)) {
            releaseTrack(track);
            return opened;
        }
        opened.track = track;
        opened.usage = usage;
        return opened;
    }

    /**
     * Select a Bluetooth output once per bridge session. If it disappears, leave that side silent/off
     * rather than routing its audio to a different Bluetooth device. Stop and start to choose again.
     */
    private AudioDeviceInfo getSessionBluetoothOutput() {
        AudioManager manager = Devices.audioManager(this);
        if (selectedBluetoothId == Integer.MIN_VALUE) {
            AudioDeviceInfo selected = Devices.chooseBluetooth(this);
            if (selected != null) {
                selectedBluetoothId = selected.getId();
            }
            return selected;
        }
        AudioDeviceInfo[] outputs = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
        for (int i = 0; i < outputs.length; i++) {
            AudioDeviceInfo candidate = outputs[i];
            if (candidate.getId() == selectedBluetoothId && Devices.isBluetoothOut(candidate.getType())) {
                return candidate;
            }
        }
        return null;
    }

    private void publishRoute() {
        synchronized (routeLock) {
            String speakerName = "Built-in speaker";
            if (speakerDevice == null || speakerTrack == null) {
                speakerName = "Built-in speaker · off";
            }
            String btName;
            if (btDevice == null) {
                btName = "Nothing connected";
            } else if (btTrack == null) {
                btName = Devices.label(btDevice) + " · off";
            } else {
                btName = Devices.label(btDevice);
            }
            MixState.speakerRoute = speakerName;
            MixState.btRoute = btName;
            MixState.originalQuiet = silence.isHoldingMusic();
            MixState.primaryLabel = Sync.leadText(MixState.speakerShiftMs, MixState.btShiftMs);
            if (quietNote.length() > 0) {
                MixState.originalLabel = quietNote;
            } else {
                MixState.originalLabel = "Silent reference clock; original app playback is unchanged. Each output has its own software gain.";
            }
            StringBuilder path = new StringBuilder();
            path.append("Other apps\n");
            path.append("        ↓\n");
            path.append("Capture · ").append(rate).append(" Hz stereo\n");
            path.append("        ├── tablet speaker  (own level, own sync)\n");
            path.append("        └── ");
            path.append(btDevice == null ? "Bluetooth waiting" : "Bluetooth speaker  (own level, own sync)");
            MixState.path = path.toString();

            String status = "Tablet " + (speakerTrack != null ? "on" : "off")
                    + " · Bluetooth " + (btTrack != null ? "on" : (btDevice == null ? "not connected" : "off"))
                    + ". Sync follows the capture clock.";
            status = status + " System media volume is unchanged; use the sync sliders to align the copies.";
            if (routeBlocked) {
                status = "Routing stalled while Bluetooth was the default output. Stop, toggle Bluetooth, start again.";
            }
            if (!MixState.hearing) {
                status = status + " Waiting for audio.";
            }
            MixState.status = status;
            String sig = speakerDevId + ":" + btDevId + ":" + (speakerTrack != null) + ":" + (btTrack != null)
                    + ":" + silence.isHoldingMusic() + ":" + MixState.hearing;
            if (!sig.equals(lastSignature)) {
                lastSignature = sig;
                updateNotification("Tablet " + (speakerTrack != null ? "on" : "off")
                        + " · Bluetooth " + (btTrack != null ? "on" : "off"));
                BridgeBus.post();
            }
        }
    }

    private static boolean isNonMusic(int usage) {
        return usage >= 0
                && usage != AudioAttributes.USAGE_MEDIA
                && usage != AudioAttributes.USAGE_GAME
                && usage != AudioAttributes.USAGE_UNKNOWN;
    }

    private static int streamForUsage(int usage) {
        switch (usage) {
            case AudioAttributes.USAGE_ALARM:
                return AudioManager.STREAM_ALARM;
            case AudioAttributes.USAGE_NOTIFICATION:
            case AudioAttributes.USAGE_NOTIFICATION_RINGTONE:
            case AudioAttributes.USAGE_NOTIFICATION_EVENT:
                return AudioManager.STREAM_NOTIFICATION;
            case AudioAttributes.USAGE_ASSISTANCE_SONIFICATION:
                return AudioManager.STREAM_SYSTEM;
            case AudioAttributes.USAGE_ASSISTANT:
                return 11;
            default:
                return -1;
        }
    }

    private AudioTrack buildTrack(int usage) {
        final AudioTrack[] box = new AudioTrack[1];
        Thread built = new Thread(new Runnable() {
            @Override
            public void run() {
                box[0] = buildTrackNow(usage);
            }
        }, "TrackBuild");
        built.setDaemon(true);
        built.start();
        try {
            built.join(1500);
        } catch (InterruptedException ignored) {
        }
        if (built.isAlive()) {
            Log.w(TAG, "track build timed out, usage " + usage);
            final Thread late = built;
            Thread reaper = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        late.join(8000);
                    } catch (InterruptedException ignored) {
                    }
                    releaseTrack(box[0]);
                }
            }, "TrackReap");
            reaper.setDaemon(true);
            reaper.start();
            return null;
        }
        return box[0];
    }

    /**
     * @return 1 pinned, 0 refused, -1 the call is still blocked so the track must not be released
     */
    private int pinDevice(final AudioTrack track, final AudioDeviceInfo device, long timeoutMs) {
        final boolean[] result = new boolean[] {false};
        final boolean[] finished = new boolean[] {false};
        Thread pin = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    result[0] = track.setPreferredDevice(device);
                } catch (Throwable t) {
                    result[0] = false;
                } finally {
                    finished[0] = true;
                }
            }
        }, "TrackPin");
        pin.setDaemon(true);
        pin.start();
        try {
            pin.join(timeoutMs);
        } catch (InterruptedException ignored) {
        }
        if (!finished[0]) {
            Log.w(TAG, "setPreferredDevice blocked");
            return -1;
        }
        return result[0] ? 1 : 0;
    }

    private AudioTrack buildTrackNow(int usage) {
        int min = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) {
            return null;
        }
        int want = rate * 4 * 60 / 1000;
        int buffer = Math.max(min, want);
        try {
            AudioTrack.Builder builder = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(usage)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_NONE)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build())
                    .setBufferSizeInBytes(buffer)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_NONE);
            if (Build.VERSION.SDK_INT >= 33) {
                builder.setOffloadedPlayback(false);
            }
            AudioTrack track = builder.build();
            if (track.getState() != AudioTrack.STATE_INITIALIZED) {
                track.release();
                return null;
            }
            return track;
        } catch (Throwable t) {
            Log.w(TAG, "track", t);
            return null;
        }
    }

    private AudioRecord openRecord(int sampleRate) {
        int min = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) {
            return null;
        }
        int buffer = Math.max(min * 2, sampleRate * 4 * 160 / 1000);
        try {
            AudioRecord built = new AudioRecord.Builder()
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                            .build())
                    .setBufferSizeInBytes(buffer)
                    .setAudioPlaybackCaptureConfig(captureConfig)
                    .build();
            if (built.getState() != AudioRecord.STATE_INITIALIZED) {
                built.release();
                return null;
            }
            return built;
        } catch (Throwable t) {
            Log.w(TAG, "record", t);
            return null;
        }
    }

    private void reopenRecord() {
        AudioRecord fresh = openRecord(rate);
        if (fresh == null) {
            return;
        }
        AudioRecord old = record;
        record = fresh;
        if (old != null) {
            try {
                old.stop();
            } catch (Exception ignored) {
            }
            try {
                old.release();
            } catch (Exception ignored) {
            }
        }
        try {
            fresh.startRecording();
        } catch (Throwable t) {
            Log.w(TAG, "restart record", t);
        }
    }

    private void openSession() {
        try {
            session = new MediaSession(this, "SystemAudioBridge");
            session.setPlaybackState(new PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_STOP)
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build());
            session.setCallback(new MediaSession.Callback() {
                @Override
                public void onStop() {
                    requestHalt();
                }
            }, mainHandler);
            session.setActive(true);
        } catch (Throwable t) {
            Log.w(TAG, "session", t);
        }
    }

    private AudioDeviceInfo routedOf(AudioTrack track) {
        try {
            return track.getRoutedDevice();
        } catch (Throwable t) {
            return null;
        }
    }

    private void fail(String message) {
        MixState.status = message;
        MixState.running = false;
        BridgeBus.post();
        requestHalt();
    }

    private void requestHalt() {
        if (halted) {
            return;
        }
        halted = true;
        running = false;
        MixState.running = false;
        MixState.hearing = false;
        MixState.capturePeak = 0;
        MixState.originalQuiet = false;
        mainHandler.removeCallbacks(verifyMute);
        MixState.primaryLabel = Sync.leadText(MixState.speakerShiftMs, MixState.btShiftMs);
        MixState.originalLabel = "System media volume is not changed by this version.";
        joinThread(captureThread, 700);
        joinThread(routeThread, 700);
        joinThread(speakerThread, 500);
        joinThread(btThread, 500);
        captureThread = null;
        routeThread = null;
        speakerThread = null;
        btThread = null;
        dropSpeaker();
        dropBt();
        if (record != null) {
            try {
                record.stop();
            } catch (Exception ignored) {
            }
            try {
                record.release();
            } catch (Exception ignored) {
            }
            record = null;
        }
        if (projection != null) {
            try {
                projection.stop();
            } catch (Exception ignored) {
            }
            projection = null;
        }
        if (session != null) {
            try {
                session.setActive(false);
                session.release();
            } catch (Exception ignored) {
            }
            session = null;
        }
        if (devicesRegistered) {
            try {
                Devices.audioManager(this).unregisterAudioDeviceCallback(deviceCallback);
            } catch (Exception ignored) {
            }
            devicesRegistered = false;
        }
        silence.restoreAll(this);
        releaseWake();
        try {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } catch (Throwable ignored) {
        }
        stopSelf();
        BridgeBus.post();
    }

    private void dropSpeaker() {
        AudioTrack old = speakerTrack;
        speakerTrack = null;
        speakerUsage = -1;
        releaseTrack(old);
    }

    private void dropBt() {
        AudioTrack old = btTrack;
        btTrack = null;
        btUsage = -1;
        releaseTrack(old);
    }

    private void releaseTrack(AudioTrack track) {
        if (track == null) {
            return;
        }
        try {
            track.pause();
        } catch (Exception ignored) {
        }
        try {
            track.flush();
        } catch (Exception ignored) {
        }
        try {
            track.stop();
        } catch (Exception ignored) {
        }
        try {
            track.release();
        } catch (Exception ignored) {
        }
    }

    private void acquireWake() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SystemAudioBridge:run");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(6L * 60L * 60L * 1000L);
        } catch (Exception ignored) {
        }
    }

    private void releaseWake() {
        PowerManager.WakeLock lock = wakeLock;
        wakeLock = null;
        if (lock != null) {
            try {
                if (lock.isHeld()) {
                    lock.release();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pending = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("System Audio Bridge")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentIntent(pending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void updateNotification(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, notification(text));
        } catch (Exception ignored) {
        }
    }

    private static Intent readData(Intent intent) {
        if (intent == null) {
            return null;
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                return intent.getParcelableExtra(EXTRA_DATA, Intent.class);
            }
            return intent.getParcelableExtra(EXTRA_DATA);
        } catch (Exception e) {
            return null;
        }
    }

    private static void joinThread(Thread thread, long ms) {
        if (thread == null) {
            return;
        }
        try {
            thread.join(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private static final class Opened {
        AudioTrack track;
        int usage = -1;
        boolean blocked;
    }
}
