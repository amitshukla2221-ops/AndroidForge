SYSTEM AUDIO BRIDGE 2.4.0

Fixes:
- Sync no longer hangs when the system output is Bluetooth. Routing runs off the capture thread, writes never block, and a stalled side rejoins its own slider offset instead of freezing the clock.
- Copies are pinned with non-music usages only. A media track forced onto the built-in speaker while Bluetooth is the default route is what locked Android 12.
- Tablet-speaker echo: once audio is heard, the original media stream is silenced. The copies stay audible because they are not on that stream. If muting also kills capture, the volume is put back.
- Level sliders scale that copy only. The alarm/notification/assistant stream is matched to the user's media volume so the slider has a real range, and the sliders are not stolen by the scroll view. Streams are restored on stop.

Install the APK over the previous manual-sync build (same application id and signing key).
