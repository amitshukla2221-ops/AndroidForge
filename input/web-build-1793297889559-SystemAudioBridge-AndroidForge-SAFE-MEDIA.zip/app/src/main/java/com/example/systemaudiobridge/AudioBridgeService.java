package com.example.systemaudiobridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;

/**
 * One 48 kHz stereo capture of other apps.
 * Captures supported playback and fans it out to independent internal and Bluetooth tracks.
 * The virtual dummy sink is a logical discard path, not a physical AudioTrack and never changes system volume.
 * Original-output suppression is attempted only when both output tracks can be routed safely.
 */
public final class AudioBridgeService extends Service {
    public static final String ACTION_START = "com.example.systemaudiobridge.START";
    public static final String ACTION_STOP = "com.example.systemaudiobridge.STOP";
    public static final String EXTRA_CODE = "resultCode";
    public static final String EXTRA_DATA = "data";

    private static final String TAG = "AudioBridge";
    private static final String CHANNEL = "audio_bridge_v21";
    private static final int NOTIFICATION_ID = 42;
    private static final int CHUNK = 1024;
    private static final int[] QUIET_USAGES = {
            AudioAttributes.USAGE_NOTIFICATION,
            AudioAttributes.USAGE_ASSISTANCE_SONIFICATION,
            AudioAttributes.USAGE_ALARM
    };

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final SystemSilence silence = new SystemSilence();
    private final Object routeLock = new Object();
    private final short[] silenceChunk = new short[CHUNK];

    private final AudioDeviceCallback deviceCallback = new AudioDeviceCallback() {
        @Override
        public void onAudioDevicesAdded(AudioDeviceInfo[] added) {
            onDevicesChanged();
        }

        @Override
        public void onAudioDevicesRemoved(AudioDeviceInfo[] removed) {
            onDevicesChanged();
        }
    };

    private MediaProjection projection;
    private MediaSession session;
    private AudioPlaybackCaptureConfiguration captureConfig;
    private AudioRecord record;
    private RingBuffer ring;
    private int rate = 48000;
    private volatile boolean running;
    private boolean halted;
    private boolean devicesRegistered;
    private volatile boolean reroute = true;
    private long lastRouteAt;
    private int recordReopens;
    private boolean forceMedia;
    private boolean heardWhileLive;
    private boolean heardWhileMuted;
    private long silentSince;
    private boolean probing;
    private long probeEnd;
    private boolean probeHeard;
    private int probes;
    private String quietReason = "";

    private volatile AudioTrack speakerTrack;
    private volatile AudioTrack btTrack;
    private int speakerDevId = Integer.MIN_VALUE;
    private int btDevId = Integer.MIN_VALUE;
    private int speakerUsage = -1;
    private int btUsage = -1;
    private boolean speakerMatched;
    private boolean btMatched;
    private int speakerBadMask;
    private int btBadMask;
    private boolean quietAttempted;
    private String lastSignature = "";
    private PowerManager.WakeLock wakeLock;

    private AudioDeviceInfo speakerDevice;
    private AudioDeviceInfo btDevice;

    private Thread captureThread;
    private Thread speakerThread;
    private Thread btThread;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (!MixState.running) {
            SystemSilence.recoverAbandoned(this);
        }
        NotificationChannel channel = new NotificationChannel(
                CHANNEL, "Audio bridge", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Keeps the audio bridge alive");
        channel.setSound(null, null);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(channel);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            MixState.status = "Stopped. Media volume is unchanged.";
            MixState.running = false;
            BridgeBus.post();
            requestHalt();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) || running) {
            return START_NOT_STICKY;
        }
        try {
            startForeground(
                    NOTIFICATION_ID,
                    notification("Starting bridge"),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } catch (Exception e) {
            Log.e(TAG, "foreground", e);
            MixState.status = "Android blocked the bridge notification.";
            MixState.running = false;
            BridgeBus.post();
            stopSelf();
            return START_NOT_STICKY;
        }
        int code = intent.getIntExtra(EXTRA_CODE, 0);
        Intent data = readData(intent);
        if (data == null) {
            fail("Capture permission missing. Start again.");
            return START_NOT_STICKY;
        }
        try {
            startCapture(code, data);
        } catch (Throwable t) {
            Log.e(TAG, "start", t);
            String message = "no-speaker".equals(t.getMessage())
                    ? "No built-in speaker available."
                    : "Could not start capture. Allow screen audio and retry.";
            fail(message);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        requestHalt();
        super.onDestroy();
    }

    private void startCapture(int resultCode, Intent data) {
        Prefs.load(this);
        AudioManager am = Devices.audioManager(this);
        if (Devices.builtInSpeaker(am) == null) {
            throw new IllegalStateException("no-speaker");
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        MediaProjection created = mpm.getMediaProjection(resultCode, data);
        if (created == null) {
            throw new IllegalStateException("projection");
        }
        projection = created;
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                if (running) {
                    MixState.status = "Capture stopped.";
                    MixState.running = false;
                    BridgeBus.post();
                }
                requestHalt();
            }
        }, mainHandler);

        rate = 48000;
        captureConfig = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build();
        record = openRecord(rate);
        if (record == null) {
            rate = 44100;
            record = openRecord(rate);
        }
        if (record == null) {
            throw new IllegalStateException("record");
        }
        MixState.captureRate = rate;
        ring = new RingBuffer(rate, 4);
        record.startRecording();
        openSession();

        // SAFETY: never mute the global media stream; captured playback may depend on it.
        // Use ordinary media-usage tracks until reliable independent routing is verified.
        forceMedia = true;
        heardWhileLive = false;
        heardWhileMuted = false;
        silentSince = 0;
        probing = false;
        probes = 0;
        quietReason = "";
        speakerBadMask = 0;
        btBadMask = 0;
        speakerDevId = Integer.MIN_VALUE;
        btDevId = Integer.MIN_VALUE;
        quietAttempted = false;
        MixState.originalQuiet = false;

        running = true;
        MixState.running = true;
        reroute = true;
        acquireWake();
        if (!devicesRegistered) {
            am.registerAudioDeviceCallback(deviceCallback, mainHandler);
            devicesRegistered = true;
        }
        captureThread = new Thread(new Runnable() {
            @Override
            public void run() {
                captureLoop();
            }
        }, "BridgeCapture");
        speakerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                playLoop(true);
            }
        }, "BridgeSpeaker");
        btThread = new Thread(new Runnable() {
            @Override
            public void run() {
                playLoop(false);
            }
        }, "BridgeBluetooth");
        captureThread.start();
        speakerThread.start();
        btThread.start();
        MixState.status = "Starting both outputs…";
        BridgeBus.post();
    }

    private void captureLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        short[] buf = new short[CHUNK];
        int errors = 0;
        while (running) {
            long now = SystemClock.elapsedRealtime();
            if (reroute || now - lastRouteAt > 1500) {
                reroute = false;
                lastRouteAt = now;
                try {
                    applyRoute();
                } catch (Throwable t) {
                    Log.w(TAG, "route", t);
                }
            }
            int n;
            try {
                n = record.read(buf, 0, buf.length);
            } catch (Throwable t) {
                n = -1;
            }
            if (n < 0) {
                errors++;
                if (errors >= 8) {
                    errors = 0;
                    recordReopens++;
                    reopenRecord();
                    if (recordReopens == 1 || recordReopens % 5 == 0) {
                        MixState.status = "Capture recovered. Bridge stayed on.";
                        BridgeBus.post();
                    }
                } else {
                    sleep(15);
                }
                continue;
            }
            errors = 0;
            if (n < 2) {
                sleep(4);
                continue;
            }
            if ((n & 1) != 0) {
                n--;
            }
            ring.write(buf, n);
            watchLevel(buf, n, now);
        }
    }

    private void watchLevel(short[] buf, int n, long now) {
        boolean hot = Pcm.audible(buf, n);
        if (hot != MixState.hearing) {
            MixState.hearing = hot;
            BridgeBus.post();
        }
        if (probing) {
            if (hot) {
                probeHeard = true;
            }
            if (now >= probeEnd) {
                finishProbe();
            }
            return;
        }
        if (!silence.isHoldingMusic()) {
            if (hot && !heardWhileLive) {
                heardWhileLive = true;
                reroute = true;
            }
            silentSince = 0;
            return;
        }
        if (hot) {
            heardWhileMuted = true;
            silentSince = 0;
            return;
        }
        if (heardWhileMuted) {
            return;
        }
        if (silentSince == 0) {
            silentSince = now;
            return;
        }
        long limit = heardWhileLive ? 700L : 1400L;
        if (now - silentSince >= limit && probes < 2) {
            startProbe(now);
        }
    }

    private void startProbe(long now) {
        probing = true;
        probeHeard = false;
        probeEnd = now + 240L;
        probes++;
        silence.restoreAll(this);
        MixState.originalQuiet = false;
    }

    private void finishProbe() {
        probing = false;
        silentSince = 0;
        if (probeHeard) {
            giveUpQuiet("This tablet mutes capture when media volume is muted. Both speakers stay on the normal music stream, so the original stays audible too.");
            return;
        }
        if (!silence.holdMusic(this)) {
            giveUpQuiet("Media volume can't be muted here. Both speakers stay on the normal music stream.");
            return;
        }
        MixState.originalQuiet = true;
        if (speakerUsage == AudioAttributes.USAGE_ALARM || btUsage == AudioAttributes.USAGE_ALARM) {
            silence.boostAlarm(this);
        }
    }

    private void giveUpQuiet(String reason) {
        forceMedia = true;
        quietAttempted = true;
        probing = false;
        quietReason = reason;
        silence.restoreAll(this);
        MixState.originalQuiet = false;
        dropSpeaker();
        dropBt();
        speakerDevId = Integer.MIN_VALUE;
        btDevId = Integer.MIN_VALUE;
        reroute = true;
        MixState.status = reason;
        BridgeBus.post();
    }

    private void playLoop(final boolean speakerSide) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        short[] buf = new short[CHUNK];
        long[] cursor = new long[] {0L};
        Tone tone = new Tone(rate);
        int[] db = new int[EqPresets.BANDS];
        int appliedDelay = -1;
        int fade = 0;
        long lastFlush = 0;
        AudioTrack seen = null;
        int writes = 0;
        boolean checked = false;
        while (running) {
            AudioTrack track = speakerSide ? speakerTrack : btTrack;
            if (track == null || ring == null) {
                sleep(15);
                continue;
            }
            if (track != seen) {
                seen = track;
                cursor[0] = -1L;
                appliedDelay = -1;
                checked = false;
                writes = 0;
                fade = 288;
                tone = new Tone(rate);
            }
            int shift = speakerSide ? MixState.speakerShiftMs : MixState.btShiftMs;
            int other = speakerSide ? MixState.btShiftMs : MixState.speakerShiftMs;
            int delayMs = Sync.absoluteDelayMs(shift, other);
            boolean snap = false;
            if (appliedDelay >= 0 && appliedDelay != delayMs) {
                long now = SystemClock.elapsedRealtime();
                if (now - lastFlush >= 80) {
                    snap = true;
                    flushTrack(track);
                    lastFlush = now;
                    fade = 288;
                    appliedDelay = delayMs;
                } else {
                    delayMs = appliedDelay;
                }
            }
            int delayFrames = Sync.delayFrames(rate, delayMs);
            boolean fresh = cursor[0] < 0;
            int n = ring.read(buf, buf.length, cursor, delayFrames, snap || fresh);
            if (appliedDelay < 0) {
                appliedDelay = delayMs;
            }
            if (n < 2) {
                sleep(3);
                continue;
            }
            if (speakerSide) {
                MixState.copySpeakerEq(db);
            } else {
                MixState.copyBtEq(db);
            }
            boolean muted = speakerSide ? MixState.speakerMuted : MixState.btMuted;
            int vol = speakerSide ? MixState.speakerVolume : MixState.btVolume;
            float gain = muted || vol <= 0 ? 0f : vol / 100f;
            tone.process(buf, n, gain, db);
            if (fade > 0) {
                Pcm.fadeIn(buf, n, fade);
                fade = 0;
            }
            int off = 0;
            while (off < n && running) {
                AudioTrack current = speakerSide ? speakerTrack : btTrack;
                if (current == null || current != track) {
                    break;
                }
                int wrote;
                try {
                    wrote = current.write(buf, off, n - off);
                } catch (Throwable t) {
                    wrote = -1;
                }
                if (wrote < 0) {
                    forceRebuild(speakerSide);
                    break;
                }
                if (wrote == 0) {
                    sleep(2);
                    continue;
                }
                off += wrote;
            }
            if (off > 0) {
                writes++;
            }
            if (!checked && writes >= 6) {
                checked = true;
                noteRoute(speakerSide, track);
            }
        }
    }

    private void noteRoute(boolean speakerSide, AudioTrack track) {
        int usage = speakerSide ? speakerUsage : btUsage;
        AudioDeviceInfo wanted = speakerSide ? speakerDevice : btDevice;
        AudioDeviceInfo routed;
        try {
            routed = track.getRoutedDevice();
        } catch (Throwable t) {
            return;
        }
        if (routed == null || wanted == null) {
            return;
        }
        boolean call = Devices.isCallRoute(routed.getType());
        boolean matches = Devices.sameOutput(wanted, routed);
        if (!call && matches) {
            if (speakerSide) {
                speakerMatched = true;
            } else {
                btMatched = true;
            }
            return;
        }
        Log.w(TAG, "route miss usage " + usage + " type " + routed.getType());
        if (usage != AudioAttributes.USAGE_MEDIA) {
            if (speakerSide) {
                speakerBadMask |= usageBit(usage);
                speakerDevId = Integer.MIN_VALUE;
            } else {
                btBadMask |= usageBit(usage);
                btDevId = Integer.MIN_VALUE;
            }
            reroute = true;
            return;
        }
    }

    private void applyRoute() {
        synchronized (routeLock) {
            if (!running) {
                return;
            }
            speakerDevice = Devices.builtInSpeaker(Devices.audioManager(this));
            btDevice = Devices.chooseBluetooth(this);
            int speakerId = speakerDevice == null ? -1 : speakerDevice.getId();
            boolean upgrade = heardWhileLive && !forceMedia && !quietAttempted && !silence.isHoldingMusic();
            if (upgrade) {
                quietAttempted = true;
            }
            if (speakerDevice == null) {
                dropSpeaker();
            } else if (upgrade || speakerTrack == null || speakerId != speakerDevId) {
                dropSpeaker();
                Opened opened = openBest(speakerDevice, true);
                speakerTrack = opened.track;
                speakerUsage = opened.usage;
                speakerMatched = opened.matched;
                speakerDevId = speakerTrack == null ? Integer.MIN_VALUE : speakerId;
            }
            int btId = btDevice == null ? -1 : btDevice.getId();
            if (btDevice == null) {
                dropBt();
                btDevId = Integer.MIN_VALUE;
            } else if (upgrade || btTrack == null || btId != btDevId) {
                dropBt();
                Opened opened = openBest(btDevice, false);
                btTrack = opened.track;
                btUsage = opened.usage;
                btMatched = opened.matched;
                btDevId = btTrack == null ? Integer.MIN_VALUE : btId;
            }
            considerQuiet();
            publishRoute();
        }
    }

    private void considerQuiet() {
        // SAFETY FIX: Android playback capture can become silent when STREAM_MUSIC is muted.
        // Never mute or boost global system streams from this app. This keeps the captured
        // stream audible, although Android may still play the original on its selected output.
        if (silence.isHoldingMusic()) {
            silence.restoreAll(this);
        }
        forceMedia = true;
        quietAttempted = true;
        MixState.originalQuiet = false;
    }

    private void publishRoute() {
        String speakerName = speakerDevice == null ? "No built-in speaker" : "Built-in speaker";
        if (speakerTrack == null) {
            speakerName = speakerName + " · waiting";
        } else if (!speakerMatched) {
            speakerName = speakerName + " · playing, pin not confirmed";
        }
        String btName;
        if (btDevice == null) {
            btName = "Nothing connected";
        } else if (btTrack == null) {
            btName = Devices.label(btDevice) + " · waiting";
        } else if (!btMatched) {
            btName = Devices.label(btDevice) + " · playing, pin not confirmed";
        } else {
            btName = Devices.label(btDevice);
        }
        MixState.speakerRoute = speakerName;
        MixState.btRoute = btName;
        MixState.originalQuiet = silence.isHoldingMusic();
        MixState.primaryLabel = running ? "Virtual dummy sink · active (discards audio)" : "Virtual dummy sink · off";
        if (silence.isHoldingMusic()) {
            MixState.originalLabel = "Original is silenced. Both copies are off the media volume. Volume returns when you stop.";
        } else if (quietReason.length() > 0) {
            MixState.originalLabel = quietReason;
        } else {
            MixState.originalLabel = "Both copies use the music stream, so they stay loud. Android still plays the original on its chosen output.";
        }
        StringBuilder path = new StringBuilder();
        path.append("Other apps\n");
        path.append("        ↓\n");
        path.append("Capture · ").append(rate).append(" Hz stereo\n");
        path.append("        ↓\n");
        path.append("Virtual dummy sink · discards samples\n");
        path.append("        ├── tablet speaker\n");
        path.append("        └── ").append(btDevice == null ? "Bluetooth waiting" : "Bluetooth speaker");
        MixState.path = path.toString();

        String status;
        if (quietReason.length() > 0 && !silence.isHoldingMusic()) {
            status = "Speaker " + (speakerTrack != null ? "on" : "off")
                    + " · Bluetooth " + (btTrack != null ? "on" : (btDevice == null ? "not connected" : "off"))
                    + ". " + quietReason;
        } else if (silence.isHoldingMusic()) {
            status = "Original quiet. Speaker " + (speakerTrack != null ? "on" : "off")
                    + ". Bluetooth " + (btTrack != null ? "on" : (btDevice == null ? "not connected" : "off")) + ".";
        } else {
            status = "Speaker " + (speakerTrack != null ? "on" : "off")
                    + " · Bluetooth " + (btTrack != null ? "on" : (btDevice == null ? "not connected" : "off"))
                    + ". Media volume left alone.";
        }
        if (!MixState.hearing) {
            status = status + " Waiting for audio.";
        }
        MixState.status = status;
        String sig = speakerDevId + ":" + btDevId + ":" + silence.isHoldingMusic() + ":" + speakerUsage + ":" + btUsage + ":" + status;
        if (!sig.equals(lastSignature)) {
            lastSignature = sig;
            String notice = silence.isHoldingMusic() ? "Original quiet · both copies live" : "Both copies live";
            updateNotification(notice);
            BridgeBus.post();
        }
    }

    private void onDevicesChanged() {
        if (!running) {
            return;
        }
        speakerBadMask = 0;
        btBadMask = 0;
        if (!silence.isHoldingMusic()) {
            // Keep safe media routing after device changes; never auto-mute system media.
            forceMedia = true;
            quietAttempted = true;
            quietReason = "";
        }
        reroute = true;
        MixState.status = "Bluetooth changed. Bridge stayed on.";
        BridgeBus.post();
    }

    private Opened openBest(AudioDeviceInfo device, boolean speakerSide) {
        int bad = speakerSide ? speakerBadMask : btBadMask;
        if (!forceMedia && quietAttempted) {
            for (int i = 0; i < QUIET_USAGES.length; i++) {
                int usage = QUIET_USAGES[i];
                if ((bad & usageBit(usage)) != 0) {
                    continue;
                }
                Opened opened = tryOpen(device, usage, true);
                if (opened.track != null) {
                    return opened;
                }
            }
        }
        return tryOpen(device, AudioAttributes.USAGE_MEDIA, false);
    }

    private Opened tryOpen(AudioDeviceInfo device, int usage, boolean requireMatch) {
        Opened opened = new Opened();
        AudioTrack track = buildTrack(usage);
        if (track == null) {
            return opened;
        }
        boolean pinned;
        try {
            pinned = track.setPreferredDevice(device);
        } catch (Throwable t) {
            pinned = false;
        }
        if (!pinned) {
            if (usage != AudioAttributes.USAGE_MEDIA || requireMatch) {
                releaseTrack(track);
                return opened;
            }
        }
        try {
            track.setVolume(1f);
            track.play();
            track.write(silenceChunk, 0, Math.min(silenceChunk.length, 256));
        } catch (Throwable t) {
            releaseTrack(track);
            return opened;
        }
        AudioDeviceInfo routed = routedOf(track);
        if (requireMatch && routed == null) {
            sleep(30);
            routed = routedOf(track);
        }
        if (routed != null && Devices.isCallRoute(routed.getType())) {
            releaseTrack(track);
            return opened;
        }
        boolean matched = Devices.sameOutput(device, routed);
        if (requireMatch && !matched) {
            releaseTrack(track);
            return opened;
        }
        opened.track = track;
        opened.usage = usage;
        opened.matched = matched;
        Log.i(TAG, "opened type " + device.getType() + " usage " + usage + " matched " + matched);
        return opened;
    }

    private AudioDeviceInfo routedOf(AudioTrack track) {
        try {
            return track.getRoutedDevice();
        } catch (Throwable t) {
            return null;
        }
    }

    private AudioTrack buildTrack(int usage) {
        int min = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) {
            return null;
        }
        int buffer = Math.max(min * 2, rate * 4 * 80 / 1000);
        try {
            AudioTrack.Builder builder = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(usage)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_NONE)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build())
                    .setBufferSizeInBytes(buffer)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_NONE);
            if (Build.VERSION.SDK_INT >= 33) {
                builder.setOffloadedPlayback(false);
            }
            AudioTrack track = builder.build();
            if (track.getState() != AudioTrack.STATE_INITIALIZED) {
                track.release();
                return null;
            }
            return track;
        } catch (Throwable t) {
            Log.w(TAG, "track", t);
            return null;
        }
    }

    private AudioRecord openRecord(int sampleRate) {
        int min = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) {
            return null;
        }
        int buffer = Math.max(min * 2, sampleRate * 4 * 160 / 1000);
        try {
            AudioRecord built = new AudioRecord.Builder()
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                            .build())
                    .setBufferSizeInBytes(buffer)
                    .setAudioPlaybackCaptureConfig(captureConfig)
                    .build();
            if (built.getState() != AudioRecord.STATE_INITIALIZED) {
                built.release();
                return null;
            }
            return built;
        } catch (Throwable t) {
            Log.w(TAG, "record", t);
            return null;
        }
    }

    private void reopenRecord() {
        AudioRecord fresh = openRecord(rate);
        if (fresh == null) {
            return;
        }
        AudioRecord old = record;
        record = fresh;
        if (old != null) {
            try {
                old.stop();
            } catch (Exception ignored) {
            }
            try {
                old.release();
            } catch (Exception ignored) {
            }
        }
        try {
            fresh.startRecording();
        } catch (Throwable t) {
            Log.w(TAG, "restart record", t);
        }
    }

    private void openSession() {
        try {
            session = new MediaSession(this, "SystemAudioBridge");
            session.setPlaybackState(new PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_STOP)
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build());
            session.setCallback(new MediaSession.Callback() {
                @Override
                public void onStop() {
                    requestHalt();
                }
            }, mainHandler);
            session.setActive(true);
        } catch (Throwable t) {
            Log.w(TAG, "session", t);
        }
    }

    private static int usageBit(int usage) {
        if (usage == AudioAttributes.USAGE_MEDIA) {
            return 1;
        }
        if (usage == AudioAttributes.USAGE_ALARM) {
            return 2;
        }
        if (usage == AudioAttributes.USAGE_ASSISTANCE_SONIFICATION) {
            return 4;
        }
        if (usage == AudioAttributes.USAGE_NOTIFICATION) {
            return 8;
        }
        return 16;
    }

    private void fail(String message) {
        MixState.status = message;
        MixState.running = false;
        BridgeBus.post();
        requestHalt();
    }

    private void requestHalt() {
        if (halted) {
            return;
        }
        halted = true;
        running = false;
        MixState.running = false;
        MixState.hearing = false;
        MixState.originalQuiet = false;
        MixState.primaryLabel = "Virtual dummy sink · off";
        MixState.originalLabel = "Media volume restored if it was changed.";
        joinThread(captureThread, 700);
        joinThread(speakerThread, 500);
        joinThread(btThread, 500);
        captureThread = null;
        speakerThread = null;
        btThread = null;
        dropSpeaker();
        dropBt();
        if (record != null) {
            try {
                record.stop();
            } catch (Exception ignored) {
            }
            try {
                record.release();
            } catch (Exception ignored) {
            }
            record = null;
        }
        if (projection != null) {
            try {
                projection.stop();
            } catch (Exception ignored) {
            }
            projection = null;
        }
        if (session != null) {
            try {
                session.setActive(false);
                session.release();
            } catch (Exception ignored) {
            }
            session = null;
        }
        if (devicesRegistered) {
            try {
                Devices.audioManager(this).unregisterAudioDeviceCallback(deviceCallback);
            } catch (Exception ignored) {
            }
            devicesRegistered = false;
        }
        silence.restoreAll(this);
        releaseWake();
        try {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } catch (Throwable ignored) {
        }
        stopSelf();
        BridgeBus.post();
    }

    private void dropSpeaker() {
        AudioTrack old = speakerTrack;
        speakerTrack = null;
        speakerUsage = -1;
        speakerMatched = false;
        releaseTrack(old);
    }

    private void dropBt() {
        AudioTrack old = btTrack;
        btTrack = null;
        btUsage = -1;
        btMatched = false;
        releaseTrack(old);
    }

    private void forceRebuild(boolean speakerSide) {
        if (speakerSide) {
            speakerDevId = Integer.MIN_VALUE;
        } else {
            btDevId = Integer.MIN_VALUE;
        }
        reroute = true;
    }

    private void flushTrack(AudioTrack track) {
        try {
            track.pause();
        } catch (Throwable ignored) {
        }
        try {
            track.flush();
        } catch (Throwable ignored) {
        }
        try {
            track.play();
        } catch (Throwable ignored) {
        }
    }

    private void releaseTrack(AudioTrack track) {
        if (track == null) {
            return;
        }
        try {
            track.pause();
        } catch (Exception ignored) {
        }
        try {
            track.flush();
        } catch (Exception ignored) {
        }
        try {
            track.stop();
        } catch (Exception ignored) {
        }
        try {
            track.release();
        } catch (Exception ignored) {
        }
    }

    private void acquireWake() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SystemAudioBridge:run");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(6L * 60L * 60L * 1000L);
        } catch (Exception ignored) {
        }
    }

    private void releaseWake() {
        PowerManager.WakeLock lock = wakeLock;
        wakeLock = null;
        if (lock != null) {
            try {
                if (lock.isHeld()) {
                    lock.release();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pending = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("System Audio Bridge")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentIntent(pending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void updateNotification(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, notification(text));
        } catch (Exception ignored) {
        }
    }

    private static Intent readData(Intent intent) {
        if (intent == null) {
            return null;
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                return intent.getParcelableExtra(EXTRA_DATA, Intent.class);
            }
            return intent.getParcelableExtra(EXTRA_DATA);
        } catch (Exception e) {
            return null;
        }
    }

    private static void joinThread(Thread thread, long ms) {
        if (thread == null) {
            return;
        }
        try {
            thread.join(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private static final class Opened {
        AudioTrack track;
        int usage = -1;
        boolean matched;
    }
}
